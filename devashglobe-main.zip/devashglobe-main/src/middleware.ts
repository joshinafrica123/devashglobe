// File: src/middleware.ts
// This file is used to handle authentication .
import { NextRequest, NextResponse } from 'next/server';
import { BASE_URL } from './app/core/api';
// import type { NextFetchEvent } from 'next/server';

export async function middleware(req: NextRequest) {
  if (req.nextUrl.pathname.startsWith('/users')) {
    console.log('Entered middleware!!!');

    if (req.nextUrl.pathname.startsWith(`/users/shipper`) || req.nextUrl.pathname.startsWith(`/users/carrier`)) {
        
          const token = req.cookies.get('token')?.value;
          if(!token){
                  return NextResponse.redirect(new URL('/login', req.url));
          }
      
      return NextResponse.next(); // ✅ Already there
    }else{
       // Call your helper and return the result (if any)
      const redirectResponse = await userDoneKyc(req);
      if (redirectResponse) return redirectResponse;
    }

  }

  if(req.nextUrl.pathname.startsWith('/admin/')){
    console.log('Admin Entered middleware!!!');

    const urlTest = req.nextUrl.pathname.split("/");

    if(urlTest[urlTest.length - 1] !==  "admin"  ){

      const token = req.cookies.get('not_usertoken')?.value;

          if(!token){

                  if(urlTest[urlTest.length - 1] ==  "forgotpassword" ){
                     return NextResponse.next();
                  }else if(urlTest[urlTest.length - 1] !==  "login"  ){
                    return NextResponse.redirect(new URL('/admin/', req.url));
                  }else{
                    return NextResponse.redirect(new URL('/', req.url));
                  }

              
          }
      
      return NextResponse.next(); // ✅ Already there
  }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/users/:path*',
    '/admin/:path*',
    // Skip Next.js internals and all static files, unless found in search params
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    // Always run for API routes
    '/(api|trpc)(.*)',
  ], // simpler matcher
};

// ✅ Return a redirect or null
async function userDoneKyc(req: NextRequest): Promise<NextResponse | null> {
  try {
    
    // Replace with real cookie reading
    const token = req.cookies.get('token')?.value;

    // console.log(token)

    if (!token) {
      return NextResponse.redirect(new URL('/login', req.url));
    }


    const response = await fetch(`${BASE_URL}/userkyc`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      return NextResponse.redirect(new URL('/login', req.url));
    }

    const data = await response.json();
    const kycData = data.kyc?.[0];

    if (data.error || !kycData ) {
      return NextResponse.next();
    }


    // ✅ redirect based on user_type
    return NextResponse.redirect(new URL(`/users/${kycData.user_type}`, req.url));


  } catch (error) {
    console.error('KYC check failed:', error);
    return NextResponse.redirect(new URL('/login', req.url));
  }
}




