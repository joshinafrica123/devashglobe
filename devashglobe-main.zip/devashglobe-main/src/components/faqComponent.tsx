"use client"

import { apiCall, BASE_URL } from "@/app/core/api";
import { Faq } from "@/app/datatype/faq";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import responce from "@/app/datatype/response";
import { Suspense, useEffect, useState } from "react"

const faqAlt:Faq[] = []



function FaqSkeleton() {
  return (
    <>
      {[...Array(6)].map((_, idx) => (
        <div key={idx} className="border p-4 rounded-lg bg-gray-100 dark:bg-gray-800 animate-pulse w-full max-w-xl mx-auto">
          <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-2/3 mb-2" />
          <div className="h-3 bg-gray-200 dark:bg-gray-600 rounded w-1/2" />
        </div>
      ))}
    </>
  );
}

function FaqList({ faq }: { faq: Faq[] }) {
  return (
    <>
      {faq?.map((question, index) => (
        <details key={index} className="border p-4 rounded-lg bg-[#06163A] dark:bg-gray-800 w-full max-w-xl mx-auto">
          <summary className="font-semibold cursor-pointer">{question.question}</summary>
          <p className="mt-2 text-sm">{question.response_ans}</p>
        </details>
      ))}
    </>
  );
}

export default function FaqComponent (){

  const [faq,setFaq] = useState<Faq[]>(faqAlt);
  const [errors, setErrors] = useState<string[]>([]);

  useEffect(()=>{
    console.log(8888888)
    handleGetFaq();

  },[]);

  async function handleGetFaq () {
    
    
  try {
      // get logged in user token
      const token = getCookie('token');

       const response = await apiCall(token+"",`${BASE_URL}/faqs`,'GET', null );

              if (!response.ok) {
                  throw new Error(`Failed to get : ${response.status}`);
              }

              const data = await response.json();
              console.log(data);

              const dataTypeed = (data as responce);

              
                if(dataTypeed.error){
                      const errList : string[] = [dataTypeed.error]
                      setErrors(errList);
                    }else{
                      console.log(dataTypeed.faq);

                    setFaq(dataTypeed.faq);
                    
                      }
                  
                  

  } catch (error) {
      console.error('faq error:', error);
      console.error('faq error:', errors);

  }

  }

  

    return (
        <div>
        <h1 className=" text-lg sm:text-2xl md:text-4xl   text-gray-900  font-semibold text-center">Frequently Asked <span className="text-[#D62D30]">Questions</span></h1>
        <div className="mt-6">
          <div className="accordion space-y-4 flex flex-col items-center justify-center min-h-[200px]">
            <Suspense fallback={<FaqSkeleton />}>
              <FaqList faq={faq} />
            </Suspense>
          </div>
        </div>
      </div>
    )
}