"use client";

import { Package, Truck, Globe, Clock } from "lucide-react";
import { Suspense, useState, useEffect } from "react";

const chooseUs = [
  {
    title: "Secure & Reliable Packaging",
    description:
      "Every shipment is handled with the utmost care. Our professional packing standards ensure your goods remain safe, secure, and intact from pickup to delivery.",
    icon: Package,
  },
  {
    title: "On-Time, Every Time",
    description:
      "We understand the importance of deadlines. With real-time tracking and smart routing, we guarantee timely deliveries you can depend on.",
    icon: Clock,
  },
  {
    title: "Global Reach, Local Expertise",
    description:
      "No matter the distance, we deliver. From local routes to international shipments, our extensive network ensures your cargo reaches anywhere in the world.",
    icon: Globe,
  },
  {
    title: "Speed Without Compromise",
    description:
      "When time is critical, we deliver at the fastest pace while maintaining safety and accuracy—helping your business stay ahead of schedule.",
    icon: Truck,
  },
];

function ChooseUsSkeleton() {
  return (
    <div className="grid gap-6 mt-6">
      {[...Array(4)].map((_, idx) => (
        <div
          key={idx}
          className="shadow-lg rounded-lg p-4 bg-gray-100 dark:bg-gray-800 animate-pulse"
        >
          <div className="w-6 h-6 rounded-full bg-gray-300 dark:bg-gray-700 mb-2" />
          <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-2/3 mb-2" />
          <div className="h-3 bg-gray-200 dark:bg-gray-600 rounded w-1/2" />
        </div>
      ))}
    </div>
  );
}

function ChooseUsList() {
  // Simulate loading for demonstration
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);
  if (loading) return <ChooseUsSkeleton />;
  return (
  <div className="flex flex-col gap-8 mt-10 max-w-3xl mx-auto">
  {chooseUs.map((feature, index) => (
    <div
      key={index}
      className="group flex items-start gap-4 p-6 bg-white dark:bg-gray-900 rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 relative"
    >
      {/* Icon */}
      <div className="w-12 h-12 flex items-center justify-center rounded-full bg-gradient-to-r from-[#06163A] to-[#0A2A6C] dark:from-[#D62D30] dark:to-red-700 text-white flex-shrink-0">
        <feature.icon className="w-6 h-6" />
      </div>

      {/* Text */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white group-hover:text-[#D62D30] transition">
          {feature.title}
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mt-1 leading-relaxed">
          {feature.description}
        </p>
      </div>
    </div>
  ))}
</div>

  );
}

export default function faqComponent() {
  return (
    <div>
      <h3 className="text-xl font-semibold text-center">Why Choose Us</h3>
      <Suspense fallback={<ChooseUsSkeleton />}>
        <ChooseUsList />
      </Suspense>
    </div>
  );
}
