"use client";

import {motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { Suspense, useState, useEffect } from "react";

const testimonials = [
  { name: "Mr Obi", text: "Excellent service! Always on time and reliable.", image: "/assets/img/testimonial/1.jpeg" },
  { name: "Mrs Mercya", text: "Their logistics solutions helped scale my business.", image: "/assets/img/testimonial/2.jpg" },
  { name: "Mr Heigth", text: "Superb tracking system and fast deliveries!", image: "/assets/img/testimonial/7.webp" }, 
   { name: "Mrs AdeBajo", text: "Their logistics solutions helped scale my business.", image: "/assets/img/testimonial/3.jpg" },
  { name: "Mr Kwesi", text: "Superb tracking system and fast deliveries!", image: "/assets/img/testimonial/4.jpg" },
];

function TestimonialSkeleton() {
  return (
    <div className="flex space-x-6 p-6">
      {[...Array(5)].map((_, idx) => (
        <div key={idx} className="min-w-[300px] animate-pulse shadow-lg rounded-lg p-4 bg-gray-100 dark:bg-gray-800">
          <div className="w-16 h-16 rounded-full bg-gray-300 dark:bg-gray-700 mx-auto mb-3" />
          <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded mb-2 w-3/4 mx-auto" />
          <div className="h-3 bg-gray-200 dark:bg-gray-600 rounded w-1/2 mx-auto" />
        </div>
      ))}
    </div>
  );
}

function TestimonialList() {
  // Simulate loading for demonstration
  const [loading, setLoading] = useState(true);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1200);
    return () => clearTimeout(timer);
  }, []);
  // Auto-scroll every 10s
  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % testimonials.length);
    }, 10000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  if (loading) return <TestimonialSkeleton />;
  return (
    <>
     
    <section className="py-16 px-6 bg-gradient-to-r from-[#06163A] via-[#0E244F] to-[#06163A] text-white relative">
      <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">What Our Clients Say</h2>

      <div className="relative max-w-2xl mx-auto h-[420px] flex items-center justify-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.8 }}
            className="absolute w-full bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-xl flex flex-col items-center text-center"
          >
            {/* Big Image */}
            <Image
              src={testimonials[index].image}
              alt={testimonials[index].name}
              width={160}
              height={160}
              className="w-32 h-32 rounded-full object-cover border-4 border-[#D62D30] shadow-lg mb-6"
            />

            {/* Testimonial Text */}
            <p className="italic text-lg text-gray-200 leading-relaxed mb-6 max-w-md">
              {testimonials[index].text}
            </p>

            {/* Name + Role */}
            <h3 className="text-xl font-semibold">{testimonials[index].name}</h3>
            {/* <p className="text-gray-400 text-sm">{testimonials[index].role}</p> */}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-center gap-4 mt-8">
        <button
          onClick={() => setIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)}
          className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 hover:bg-[#D62D30] transition"
        >
          ◀
        </button>
        <button
          onClick={() => setIndex((prev) => (prev + 1) % testimonials.length)}
          className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 hover:bg-[#D62D30] transition"
        >
          ▶
        </button>
      </div>
    </section>
    </>
  );
}

export default function TestimonialComponent (){
  return (
    <div className="mt-12 mb-5 px-2">
      {/* <h2 className="text-2xl font-bold text-center text-[#06163A] dark:text-[#D62D30]">What Our Clients Say</h2> */}
      <Suspense fallback={<TestimonialSkeleton />}>
        <TestimonialList />
      </Suspense>
    </div>
  );
}