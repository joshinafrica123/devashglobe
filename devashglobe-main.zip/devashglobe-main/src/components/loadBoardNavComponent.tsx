"use client";

import { useState } from "react";
import { BASE_URL } from "@/app/core/api";
import { validateEmail, validatePhone } from "@/app/core/util";

export default function FreightForm() {
  const [freightData, setFreightData] = useState({
    type: "",
    size: "",
    name: "",
    phone: "",
    companyName: "",
    email: "",
    message: "",
  });
  const [errors, setErrors] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [distance, setDistance] = useState(50);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    console.log(name);
    setFreightData({ ...freightData, [name]: value });
  };
  const handleChangeT = (
    e: React.ChangeEvent<HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFreightData({ ...freightData, [name]: value });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors([]);
    console.log("Freight Data Submitted:", freightData);

    // Here you can add your API call to submit the freight data
    // check if the data is being logged correctly
    if (
      freightData.type &&
      freightData.email &&
      freightData.size &&
      freightData.message &&
      freightData.companyName &&
      distance &&
      freightData.name &&
      freightData.phone
    ) {
      console.log("Freight data is valid and ready to be submitted.");

      const errologs: string[] = [];

      const validateEmails = validateEmail(freightData.email);

      if (validateEmails.length > 0) {
        errologs.push(...validateEmails);
        setErrors(errologs);
        return;
      }

      const validatePhones = validatePhone(freightData.phone);
      if (validatePhones.length > 0) {
        errologs.push(...validatePhones);
        setErrors(errologs);
        return;
      }

      setLoading(true);

      // GET DATA FROR API
      const formData = new globalThis.FormData();
      formData.append("email", freightData.email);
      formData.append("type", freightData.type);
      formData.append("size", freightData.size);
      formData.append("distance", distance + "");
      formData.append("name", freightData.name);
      formData.append("phone", freightData.phone);
      formData.append("companyName", freightData.companyName);
      formData.append("message", freightData.message);

      // Call your API function here
      resquestApi(formData);
    } else {
      console.log("Please fill in all required fields.");
      setErrors(["Please fill in all required fields."]);
    }
  };

  async function resquestApi(freightData: FormData): Promise<void> {
    try {
      const response = await fetch(`${BASE_URL}/contacts`, {
        method: "POST",
        body: freightData,
      });

      if (!response.ok) {
        setErrors([
          "Failed to submit freight request. Please try again later.",
        ]);
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      // Assuming the API returns a success message or data
      // set sussess message or handle the response as needed
      setSuccessMessage("Freight request submitted successfully!");
      // Handle the response data as needed
      console.log("Freight request submitted successfully:", data);
      setLoading(false);
    } catch (error) {
      console.error("Error submitting freight request:", error);
      setErrors(["Failed to submit freight request. Please try again later."]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 p-8 mb-10 rounded-2xl shadow-2xl max-w-2xl mx-auto relative overflow-hidden">
      {/* Decorative Gradient Circle */}
      <div className="absolute -top-16 -right-16 w-40 h-40 bg-[#D62D30]/20 rounded-full blur-3xl"></div>

      <h3 className="text-3xl font-extrabold text-[#06163A] dark:text-white text-center mb-6">
        Get a Quote from{" "}
        <span className="text-[#D62D30]">AshGlobe Loadboard</span>
      </h3>

      {/* Alerts */}
      {errors.length > 0 && (
        <div className="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 rounded-lg mb-6 shadow-sm">
          <ul className="list-disc pl-5">
            {errors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}
      {successMessage && (
        <div className="bg-green-50 border-l-4 border-green-600 text-green-700 p-4 rounded-lg mb-6 shadow-sm">
          {successMessage}
        </div>
      )}

      <form className="space-y-6" onSubmit={handleSubmit}>
        {/* Freight Type */}
        <div>
          <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
            Type
          </label>
          <select
            name="type"
            onChange={handleChange}
            className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-[#D62D30] focus:outline-none"
            required
          >
            <option value="">Select</option>
            <option value="load">Load</option>
            <option value="truck">Truck</option>
          </select>
        </div>

        {/* Load Size */}
        <div>
          <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
            Size
          </label>
          <select
            name="size"
            onChange={handleChange}
            className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-[#D62D30] focus:outline-none"
            required
          >
            <option value="">Select</option>
            <option value="500">500kg</option>
            <option value="1000">1000kg</option>
            <option value="2000">1500kg</option>
            <option value="2500">2500kg</option>
            <option value="3000">3000kg</option>
            <option value="3000+">Above 3000kg</option>
          </select>
        </div>

        {/* Distance */}
        <div>
          <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
            Distance (Miles):{" "}
            <span className="font-semibold text-[#D62D30]">{distance}</span>
          </label>
          <input
            type="range"
            min="0"
            max="100"
            name="distance"
            value={distance}
            onChange={(e) => setDistance(parseInt(e.target.value))}
            className="w-full accent-[#D62D30]"
            required
          />
        </div>

        {/* Name & Phone */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
              Your Name
            </label>
            <input
              onChange={handleChange}
              type="text"
              name="name"
              placeholder="John Doe"
              className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-[#D62D30] focus:outline-none"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
              Phone Number
            </label>
            <input
              onChange={handleChange}
              name="phone"
              type="tel"
              placeholder="+883..."
              className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-[#D62D30] focus:outline-none"
              required
            />
          </div>
        </div>

        {/* Company & Email */}
        <div className="grid md:grid-cols-2 gap-6">
          <input
            type="text"
            name="companyName"
            onChange={handleChange}
            value={freightData.companyName}
            placeholder="Your Company Name"
            className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800 dark:text-white focus:ring-2 focus:ring-[#D62D30] focus:outline-none"
          />
          <input
            type="email"
            name="email"
            onChange={handleChange}
            value={freightData.email}
            placeholder="Email Address"
            className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800 dark:text-white focus:ring-2 focus:ring-[#D62D30] focus:outline-none"
          />
        </div>

        {/* Message */}
        <textarea
          onChange={(e) =>
            handleChangeT(e as React.ChangeEvent<HTMLTextAreaElement>)
          }
          value={freightData.message}
          name="message"
          placeholder="Write your question here..."
          rows={4}
          className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800 dark:text-white focus:ring-2 focus:ring-[#D62D30] focus:outline-none"
        />

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading}
          className={`w-full py-3 rounded-lg font-semibold text-white shadow-md transition-all duration-300 transform hover:scale-[1.02]
        ${
          loading
            ? "bg-gray-400 cursor-not-allowed"
            : "bg-[#06163A] hover:bg-[#D62D30]"
        }`}
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <svg
                className="w-5 h-5 animate-spin"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8v8z"
                ></path>
              </svg>
              Sending Request...
            </span>
          ) : (
            "Submit Request"
          )}
        </button>
      </form>

      <p className="text-gray-600 dark:text-gray-400 text-xs text-center mt-6">
        By clicking on{" "}
        <a href="#" className="text-[#D62D30] underline">
          Submit Request
        </a>
        , I agree to the processing of my data in line with AshGlobe’s privacy
        policy.
      </p>
    </div>
  );
}
