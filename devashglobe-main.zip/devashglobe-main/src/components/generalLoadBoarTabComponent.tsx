"use client";
import { apiCall, BASE_URL } from "@/app/core/api";
import {
  getCookie,
  isCookieValid,
} from "@/app/datatype/frontEndCookiee";
import { loadboard } from "@/app/datatype/loadboards";
import responce from "@/app/datatype/response";
import { useEffect, useState } from "react";
import SmartSearchInput from "./globalsearchComponents";
import { useRouter } from "next/navigation";
// import {
//   FaClock,
//   FaLandmark,
//   FaLocationArrow,
//   FaMoneyBill,
//   FaSearchLocation,
//   FaTruck,
// } from "react-icons/fa";
// import { openMap } from "@/app/core/util";

{
  /* // Skeleton loader for loadboard cards */
}
// function LoadboardSkeleton() {
//   return (
//     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
//       {[...Array(6)].map((_, idx) => (
//         <div
//           key={idx}
//           className="relative w-90 h-80 bg-gray-200 dark:bg-gray-800 shadow-lg rounded-lg animate-pulse"
//         >
//           <div className="absolute inset-0 bg-gray-300 dark:bg-gray-700 rounded-lg" />
//           <div className="absolute inset-0 flex flex-col items-start justify-center p-4">
//             <div className="h-6 w-1/2 bg-gray-400 dark:bg-gray-600 rounded mb-2" />
//             <div className="h-4 w-1/3 bg-gray-300 dark:bg-gray-500 rounded mb-2" />
//             <div className="h-4 w-1/4 bg-gray-200 dark:bg-gray-600 rounded mb-2" />
//             <div className="h-3 w-1/2 bg-gray-300 dark:bg-gray-500 rounded mb-2" />
//             <div className="h-3 w-1/2 bg-gray-200 dark:bg-gray-600 rounded mb-2" />
//           </div>
//         </div>
//       ))}
//     </div>
//   );
// }

{
  /* // Actual loadboard cards */
}
// function LoadboardList({ filteredData }: { filteredData: loadboard[] }) {
//   return (
//     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
//       {filteredData.map((item, index) => (
//         <div
//           key={index}
//           className=" group w-90 h-80 bg-cover bg-center text-black shadow-lg rounded-lg "
//           style={{ backgroundImage: `url('${item.image}')` }}
//         >
//           {/* Overlay with Hidden Content */}
//           <div className="bg-[#06163A] opacity-85 flex flex-col items-start justify-center text-white text-center p-4 rounded-lg ">
//             <h2 className="text-lg font-bold">{item.title}</h2>
//             <span className="text-sm bg-[#D62D30] px-2 py-1 rounded mt-2">
//               {item.type.toUpperCase()}
//             </span>
//             <h5 className="pt-2">3/May/2025</h5>
//             <h5>
//               <span>From: ABC</span>
//             </h5>
//             <h3>
//               <span>To: XYZ</span>
//             </h3>
//             <p className="mt-2">
//               {item.from_state} - {item.to_state}{" "}
//             </p>
//           </div>
//         </div>
//       ))}
//       {filteredData.length === 0 && (
//         <div className="text-center text-sm text-gray-500 dark:text-gray-300 mt-4">
//           No Loads found yet.
//         </div>
//       )}
//     </div>
//   );
// }

export default function GeneralLaodBoardTab() {
  const [loadboards, setLoadboards] = useState<loadboard[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLoadboard, setSelectedLoadboard] = useState<loadboard | null>(
    null
  );
  const [userType, setUserType] = useState("");
  const [token, setToken] = useState("");
  const [messages, setMessages] = useState<string[]>([]);

  const router = useRouter();

  useEffect(() => {
    handleGetLoadBoard();
    const userType = getCookie("usertype");
    const token = getCookie("token");

    setUserType(userType + "");
    setToken(token + "");

    console.log(userType);
    console.log(token);
    console.log(loadboards);
    console.log(loading);
    console.log(messages);
    handleRequestAndAccept();
  }, []);

  async function handleGetLoadBoard() {
    try {
      const token = getCookie("token");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/loadboards`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }
      const data = await response.json();
      const dataTypeed = data as responce;
      if (dataTypeed.error) {
        setErrors([dataTypeed.error]);
      } else {
        setLoadboards(dataTypeed.loadboard);
        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
      console.error("faq error:", error);
      console.error("faq error:", errors);
    }
  }

  const handleSmartSearchOnChange = (e: loadboard[]) => {
    if (e && e.length > 0) {
      setSelectedLoadboard(e[0]);
    }
    console.log(e);
  };



  // function formatCalendarDate(isoString: string): string {
  //   const date = new Date(isoString);
  //   // Check if the date is valid
  //   if (isNaN(date.getTime())) {
  //     return "N/A";
  //   }

  //   const month = [
  //     "Jan",
  //     "Feb",
  //     "Mar",
  //     "Apr",
  //     "May",
  //     "Jun",
  //     "Jul",
  //     "Aug",
  //     "Sep",
  //     "Oct",
  //     "Nov",
  //     "Dec",
  //   ];
  //   // Format as YYYY-MM-DD
  //   // Or use toLocaleDateString for a more readable format:

  //   const formattedDate = date.toLocaleDateString().split("T")[0].split("/");

  //   console.log(formattedDate);

  //   return (
  //     month[parseInt(formattedDate[0]) - 1] +
  //     "-" +
  //     formattedDate[1] +
  //     "-" +
  //     formattedDate[2]
  //   );
  //   // Or use toLocaleDateString for a more readable format:
  //   // return date.toLocaleDateString();
  // }

  const handleRequestAndAccept = async () => {
    if (!selectedLoadboard) return;

    console.log(userType);
    console.log(token);

    setErrors([]);

    try {
      //check if the user is logged in
      if (
        !token ||
        token === "" ||
        token === "undefined" ||
        token == "null" ||
        !isCookieValid("token")
      ) {
        console.error("User is not logged in or token is invalid.");
        router.push("/login");
        return;
      }

      if (userType == "carrier" && selectedLoadboard.type == "truck") {
        setErrors([
          "Sorry you can't proceed with this Action, as you are logged In as a Carrier",
        ]);
        return;
      }

      if (userType == "shiper" && selectedLoadboard.type == "load") {
        setErrors([
          "Sorry you can't proceed with this Action, as you are logged In as a Shipper",
        ]);
        return;
      }

      // Check if the selected loadboard is valid
      if (!selectedLoadboard.id) {
        console.error("Selected loadboard is invalid.");
        return;
      }

      if (errors.length == 0) {
        const formData = new globalThis.FormData();
        formData.append("account_id", selectedLoadboard.account_id + "");
        formData.append("contract_type", selectedLoadboard.type);
        formData.append("object_id", selectedLoadboard.id + "");
        formData.append(
          "description",
          `${selectedLoadboard.from_state} - ${selectedLoadboard.to_state} `
        );
        formData.append(
          "delivery_time",
          `${selectedLoadboard.date_lower_range} - ${selectedLoadboard.date_upper_range} `
        );
        formData.append(
          "payment",
          `${selectedLoadboard.price_upper_range} - ${selectedLoadboard.price_low_range} `
        );

        // Make the API call to request or accept the loadboard
        const response = await apiCall(
          token + "",
          `${BASE_URL}/contracts`,
          "POST",
          formData
        );

        if (!response.ok) {
          throw new Error(`Failed to request: ${response.status}`);
        }
        const data = await response.json();
        const dataTypeed = data as responce;
        if (dataTypeed.error) {
          console.error("Error in response:", dataTypeed.error);
          setErrors([dataTypeed.error]);
        } else {
          console.log("Request successful:", dataTypeed);
          setMessages(["Request successful!"]);
          // setTimeout(() => closeModal(), 1000);
        }
      }
    } catch (error) {
      console.error("Request error:", error);
    }
  };

 

  return (
  
        <SmartSearchInput onChange={(e) => handleSmartSearchOnChange(e)} />
 
  );
}
