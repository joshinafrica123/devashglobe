"use client"

import Link from "next/link";
import SmartSearchInput from "./globalsearchComponents";
import { loadboard } from "@/app/datatype/loadboards";
import { useState } from "react";
// import { useState } from "react";

export default  function Loadboard ()  {
  const [search, setSearch] = useState<loadboard[]>([]);
  // const [isVible, setIsVisible] = useState(true);

  const data = [
    { name: "Load A", type: "load", description: "Heavy goods transportation", image: "/assets/img/loads/1.jpeg" , from : "Accra", to:"Lagos" , map:"12233444,443343434" , company:"abc limited ", date:"24/5/2025" },
    { name: "Truck B", type: "truck", description: "Available for hire" , image: "/assets/img/trucks/1.jpeg",
      from : "Accra", to:"Lagos" , map:"12233444,443343434" , company:"abc limited ", date:"24/5/2025" },
    { name: "Load C", type: "load", description: "Fragile items" , image: "/assets/img/loads/2.avif",
      from : "Accra", to:"Lagos" , map:"12233444,443343434" , company:"abc limited ", date:"24/5/2025" },
    { name: "Truck D", type: "truck", description: "Long-haul service" , image: "/assets/img/trucks/2.jpeg",
      from : "Accra", to:"Lagos" , map:"12233444,443343434" , company:"abc limited ", date:"24/5/2025" 
     },
  ];

    const x = 5 ;

    if(x == 5 ) {
        console.log ("Hey 5 "+search)
    }else {
        console.log ("Hey 2 ")
    }

    // const submit = (e:Event) =>{
    //         e.preventDefault();

    //         setIsVisible(true);
    // }


  return (
    <>
    

        
                      <SmartSearchInput  onChange={(e)=>setSearch(e)} />

                        {/* Responsive Table */}
                            <div className="mt-6 p-6 bg-white text-black shadow-lg rounded-lg overflow-auto">
                                <h2 className="text-xl font-bold mb-4">Loadboard Table</h2>
                                <table className="w-full border-collapse border border-gray-300">
                                    <thead>
                                    <tr className="bg-[#D62D30] text-white">
                                        <th className="border p-2">Name</th>
                                        <th className="border p-2">Type</th>
                                        <th className="border p-2">From</th>
                                        <th className="border p-2">To</th>
                                        <th className="border p-2">Date</th>
                                        <th className="border p-2">Map</th>
                                        <th className="border p-2">Company </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {data.map((item, index) => (
                                        <tr key={index} className="border">
                                        <td className="border p-2">{item.name}</td>
                                        <td className="border p-2">{item.type.toUpperCase()}</td>
                                        <td className="border p-2">{item.from}</td>
                                        <td className="border p-2">{item.to}</td>
                                        <td className="border p-2">{item.date}</td>
                                        <td className="border p-2 text-center">
                                            {/* Map icon linking to Google Maps */}
                                            <Link
                                                href={`https://www.google.com/maps/search/${encodeURIComponent(item.name)}`}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="text-blue-500 hover:text-blue-700"
                                            >
                                                📍
                                            </Link> 
                                            </td>
                                        <td className="border p-2">{item.company}</td>
                                        </tr>
                                    ))}
                                    </tbody>
                                </table>
                            </div>
                    </> 


  );
};