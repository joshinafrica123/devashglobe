"use client";

import { useState } from "react";
import { BASE_URL } from "@/app/core/api";
import { validateEmail, validatePhone } from "@/app/core/util";
import { firstLetterCapitalized } from "@/app/datatype/frontEndCookiee";
// import AutocompleteComponent from "./autocompleteloadtruckComponents";
import GeneralLaodBoardTab from "./generalLoadBoarTabComponent";

export default function SearchForm({ title }: { title: string }) {
  const [freightData, setFreightData] = useState({
    type: "",
    size: "",
    name: "",
    phone: "",
    companyName: "",
    email: "",
    message: "",
  });
  const [errors, setErrors] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const today = new Date().toISOString().split("T")[0]; // YYYY-MM-D

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    console.log(name);
    setFreightData({ ...freightData, [name]: value });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors([]);
    console.log("Freight Data Submitted:", freightData);

    // Here you can add your API call to submit the freight data
    // check if the data is being logged correctly
    if (
      freightData.type &&
      freightData.email &&
      freightData.size &&
      freightData.message &&
      freightData.companyName &&
      freightData.name &&
      freightData.phone
    ) {
      console.log("Freight data is valid and ready to be submitted.");

      const errologs: string[] = [];

      const validateEmails = validateEmail(freightData.email);

      if (validateEmails.length > 0) {
        errologs.push(...validateEmails);
        setErrors(errologs);
        return;
      }

      const validatePhones = validatePhone(freightData.phone);
      if (validatePhones.length > 0) {
        errologs.push(...validatePhones);
        setErrors(errologs);
        return;
      }

      setLoading(true);

      // GET DATA FROR API
      const formData = new globalThis.FormData();
      formData.append("email", freightData.email);
      formData.append("type", freightData.type);
      formData.append("size", freightData.size);
      formData.append("name", freightData.name);
      formData.append("phone", freightData.phone);
      formData.append("companyName", freightData.companyName);
      formData.append("message", freightData.message);

      // Call your API function here
      resquestApi(formData);
    } else {
      console.log("Please fill in all required fields.");
      setErrors(["Please fill in all required fields."]);
    }
  };

  async function resquestApi(freightData: FormData): Promise<void> {
    try {
      const response = await fetch(`${BASE_URL}/contacts`, {
        method: "POST",
        body: freightData,
      });

      if (!response.ok) {
        setErrors([
          "Failed to submit freight request. Please try again later.",
        ]);
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      // Assuming the API returns a success message or data
      // set sussess message or handle the response as needed
      setSuccessMessage("Freight request submitted successfully!");
      // Handle the response data as needed
      console.log("Freight request submitted successfully:", data);
      setLoading(false);
    } catch (error) {
      console.error("Error submitting freight request:", error);
      setErrors(["Failed to submit freight request. Please try again later."]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-gradient-to-br from-gray-50 to-gray-100
     dark:from-gray-800 dark:to-gray-900 p-8 mb-10 rounded-2xl shadow-2xl w-full mx-auto relative overflow-hidden">
      {/* Decorative Gradient Circle */}
      <div className="absolute -top-16 -right-16 w-40 h-40 bg-[#D62D30]/20 rounded-full blur-3xl"></div>

      <h3 className="text-3xl font-extrabold text-[#06163A] dark:text-white text-left mb-6">
        <span className="text-[#D62D30]">{firstLetterCapitalized(title)}</span>
      </h3>

      {/* Alerts */}
      {errors.length > 0 && (
        <div className="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 rounded-lg mb-6 shadow-sm">
          <ul className="list-disc pl-5">
            {errors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}
      {successMessage && (
        <div className="bg-green-50 border-l-4 border-green-600 text-green-700 p-4 rounded-lg mb-6 shadow-sm">
          {successMessage}
        </div>
      )}

      <form className="space-y-6" onSubmit={handleSubmit}>
        {/* Name & Phone */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
              {title == "load" ? "Loading" : "Departure"}
            </label>
            <GeneralLaodBoardTab />
          </div>
          <div>
            <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
              {title == "load" ? "UnLoading" : "Destination"}
            </label>
            <GeneralLaodBoardTab />
          </div>
        </div>

        {/* Name & Phone */}
        <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
              From this Date
            </label>
            <input
              type="date"
              name="start_date"
              min={today}
              onChange={handleChange}
              value={today}
              className="w-full p-2 border rounded-md text-[#06163A]"
            />
          </div>
          <div>
            <label className="block text-gray-700 dark:text-gray-300 font-medium mb-1">
              Size(Tons(t))
            </label>
            <input
              onChange={handleChange}
              name="phone"
              type="number"
              className="w-full p-2 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-[#D62D30] focus:outline-none"
              required
            />
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading}
          className={`w-full py-3 rounded-lg font-semibold text-white shadow-md transition-all duration-300 transform hover:scale-[1.02]
        ${
          loading
            ? "bg-gray-400 cursor-not-allowed"
            : "bg-[#06163A] hover:bg-[#D62D30]"
        }`}
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <svg
                className="w-5 h-5 animate-spin"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8v8z"
                ></path>
              </svg>
              Search...
            </span>
          ) : (
            `Search for ${firstLetterCapitalized(title)}`
          )}
        </button>
      </form>
    </div>
  );
}
