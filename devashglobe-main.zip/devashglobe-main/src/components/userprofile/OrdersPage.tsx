import user from "@/app/datatype/user";
import React, { useState } from "react";
import { FaFilter, FaMapMarkerAlt, FaSearch } from "react-icons/fa";

// type OrderItem = {
//     id: string;
//     name: string;
//     quantity: number;
//     price: number; // cents or minor units
// };

// type Order = {
//     id: string;
//     createdAt: string; // ISO string
//     status: "pending" | "processing" | "shipped" | "completed" | "cancelled" | string;
//     total: number; // cents or minor units
//     items: OrderItem[];
// };

// type OrdersPageProps = {
//     userId?: string;
//     onSelectOrder?: (order: Order) => void;
//     // baseApi can be used to point to a custom backend during development/testing
//     baseApi?: string;
// };

export default function OrdersPage() {
  const [filter] = useState("All");
  const [sortAsc] = useState(true);
  const [search, setSearch] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  console.log(search);
  console.log(filterOpen);

  const [users] = useState<user[]>([]);

  const filteredUsers = users
    ?.filter((user) => filter === "All" || user.status === filter)
    .sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

  const [currentPage, setCurrentPage] = useState(1);
  const usersPerPage = 10;
  const indexOfLast = currentPage * usersPerPage;
  const indexOfFirst = indexOfLast - usersPerPage;
  const currentContracts = filteredUsers?.slice(indexOfFirst, indexOfLast);

  // const [orders, setOrders] = useState<Order[] | null>(null);
  // const [loading, setLoading] = useState<boolean>(false);
  // const [error, setError] = useState<string | null>(null);

  // useEffect(() => {
  //     const controller = new AbortController();
  //     const fetchOrders = async () => {
  //         setLoading(true);
  //         setError(null);

  //         const s: Order[] = [
  //             {
  //                 id:"dtzcf",
  //                 createdAt:"23-45-2344",
  //                 status: "pending",
  //                 total:34,
  //                 items:[]
  //             },
  //             {
  //                 id:"dtzcf",
  //                 createdAt:"23-45-2344",
  //                 status: "pending",
  //                 total:34,
  //                 items:[]
  //             }
  //         ]
  //         setOrders(s);
  //         setLoading(false)
  //         // Default endpoints:
  //         // - If userId provided: /api/users/[userId]/orders
  //         // - Otherwise: /api/orders
  //         // const endpoint = userId ? `${baseApi}/api/users/${encodeURIComponent(userId)}/orders` : `${baseApi}/api/orders`;

  //         // try {
  //         //     const res = await fetch(endpoint, { signal: controller.signal, headers: { "Content-Type": "application/json" } });
  //         //     if (!res.ok) {
  //         //         const text = await res.text().catch(() => null);
  //         //         throw new Error(text || `Request failed: ${res.status}`);
  //         //     }
  //         //     const data = (await res.json()) as Order[] | { orders: Order[] };
  //         //     // Support APIs that return { orders: [...] } or the raw array
  //         //     const parsed = Array.isArray(data) ? data : ("orders" in data ? data.orders : []);
  //         //     setOrders(parsed);
  //         // } catch (err) {
  //         //     console.error("Error fetching orders:", err);
  //         //     setError(err instanceof Error ? err.message : "Failed to load orders");
  //         //     // if (err.name === "AbortError") return;
  //         //     // setError(err?.message ?? "Failed to load orders");
  //         // } finally {
  //         //     setLoading(false);
  //         // }
  //     };

  //     fetchOrders();
  //     return () => controller.abort();
  // }, [userId, baseApi]);

  // const formatCurrency = (minorUnits: number) => {
  //     // Assumes minor units (e.g., cents). Adjust locale/currency as needed.
  //     return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(minorUnits / 100);
  // };

  // if (loading) {
  //     return <div>Loading orders…</div>;
  // }

  // if (error) {
  //     return <div role="alert">Error loading orders: {error}</div>;
  // }

  // if (!orders || orders.length === 0) {
  //     return <div>No orders found.</div>;
  // }
  //   const handleRowClick = (userId: number) => {
  //     console.log("Row clicked for user ID:", userId);
  //     // Implement further actions, e.g., open a detail view
  //   };

  return (
    // <div>
    //     <h2>Your Orders</h2>
    //     <ul style={{ listStyle: "none", padding: 0 }}>
    //         {orders.map((order) => (
    //             <li
    //                 key={order.id}
    //                 style={{
    //                     border: "1px solid #e5e7eb",
    //                     borderRadius: 6,
    //                     padding: 12,
    //                     marginBottom: 12,
    //                     display: "flex",
    //                     justifyContent: "space-between",
    //                     alignItems: "flex-start",
    //                 }}
    //             >
    //                 <div style={{ flex: 1 }}>
    //                     <div style={{ display: "flex", gap: 12, alignItems: "baseline", marginBottom: 6 }}>
    //                         <strong>Order #{order.id}</strong>
    //                         <small style={{ color: "#6b7280" }}>{new Date(order.createdAt).toLocaleString()}</small>
    //                         <span
    //                             style={{
    //                                 marginLeft: 8,
    //                                 padding: "2px 8px",
    //                                 borderRadius: 9999,
    //                                 background: order.status === "completed" ? "#def7ec" : order.status === "cancelled" ? "#fce7f3" : "#eef2ff",
    //                                 color: "#111827",
    //                                 fontSize: 12,
    //                             }}
    //                         >
    //                             {order.status}
    //                         </span>
    //                     </div>

    //                     <div style={{ color: "#374151", marginBottom: 8 }}>
    //                         {order.items.map((it) => (
    //                             <div key={it.id} style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
    //                                 <div>
    //                                     {it.name} <small style={{ color: "#6b7280" }}>×{it.quantity}</small>
    //                                 </div>
    //                                 <div style={{ color: "#111827" }}>{formatCurrency(it.price * it.quantity)}</div>
    //                             </div>
    //                         ))}
    //                     </div>
    //                 </div>

    //                 <div style={{ textAlign: "right", marginLeft: 16 }}>
    //                     <div style={{ fontWeight: 600 }}>{formatCurrency(order.total)}</div>
    //                     <button
    //                         onClick={() => onSelectOrder?.(order)}
    //                         style={{
    //                             marginTop: 8,
    //                             background: "#111827",
    //                             color: "white",
    //                             border: "none",
    //                             padding: "6px 10px",
    //                             borderRadius: 6,
    //                             cursor: "pointer",
    //                         }}
    //                         type="button"
    //                     >
    //                         View
    //                     </button>
    //                 </div>
    //             </li>
    //         ))}
    //     </ul>
    // </div>
    <div>
      {/* Smart Contracts Table */}
      <div className="bg-white dark:bg-[#06163A] shadow border border-[#CBD5E1] rounded-xl p-5 w-full mt-10">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-5 gap-3">
          <div>
            <h2 className="text-lg font-semibold text-[#06163A] dark:text-white">
              User Accounts
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-300 mt-1">
              Manage who has access
            </p>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-3 w-full sm:w-auto">
            {/* SEARCH */}
            <div className="relative w-full sm:w-64">
              <FaSearch className="absolute left-2 top-2.5 text-[#8C8C8C] text-sm" />
              <input
                type="text"
                placeholder="Search..."
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-sm rounded-md border dark:bg-[#112244] text-gray-700 dark:text-white outline-none"
              />
            </div>

            {/* FILTER */}
            <button
              onClick={() => setFilterOpen(true)}
              className="p-2 rounded-md bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white hover:bg-gray-200 dark:hover:bg-[#0b1f41]"
            >
              <FaFilter />
            </button>
          </div>
        </div>

        {/* TABLE */}
        <div className="overflow-x-auto">
          <table className="min-w-[700px] w-full text-sm text-left border-collapse">
            <thead className="bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white">
              <tr>
                <th className="py-2 px-3">Date</th>
                <th className="py-2 px-3">Name</th>
                <th className="py-2 px-3 hidden sm:table-cell">Email</th>
                <th className="py-2 px-3">Location</th>
              </tr>
            </thead>

            <tbody>
              {currentContracts?.map((contract) => (
                <tr
                  key={contract.id}
                  className="border-b hover:bg-gray-50 dark:hover:bg-[#0b1f41]"
                >
                  <td className="py-3 px-3">
                    {new Date(contract.date).toDateString()}
                  </td>
                  <td className="py-3 px-3">
                    {contract.first_name} {contract.last_name}
                  </td>
                  <td className="py-3 px-3 hidden sm:table-cell">
                    {contract.email}
                  </td>
                  <td className="py-3 px-3 flex items-center gap-1">
                    <FaMapMarkerAlt className="text-[#D62D30]" />
                    <span>{contract.first_name}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination Controls */}
      <div className="flex flex-wrap justify-center mt-4 gap-2">
        {Array.from(
          { length: Math.ceil(users.length / usersPerPage) },
          (_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPage(i + 1)}
              className={`px-3 py-1 rounded text-sm ${
                currentPage === i + 1
                  ? "bg-[#D62D30] text-white"
                  : "bg-gray-200 dark:bg-gray-600 dark:text-white"
              }`}
            >
              {i + 1}
            </button>
          )
        )}
      </div>
    </div>
  );
}
