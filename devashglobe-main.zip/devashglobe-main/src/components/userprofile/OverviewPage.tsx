import React from "react";
import Image from "next/image";
import Link from "next/link";

export default function OverviewPage() {
  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div>
        <h4 className="text-xl font-semibold text-gray-900 dark:text-white">
          Account
        </h4>
        <p className="text-gray-600 dark:text-gray-300">
          Update information about your profile
        </p>
      </div>

      {/* Profile Overview */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <Image
            src="/assets/img/users/2.jpg"
            alt="Profile"
            width={110}
            height={110}
            className="rounded-full border-4 border-[#D62D30]"
          />

          <button className="bg-white text-[#01245A] px-6 py-2 border border-[#01245A] rounded hover:bg-[#01245A] hover:text-white transition">
            Change Picture
          </button>
        </div>
      </div>

      {/* Account Info */}
      <div className="bg-white dark:bg-gray-800 p-4 md:p-6 rounded-lg">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { label: "Full Name", value: "Ashglobe Admin", type: "text" },
            {
              label: "Email Address",
              value: "ashglobe@example.com",
              type: "email",
            },
            { label: "Phone Number", value: "+234 800 123 4567", type: "tel" },
            { label: "Location", value: "Accra, Ghana", type: "text" },
            { label: "Date of Birth", value: "1995-01-01", type: "date" },
            { label: "Password", value: "password", type: "password" },
          ].map((item, idx) => (
            <div key={idx} className="flex flex-col gap-1">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {item.label}
              </label>
              <input
                type={item.type}
                defaultValue={item.value}
                className="p-2 border border-gray-300 dark:border-gray-700 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
          ))}
        </div>

        {/* Reset Password */}
        <div className="flex justify-end mt-4">
          <Link
            href="#"
            className="text-[#007BFF] border-b-2 border-[#007BFF] text-sm"
          >
            Reset Password
          </Link>
        </div>
      </div>

      {/* Security / Delete Section */}
      <div className="bg-white dark:bg-gray-800 p-4 md:p-6 rounded-lg border border-red-300 flex flex-col md:flex-row gap-4 md:items-center md:justify-between">
        <div>
          <h5 className="text-lg font-semibold text-red-600">
            Enable Authenticator App
          </h5>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Add an extra layer of security to your account by linking an
            authenticator app.
          </p>
        </div>

        <button className="bg-[#D62D2D26] text-[#D80027] px-6 py-2 rounded text-sm hover:bg-red-700 hover:text-white transition">
          Remove Authentication
        </button>
      </div>
    </div>
  );
}
