import React, { useState } from "react";

export default function NotificationsPage() {
  const [pushSettings, setPushSettings] = useState({
    reminders: true,
    messengers: false,
  });

  const Toggle = ({
    enabled,
    onChange,
  }: {
    enabled: boolean;
    onChange: () => void;
  }) => (
    <button
      onClick={onChange}
      className={`relative w-12 h-7 rounded-full transition-colors duration-300
      ${enabled ? "bg-[#01245A]" : "bg-gray-300 dark:bg-gray-600"}`}
    >
      <span
        className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform duration-300
        ${enabled ? "translate-x-5" : ""}`}
      />
    </button>
  );

  const [emailSettings, setEmailSettings] = useState({
    news: true,
    feedback: false,
    reminders: true,
    updates: false,
  });

  return (
    <div className="p-5 space-y-10 font-sans">
      {/* HEADER */}
      <div>
        <h2 className="text-lg font-semibold text-[#06163A] dark:text-white">
          Notifications
        </h2>
        <p className="text-sm text-gray-500 dark:text-gray-300 mt-1">
          Get notified on what’s happening.
        </p>
      </div>

      {/* PUSH NOTIFICATIONS */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold text-[#06163A] dark:text-white">
            Push Notifications
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-300 mt-1">
            Get instant updates and stay on track with real-time alerts.
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 space-y-4 shadow-sm">
          {[
            { key: "reminders", label: "Reminders and Alerts" },
            { key: "messengers", label: "Messengers" },
          ].map(({ key, label }) => (
            <div key={key} className="flex items-center justify-between gap-4">
              <div>
                <h5 className="text-sm font-medium text-gray-800 dark:text-white">
                  {label}
                </h5>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Manage {label.toLowerCase()}
                </p>
              </div>
              <Toggle
                enabled={pushSettings[key as keyof typeof pushSettings]}
                onChange={() =>
                  setPushSettings((prev) => ({
                    ...prev,
                    [key]: !prev[key as keyof typeof pushSettings],
                  }))
                }
              />
            </div>
          ))}
        </div>
      </section>

      {/* EMAIL NOTIFICATIONS */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold text-[#06163A] dark:text-white">
            Email Notifications
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-300 mt-1">
            Stay informed with updates delivered straight to your inbox.
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 space-y-4 shadow-sm">
          {[
            { key: "news", label: "News and Updates" },
            { key: "feedback", label: "Client Feedback" },
            { key: "reminders", label: "Reminders and Alerts" },
            { key: "updates", label: "System Updates" },
          ].map(({ key, label }) => (
            <div key={key} className="flex items-center justify-between gap-4">
              <div>
                <h5 className="text-sm font-medium text-gray-800 dark:text-white">
                  {label}
                </h5>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Receive {label.toLowerCase()}
                </p>
              </div>
              <Toggle
                enabled={emailSettings[key as keyof typeof emailSettings]}
                onChange={() =>
                  setEmailSettings((prev) => ({
                    ...prev,
                    [key]: !prev[key as keyof typeof emailSettings],
                  }))
                }
              />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
