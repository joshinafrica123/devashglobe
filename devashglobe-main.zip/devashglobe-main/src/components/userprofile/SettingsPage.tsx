import user from "@/app/datatype/user";
import React, { useState } from "react";
import { FaDownload, FaFilter, FaMapMarkerAlt, FaSearch } from "react-icons/fa";

// type OrderItem = {
//     id: string;
//     name: string;
//     quantity: number;
//     price: number; // cents or minor units
// };

// type Order = {
//     id: string;
//     createdAt: string; // ISO string
//     status: "pending" | "processing" | "shipped" | "completed" | "cancelled" | string;
//     total: number; // cents or minor units
//     items: OrderItem[];
// };

// type OrdersPageProps = {
//     userId?: string;
//     onSelectOrder?: (order: Order) => void;
//     // baseApi can be used to point to a custom backend during development/testing
//     baseApi?: string;
// };

export default function SettingsPage() {
  const [filter] = useState("All");
  const [sortAsc] = useState(true);
  const [search, setSearch] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  console.log(search);
  console.log(filterOpen);

  const [users] = useState<user[]>([]);

  const filteredUsers = users
    ?.filter((user) => filter === "All" || user.status === filter)
    .sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

  const [currentPage, setCurrentPage] = useState(1);
  const usersPerPage = 10;
  const indexOfLast = currentPage * usersPerPage;
  const indexOfFirst = indexOfLast - usersPerPage;
  const currentContracts = filteredUsers?.slice(indexOfFirst, indexOfLast);

  // const [orders, setOrders] = useState<Order[] | null>(null);
  // const [loading, setLoading] = useState<boolean>(false);
  // const [error, setError] = useState<string | null>(null);

  // useEffect(() => {
  //     const controller = new AbortController();
  //     const fetchOrders = async () => {
  //         setLoading(true);
  //         setError(null);

  //         const s: Order[] = [
  //             {
  //                 id:"dtzcf",
  //                 createdAt:"23-45-2344",
  //                 status: "pending",
  //                 total:34,
  //                 items:[]
  //             },
  //             {
  //                 id:"dtzcf",
  //                 createdAt:"23-45-2344",
  //                 status: "pending",
  //                 total:34,
  //                 items:[]
  //             }
  //         ]
  //         setOrders(s);
  //         setLoading(false)
  //         // Default endpoints:
  //         // - If userId provided: /api/users/[userId]/orders
  //         // - Otherwise: /api/orders
  //         // const endpoint = userId ? `${baseApi}/api/users/${encodeURIComponent(userId)}/orders` : `${baseApi}/api/orders`;

  //         // try {
  //         //     const res = await fetch(endpoint, { signal: controller.signal, headers: { "Content-Type": "application/json" } });
  //         //     if (!res.ok) {
  //         //         const text = await res.text().catch(() => null);
  //         //         throw new Error(text || `Request failed: ${res.status}`);
  //         //     }
  //         //     const data = (await res.json()) as Order[] | { orders: Order[] };
  //         //     // Support APIs that return { orders: [...] } or the raw array
  //         //     const parsed = Array.isArray(data) ? data : ("orders" in data ? data.orders : []);
  //         //     setOrders(parsed);
  //         // } catch (err) {
  //         //     console.error("Error fetching orders:", err);
  //         //     setError(err instanceof Error ? err.message : "Failed to load orders");
  //         //     // if (err.name === "AbortError") return;
  //         //     // setError(err?.message ?? "Failed to load orders");
  //         // } finally {
  //         //     setLoading(false);
  //         // }
  //     };

  //     fetchOrders();
  //     return () => controller.abort();
  // }, [userId, baseApi]);

  // const formatCurrency = (minorUnits: number) => {
  //     // Assumes minor units (e.g., cents). Adjust locale/currency as needed.
  //     return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(minorUnits / 100);
  // };

  // if (loading) {
  //     return <div>Loading orders…</div>;
  // }

  // if (error) {
  //     return <div role="alert">Error loading orders: {error}</div>;
  // }

  // if (!orders || orders.length === 0) {
  //     return <div>No orders found.</div>;
  // }
  const handleRowClick = (userId: number) => {
    console.log("Row clicked for user ID:", userId);
    // Implement further actions, e.g., open a detail view
  };

  return (
    // <div>
    //     <h2>Your Orders</h2>
    //     <ul style={{ listStyle: "none", padding: 0 }}>
    //         {orders.map((order) => (
    //             <li
    //                 key={order.id}
    //                 style={{
    //                     border: "1px solid #e5e7eb",
    //                     borderRadius: 6,
    //                     padding: 12,
    //                     marginBottom: 12,
    //                     display: "flex",
    //                     justifyContent: "space-between",
    //                     alignItems: "flex-start",
    //                 }}
    //             >
    //                 <div style={{ flex: 1 }}>
    //                     <div style={{ display: "flex", gap: 12, alignItems: "baseline", marginBottom: 6 }}>
    //                         <strong>Order #{order.id}</strong>
    //                         <small style={{ color: "#6b7280" }}>{new Date(order.createdAt).toLocaleString()}</small>
    //                         <span
    //                             style={{
    //                                 marginLeft: 8,
    //                                 padding: "2px 8px",
    //                                 borderRadius: 9999,
    //                                 background: order.status === "completed" ? "#def7ec" : order.status === "cancelled" ? "#fce7f3" : "#eef2ff",
    //                                 color: "#111827",
    //                                 fontSize: 12,
    //                             }}
    //                         >
    //                             {order.status}
    //                         </span>
    //                     </div>

    //                     <div style={{ color: "#374151", marginBottom: 8 }}>
    //                         {order.items.map((it) => (
    //                             <div key={it.id} style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
    //                                 <div>
    //                                     {it.name} <small style={{ color: "#6b7280" }}>×{it.quantity}</small>
    //                                 </div>
    //                                 <div style={{ color: "#111827" }}>{formatCurrency(it.price * it.quantity)}</div>
    //                             </div>
    //                         ))}
    //                     </div>
    //                 </div>

    //                 <div style={{ textAlign: "right", marginLeft: 16 }}>
    //                     <div style={{ fontWeight: 600 }}>{formatCurrency(order.total)}</div>
    //                     <button
    //                         onClick={() => onSelectOrder?.(order)}
    //                         style={{
    //                             marginTop: 8,
    //                             background: "#111827",
    //                             color: "white",
    //                             border: "none",
    //                             padding: "6px 10px",
    //                             borderRadius: 6,
    //                             cursor: "pointer",
    //                         }}
    //                         type="button"
    //                     >
    //                         View
    //                     </button>
    //                 </div>
    //             </li>
    //         ))}
    //     </ul>
    // </div>
    <div>
      {/* Smart Contracts Table */}
      <div className="bg-white dark:bg-[#06163A] shadow border border-[#CBD5E1] rounded-xl p-5 w-full mt-10">
        {/* TOP BAR — TITLE + SUBTITLE + CONTROLS */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h2 className="text-lg font-semibold text-[#06163A] dark:text-white">
              Audit Logs
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-300">
              Manage who has access
            </p>
          </div>

          <button className="flex items-center gap-2 border border-[#01245A] text-[#4D4DA2] px-4 py-2 rounded-md hover:bg-gray-100 dark:hover:bg-[#0b1f41] transition w-full sm:w-auto">
            <FaDownload className="text-sm" />
            Export
          </button>
        </div>

        {/* TOP BAR — TITLE + SUBTITLE + CONTROLS */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
          {/* Search */}
          <div className="relative w-full sm:w-72">
            <FaSearch className="absolute left-3 top-3 text-gray-400 text-sm" />
            <input
              type="text"
              placeholder="Search users"
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg  dark:bg-[#112244] border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-white outline-none"
            />
          </div>

          {/* Filter */}
          <button
            onClick={() => setFilterOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-md border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-[#0b1f41] transition w-full sm:w-auto"
          >
            <FaFilter className="text-sm" />
            Filter
          </button>
        </div>

        {/* TABLE */}
        <div className="overflow-x-auto">
          <table className="min-w-[700px] w-full text-sm text-left">
            <thead className="bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white">
              <tr>
                <th className="py-2 px-3">Time</th>
                <th className="py-2 px-3">User</th>
                {/* <th
                  className="py-2 px-3 cursor-pointer hover:text-[#D62D30]"
                  // onClick={() => setSortAsc(!sortAsc)}
                >
                  Registration Date {sortAsc ? "↑" : "↓"}
                </th> */}
                <th className="py-2 px-3">Action</th>
                <th className="py-2 px-3">Details</th>
                {/* <th className="py-2 px-3">Amount</th> */}
                {/* <th className="py-2 px-3">Status</th> */}

                {/* <th className="py-2 px-3" onClick={() => setFilter("All")}>
                              Location
                            </th>
                            <th className="py-2 px-3">Price</th>  */}
                {/* <th className="py-2 px-3">Status</th> */}
              </tr>
            </thead>

            <tbody className="text-gray-700 dark:text-gray-200">
              {currentContracts?.map((contract) => (
                <tr
                  key={contract.id}
                  onClick={() => handleRowClick(contract.id)}
                  className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-[#0b1f41] cursor-pointer"
                >
                  <td className="py-3 px-3 whitespace-nowrap">
                    {new Date(contract.date).toLocaleString()}
                  </td>
                  <td className="py-3 px-3">
                    {contract.first_name} {contract.last_name}
                  </td>
                  <td className="py-3 px-3 truncate max-w-[200px]">
                    {contract.email}
                  </td>
                  <td className="py-3 px-3 flex items-center gap-1 whitespace-nowrap">
                    <FaMapMarkerAlt className="text-[#D62D30]" />
                    <span>{contract.first_name}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredUsers.length === 0 && (
            <div className="text-center text-sm text-gray-500 py-6">
              No audit logs found.
            </div>
          )}
        </div>
      </div>

      {/* Pagination Controls */}
      <div className="flex flex-wrap justify-center mt-6 gap-2">
        {Array.from(
          { length: Math.ceil(users.length / usersPerPage) },
          (_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPage(i + 1)}
              className={`px-3 py-1 rounded text-sm ${
                currentPage === i + 1
                  ? "bg-[#D62D30] text-white"
                  : "bg-gray-200 dark:bg-gray-600 dark:text-white"
              }`}
            >
              {i + 1}
            </button>
          )
        )}
      </div>
    </div>
  );
}
