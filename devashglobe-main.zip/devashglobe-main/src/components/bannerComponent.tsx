"use client"

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";

interface bannerArguments {
  backgroudImage:string,
  pageTitle:string , 
  bannerImage : string
}

export default function BannerComponent ( bannerArguments : bannerArguments ) {

    return (

        <section
                    className="relative bg-cover bg-right py-70"
                    style={{ backgroundImage: `url(${bannerArguments.backgroudImage})` }}
                  >
             
                    <div className="container mx-auto relative z-10 text-center">

                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 1.5 }}
                      > 

                        <h2 className="text-4xl font-bold text-white">{bannerArguments.pageTitle}</h2>
                        <div className="flex justify-center mt-4">
                          <ul className="flex space-x-2 text-white text-lg">
                            <li>
                              <Link href="/" className="hover:text-gray-300">Home</Link>
                            </li>
                            <li className="text-gray-300">/</li>
                            <li>{bannerArguments.pageTitle}</li>
                          </ul>
                        </div>

                    </motion.div>

                    </div>
                    <div className="absolute bottom-18.5  left-0 w-50 h-50">

                    <motion.div
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 2 }}
                      > 

                        <Image
                          src={bannerArguments.bannerImage}
                          alt="Shape"
                          width={800}
                          height={800}
                          className="opacity-80"
                        />

                     </motion.div>

                    </div>
        </section>
        
    )
}