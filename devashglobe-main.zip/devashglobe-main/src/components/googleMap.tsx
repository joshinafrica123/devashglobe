export default function GoogleMap ()  {
    return (
    <div className="relative w-full h-0 pb-[56.25%] overflow-hidden rounded-lg shadow-lg">
      <iframe
        className="absolute top-0 left-0 w-full h-full border-0"
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3971.1378223487354!2d-0.34493382601651335!3d5.546574994433738!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdfbd295e345f03%3A0x829f74aa449e881b!2sLS%20GNR%20Exclusive%20Boutique!5e0!3m2!1sen!2sgh!4v1742822259493!5m2!1sen!2sgh"
        allowFullScreen
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      ></iframe>
    </div>
    );
  };
  
