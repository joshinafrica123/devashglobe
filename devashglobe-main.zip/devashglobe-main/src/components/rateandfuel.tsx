import Link from "next/link";
import { Fuel, ArrowLeftRight } from "lucide-react";

export default function ShortLinks() {
  return (
    <div className="bg-gradient-to-r from-[#D62D30] to-[#06163A] py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-wrap justify-center gap-8">
          {/* Diesel Price */}
          <div className="w-full sm:w-1/2 lg:w-1/3">
            <Link
              href="/worldfuelprice"
              className="flex flex-col items-center text-center rounded-xl border border-red-300 bg-white shadow-md hover:shadow-lg transition p-6"
            >
              <Fuel className="w-10 h-10 text-red-600 mb-3" />
              <h3 className="text-lg font-semibold text-gray-800">
                Petrol & Diesel price
              </h3>
              <p className="text-sm text-gray-500 truncate">
                Find out the price of fuels in Europe
              </p>
            </Link>
          </div>

          {/* Currency Converter */}
          <div className="w-full sm:w-1/2 lg:w-1/3">
            <Link
              href="/worldexchangerates"
              className="flex flex-col items-center text-center rounded-xl border border-red-300 bg-white shadow-md hover:shadow-lg transition p-6"
            >
              <ArrowLeftRight className="w-10 h-10 text-red-600 mb-3" />
              <h3 className="text-lg font-semibold text-gray-800">
                Currency convertor
              </h3>
              <p className="text-sm text-gray-500 truncate">
                At the exchange rate of the National Bank
              </p>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
