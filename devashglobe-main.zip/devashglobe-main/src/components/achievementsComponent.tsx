"use client";

import { FiUsers, FiCheckCircle, FiLock } from "react-icons/fi";
import { motion } from "framer-motion";
import React, { useEffect, useState } from "react";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { apiCall, BASE_URL } from "@/app/core/api";
import responce from "@/app/datatype/response";

export default function Achievements() {
  const [counts, setCounts] = useState({
    contracts: 0,
    openContracts: 0,
    users: 0,
  });
  const [errors, setErrors] = useState<string[]>([]);

  const achievements = [
    { label: "Closed Contracts", count: 1200, icon: FiLock, type: "contracts" },
    {
      label: "Open Contracts",
      count: 340,
      icon: FiCheckCircle,
      type: "openContracts",
    },
    { label: "Active Users", count: 5000, icon: FiUsers, type: "users" },
  ];

  useEffect(() => {
    handleGetUser();
  }, []);

  async function handleGetUser() {
    try {
      // get logged in user token
      const token = getCookie("token");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/users`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }

      const data = await response.json();
      console.log(data);

      const dataTypeed = data as responce;

      if (dataTypeed.error) {
        const errList: string[] = [dataTypeed?.error];
        setErrors(errList);
      } else {
        console.log(dataTypeed.user);

        /**setCounts((b) =>({
                        contracts: Math.min(b.contracts + 10, 2000),
                        openContracts: Math.min(b.openContracts + 5, 340),
                          users: Math.min(b.users + 50, dataTypeed.user?.length),
                    }) );**/

        setInterval(() => {
          setCounts((prevCounts) => ({
            contracts: Math.min(prevCounts.contracts + 10, 20000),
            openContracts: Math.min(prevCounts.openContracts + 5, 340),
            users: Math.min(prevCounts.users + 50, dataTypeed.user?.length),
          }));
        }, 50);

        //   clearInterval(interval);
      }
    } catch (error) {
      console.error("equipment error:", error);
      console.error("equipment error:", errors);
    }
  }

  return (
    <section className="py-20 bg-gradient-to-r from-[#D62D30] to-[#06163A] text-white">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          Our Achievements
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {achievements?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.3, duration: 0.6 }}
              whileHover={{ scale: 1.05 }}
              className="p-8 rounded-2xl bg-white/10 backdrop-blur-lg shadow-lg text-center"
            >
              {React.createElement(item.icon, {
                className: "text-5xl text-[#D62D30] mx-auto mb-4",
              })}
              <h3 className="text-4xl font-extrabold">
                {i == 0
                  ? counts.contracts
                  : i == 1
                  ? counts.openContracts
                  : i == 2
                  ? counts.users
                  : "1"}
                +
              </h3>
              <p className="mt-2 text-lg text-gray-300">{item.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
