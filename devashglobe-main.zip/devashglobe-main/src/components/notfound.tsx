import Head from 'next/head';
import Image from 'next/image';

const NoSearchFound = ({title}:{title:string}) => {
  return (
    <>
      <Head>
        <title>Not Found</title>
      </Head>

      <div className="flex flex-col items-center justify-self-auto min-h-screen text-center text-gray-800 m-auto">
        <h1 className="text-2xl font-extrabold sm:text-5xl md:text-6xl mb-4 mt-10">
          {title}
        </h1>
        
        
        {/* Replace the src with your desired image path */}
        <div className="w-80 h-auto">
            <Image
                src={"/assets/img/on-search.png"}
                alt="No merchant found"
                width={320}
                height={320}
                className="object-contain"
            />
        </div>
      </div>
    </>
  );
};

export default NoSearchFound;