"use client";

import { useState } from "react";
import SearchForm from "./shortsearchComponent";

export default function HomeLoadTrckSearch() {
  const [activeTab, setActiveTab] = useState<"load" | "truck">("load");

  return (
    <div className="max-w-6xl mx-auto px-4">
      {/* Mobile Tabs */}
      <div className=" mb-4 flex border-b border-gray-200 dark:border-gray-700">
        <button
          onClick={() => setActiveTab("load")}
          className={`flex-1 py-2 text-center font-medium ${
            activeTab === "load"
              ? "border-b-2 border-[#D62D30] text-[#D62D30]"
              : "text-gray-500"
          }`}
        >
          Load
        </button>
        <button
          onClick={() => setActiveTab("truck")}
          className={`flex-1 py-2 text-center font-medium ${
            activeTab === "truck"
              ? "border-b-2 border-[#D62D30] text-[#D62D30]"
              : "text-gray-500"
          }`}
        >
          Truck
        </button>
      </div>

      {/* Content */}
      {/* md:grid-cols-2 */}
      <div className="grid grid-cols-1  gap-6 items-stretch">
        {/* Mobile: show only active tab */}
        {/* <div className="md:block hidden">
          <SearchForm title="load" />
        </div>
        <div className="md:block hidden">
          <SearchForm title="truck" />
        </div> */}

        {/* Mobile active content */}
        <div className="">
          {activeTab === "load" && <SearchForm title="load" />}
          {activeTab === "truck" && <SearchForm title="truck" />}
        </div>
      </div>
    </div>
  );
}
