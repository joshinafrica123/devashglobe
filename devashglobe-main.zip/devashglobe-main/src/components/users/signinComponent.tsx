"use client";


import { BASE_URL } from '@/app/core/api';
import {setCookie } from '@/app/datatype/frontEndCookiee';
import responce from '@/app/datatype/response';
// import users from '@/app/datatype/users';
import { useRouter} from 'next/navigation';
import React, { useState } from "react";

interface FormData {
  email: string;
  password: string;
}

export default function SignUpForm() {
  const [form, setForm] = useState<FormData>({
    email: "",
    password: ""
  });

  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [loading,setLoading] = useState(false);

  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const validatePassword = (password: string): string[] => {
    const errorList: string[] = [];
    if (password.length < 8) errorList.push("Minimum 8 characters required.");
    if (!/[A-Z]/.test(password)) errorList.push("At least one uppercase letter required.");
    if (!/[0-9]/.test(password)) errorList.push("At least one number required.");
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) errorList.push("At least one special character required.");
    return errorList;
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validationErrors = validatePassword(form.password);
   
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
    } else {
      setErrors([]);
      console.log("Signing up:", form);
      // Submit your API call here
      loginUser(form);
    }
  };



async function loginUser(form: FormData): Promise<void> {
  try {

    const formData = new globalThis.FormData();
    formData.append('email', form.email);
    formData.append('password', form.password);

    setLoading(true);

    console.log(BASE_URL)

    const response = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      body: formData, // FormData handles content-type automatically
    });

    if (!response.ok) {
      throw new Error(`Failed to register: ${response.status}`);
    }

    const data = await response.json();
    const dataTypeed = (data as responce);
    if(dataTypeed.error){
      const errList : string[] = [dataTypeed.error]
      setErrors(errList);
    }else{

    console.log('Registered user:', (data as responce).token);
    console.log('Registered user:', (data as responce).user);
  
    // Set cookie (expires in 1 day)
    setCookie(data,'signin','','','');

    setLoading(false)
// Read cookie
//const allCookies = document.cookie; // returns "token=abc123; theme=dark"
    router.push('/users');
   }

  } catch (error) {
    console.error('Registration error:', error);
    if((error as responce).error){
    const errList : string [] = [(error as responce).error]
    setErrors(errList);
    }
  }
}




  return (
    <>
      <form
        onSubmit={handleSubmit}
        className="max-w-md mx-auto p-6 bg-gradient-to-br from-gray-50 to-gray-100  bg-[#D62D30]/20 shadow-2xl dark:bg-gray-900  rounded-xl space-y-4 w-full"
      >
        <h2 className="text-2xl font-bold text-center text-[#06163A] dark:text-white">Sign In</h2>

        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          className="w-full p-2 border rounded focus:outline-none dark:bg-gray-800 dark:text-white"
          required
        />

        {/* Password Field */}
        <div className="relative">
          <input
            type={showPassword ? "text" : "password"}
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            className="w-full p-2 border rounded focus:outline-none dark:bg-gray-800 dark:text-white"
            required
          />
          <button
            type="button"
            onClick={togglePasswordVisibility}
            className="absolute right-2 top-2 text-sm text-blue-600 dark:text-blue-300"
          >
            {showPassword ? "Hide" : "Show"}
          </button>
        </div>


        {/* Display Errors */}
        {errors.length > 0 && (
          <div className="text-sm text-red-600 dark:text-red-400 space-y-1">
            {errors.map((err, index) => (
              <p key={index}>• {err}</p>
            ))}
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-[#06163A] text-white py-2 rounded hover:bg-blue-900 transition"
        >
          {
            loading ? "Logging In..":"Log In"
          }

        </button>

        <div className="text-center text-sm mt-4">
          Not yet a member?{" "}
          <a href="/joinus" className="text-[#D62D30] hover:underline font-medium">
            Sign Up
          </a>
        </div>

      </form>
      
    </>
  );
}
