"use client";

import { Country, COUNTRY_CODES } from '@/app/datatype/countryCode';
import { useState, useRef, useEffect } from 'react';


/**interface Country {
  id:string;
  code: string;
  country: string;
  flag: string;
  maxLenght:number;
}***/

interface CountryPhoneInputProps {
  onCountryChange?: (country: Country) => void;
  defaultCountry?: Country;
    onPhoneChange?:(phoneNumber:string) => void;
}


const countries: Country[] = COUNTRY_CODES ;


/**[
  { name: "United States", code: "US", dial_code: "+1", flag: "🇺🇸" },
  { name: "United Kingdom", code: "GB", dial_code: "+44", flag: "🇬🇧" },
  // ... rest of the countries
];***/



export default function CountyCodeComphone({ 
  onCountryChange, 
  defaultCountry = countries[31],
  onPhoneChange
}: CountryPhoneInputProps) {


  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCountry, setSelectedCountry] = useState<Country>(defaultCountry);
  const [phoneNumber, setPhoneNumber] = useState<string>("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (onCountryChange) {
      onCountryChange(selectedCountry);
    }
    if(onPhoneChange){
        onPhoneChange(phoneNumber)
    }
  }, [selectedCountry, onCountryChange,phoneNumber,onPhoneChange]);

  const filteredCountries = countries.filter((country) =>
    country.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
    country.code.includes(searchTerm)
  );

  const handleCountrySelect = (country: Country) => {
    setSelectedCountry(country);
    setIsOpen(false);
    setSearchTerm("");
  };

  const handlePhoneInput = (phoneNumber: string) => {
    setPhoneNumber(phoneNumber);
  }

  return (
    <div className="flex w-full max-w-md">
      {/* Country Select Dropdown */}
      <div className="relative mr-2" ref={dropdownRef}>
        <button
          type="button"
          className="flex items-center justify-between px-3 py-2 bg-gray-50 border border-gray-300 rounded-md shadow-sm w-28 focus:outline-none focus:ring-2 focus:ring-blue-500"
          onClick={() => setIsOpen(!isOpen)}
        >
          <div className="flex items-center">
            <span className="mr-2 text-xl">{selectedCountry.flag}</span>
            <span className="font-medium">{selectedCountry.code}</span>
          </div>
          <svg
            className={`w-4 h-4 ml-2 text-gray-500 transition-transform duration-200 ${
              isOpen ? "transform rotate-180" : ""
            }`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        {isOpen && (
          <div className="absolute z-10 w-64 mt-1 bg-white border border-gray-300 rounded-md shadow-lg">
            {/* Search Box */}
            <div className="p-2 border-b border-gray-200">
              <input
                type="text"
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Search country..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                autoFocus
              />
            </div>

            {/* Country List */}
            <div className="overflow-y-auto max-h-60">
              {filteredCountries.length > 0 ? (
                filteredCountries.map((country) => (
                  <div
                    key={country.code}
                    className="flex items-center px-4 py-2 cursor-pointer hover:bg-gray-100"
                    onClick={() => handleCountrySelect(country)}
                  >
                    <span className="mr-3 text-xl">{country.flag}</span>
                    <span className="flex-grow text-sm font-medium">{country.country}</span>
                    <span className="text-sm text-gray-500">{country.code}</span>
                  </div>
                ))
              ) : (
                <div className="px-4 py-2 text-sm text-gray-500">No countries found</div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Phone Number Input */}
      <input
        type="tel"
        className="flex-grow px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        placeholder="Phone number"
        onChange={(e)=> handlePhoneInput(e.target.value)}
      />
    </div>
  );
}