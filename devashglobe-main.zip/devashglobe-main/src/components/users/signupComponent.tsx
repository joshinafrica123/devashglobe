"use client";


import { BASE_URL } from '@/app/core/api';
import { FormData, validateEmail, validatePassword } from '@/app/core/util';
import { setCookie } from '@/app/datatype/frontEndCookiee';
import responce from '@/app/datatype/response';
import { useRouter } from 'next/navigation'
import React, { useState } from "react";



export default function SignUpForm() {
  const [form, setForm] = useState<FormData>({
    email: "",
    user_type: "",
    business_type: "",
    password: "",
    confirm_password: "",
  });

  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

 

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validationErrors = validatePassword(form.password);
    const validationEmailErrors = validateEmail(form.email);
    if (form.password !== form.confirm_password) {
      validationErrors.push("Passwords do not match.");
    }
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
    } else {

      if(validationEmailErrors.length > 0){
        setErrors(validationEmailErrors);
        return;
      }else {

      setErrors([]);
      setLoading(true)
      console.log("Signing up:", form);

      // Submit your API call here
      saveRegister(form);
    
      }
    }
  };



async function saveRegister(form: FormData): Promise<void> {
  try {

    const formData = new globalThis.FormData();
    formData.append('email', form.email);
    formData.append('user_type', form.user_type);
    formData.append('business_type_id', form.business_type);
    formData.append('password', form.password);
    formData.append('confirm_password', form.confirm_password);


    const response = await fetch(`${BASE_URL}/auth/register`, {
      method: 'POST',
      body: formData, // FormData handles content-type automatically
    });

    if (!response.ok) {
      throw new Error(`Failed to register: ${response.status}`);
    }

    const data = await response.json();
    
    const dataTypeed = (data as responce);
    if(dataTypeed.error){
      const errList : string[] = [dataTypeed.error]
      setErrors(errList);
    }else{

    console.log('Registered user:', data);
    // Set cookie (expires in 1 day)
    setCookie(data,'signup',form.user_type,form.business_type,form.email);
    // await setCookie('token',(data as responce).token);
    
/**console.log(getCookie('businesstype'))***/
// Read cookie
//const allCookies = document.cookie; // returns "token=abc123; theme=dark"

    router.push('/users');

  }



  } catch (error) {
    console.error('Registration error:', error);
    const dataTypeed = (error as responce);
    if(dataTypeed.error){
      const errList : string[] = [dataTypeed.error]
      setErrors(errList);
    }


  }
}



  

  return (
    <form
      onSubmit={handleSubmit}
      className="max-w-md mx-auto p-6 bg-gradient-to-br from-gray-50 to-gray-100  bg-[#D62D30]/20 shadow-2xl dark:bg-gray-900  rounded-xl space-y-4 w-full"
    >
      <h2 className="text-2xl font-bold text-center text-[#06163A] dark:text-white">Join Us</h2>

      <input
        type="email"
        name="email"
        placeholder="Email"
        value={form.email}
        onChange={handleChange}
        className="w-full p-2 border rounded focus:outline-none dark:bg-gray-800 dark:text-white"
        required
      />

      <select
        name="user_type"
        value={form.user_type}
        onChange={handleChange}
        className="w-full p-2 border rounded dark:bg-gray-800 dark:text-white"
        required
      >
        <option value="">Select User Type</option>
        <option value="shipper">Shipper</option>
        <option value="carrier">Carrier</option>
      </select>

      <select
        name="business_type"
        value={form.business_type}
        onChange={handleChange}
        className="w-full p-2 border rounded dark:bg-gray-800 dark:text-white"
        required
      >
        <option value="">Select Business Type</option>
        <option value="1">Individual</option>
        <option value="2">Cooperations</option>
      </select>

      {/* Password Field */}
      <div className="relative">
        <input
          type={showPassword ? "text" : "password"}
          name="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          className="w-full p-2 border rounded focus:outline-none dark:bg-gray-800 dark:text-white"
          required
        />
        <button
          type="button"
          onClick={togglePasswordVisibility}
          className="absolute right-2 top-2 text-sm text-blue-600 dark:text-blue-300"
        >
          {showPassword ? "Hide" : "Show"}
        </button>
      </div>

      {/* Confirm Password */}
      <input
        type={showPassword ? "text" : "password"}
        name="confirm_password"
        placeholder="Confirm Password"
        value={form.confirm_password}
        onChange={handleChange}
        className="w-full p-2 border rounded focus:outline-none dark:bg-gray-800 dark:text-white"
        required
      />

      {/* Display Errors */}
      {errors.length > 0 && (
        <div className="text-sm text-red-600 dark:text-red-400 space-y-1">
          {errors.map((err, index) => (
            <p key={index}>• {err}</p>
          ))}
        </div>
      )}

      <button
        type="submit"
        className="w-full bg-[#06163A] text-white py-2 rounded hover:bg-blue-900 transition"
      >
        Sign Up
          {loading ? (
            <>
          
             ...

            </>
          ) : '' }
           
        

      </button>

      <div className="text-center text-sm mt-4">
        Already a member?{" "}
        <a href="/login" className="text-[#D62D30] hover:underline font-medium">
          Sign In
        </a>
      </div>

    </form>
  );
}
