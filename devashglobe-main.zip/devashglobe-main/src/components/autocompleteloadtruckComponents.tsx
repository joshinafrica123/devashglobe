"use client";

import { Country, COUNTRY_CODES } from "@/app/datatype/countryCode";
import { useState, useRef, useEffect } from "react";

/**interface Country {
  id:string;
  code: string;
  country: string;
  flag: string;
  maxLenght:number;
}***/

interface CountryPhoneInputProps {
  onLoadTruckChange?: (country: Country) => void;
  defaultItem?: Country;
  onItemChange?: (phoneNumber: string) => void;
}

const countries: Country[] = COUNTRY_CODES;

/**[
  { name: "United States", code: "US", dial_code: "+1", flag: "🇺🇸" },
  { name: "United Kingdom", code: "GB", dial_code: "+44", flag: "🇬🇧" },
  // ... rest of the countries
];***/

export default function AutocompleteComponent({
  onLoadTruckChange,
  defaultItem = countries[31],
  onItemChange,
}: CountryPhoneInputProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCountry, setSelectedCountry] = useState<Country>(defaultItem);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (onLoadTruckChange) {
      onLoadTruckChange(selectedCountry);
    }
  }, [selectedCountry, onLoadTruckChange, onItemChange]);

  const filteredCountries = countries.filter(
    (country) =>
      country.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
      country.code.includes(searchTerm)
  );

  const handleCountrySelect = (country: Country) => {
    setSelectedCountry(country);
    setIsOpen(false);
    setSearchTerm("");
  };

  
  return (
    <div className="flex w-full">
      {/* Country Select Dropdown */}
      <div className=" mr-2 w-full" ref={dropdownRef}>

        <div className=" border-gray-200">
          <input
            type="text"
            className="w-full px-3 py-2 text-sm border bg-[#0b234f] border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Search country..."
            value={selectedCountry.country}
            onFocus={() => setIsOpen(!isOpen)}
            onChange={(e) => setSearchTerm(e.target.value)}
            autoFocus
          />
        </div>

        {isOpen && (
          <div className="absolute z-30 w-53 mt-1 bg-[#0b234f] border border-gray-300 rounded-md shadow-lg">
            {/* Country List */}
            <div className="overflow-y-auto max-h-60">
              {filteredCountries.length > 0 ? (
                filteredCountries.map((country) => (
                  <div
                    key={country.code}
                    className="flex items-center px-4 py-2 cursor-pointer hover:bg-gray-100"
                    onClick={() => handleCountrySelect(country)}
                  >
                    <span className="mr-3 text-xl">{country.flag}</span>
                    <span className="flex-grow text-sm font-medium">
                      {country.country}
                    </span>
                    <span className="text-sm text-gray-500">
                      {country.code}
                    </span>
                  </div>
                ))
              ) : (
                <div className="px-4 py-2 text-sm text-gray-500">
                  No countries found
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
