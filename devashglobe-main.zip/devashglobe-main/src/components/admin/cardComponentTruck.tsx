"use client "

import { loadboard } from '@/app/datatype/loadboards';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { HiDotsHorizontal,  HiMail, HiPhone } from 'react-icons/hi'


export default function  Card  ({ title, data, type,location }: { title: string; data: loadboard[]; type: string; location:string })  {

  const [loading, setLoading] = useState(true);

  // Simulate loading for demo (replace with real loading logic if needed)
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1200);
    return () => clearTimeout(timer);
  }, []);

  // Skeleton loader
  const Skeleton = () => (
    <div className="space-y-3 overflow-y-auto max-h-[400px] pr-1">
      {[...Array(5)].map((_, idx) => (
        <div key={idx} className="flex items-center justify-between bg-[#0E234F] p-3 rounded-lg animate-pulse">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-gray-700" />
            <div>
              <div className="h-4 w-24 bg-gray-700 rounded mb-2" />
              <div className="h-3 w-12 bg-gray-600 rounded" />
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="w-5 h-5 bg-gray-700 rounded-full" />
            <div className="w-5 h-5 bg-gray-700 rounded-full" />
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="bg-[#06163A] text-white rounded-xl shadow-md p-4 w-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">{title}</h3>
        <Link href={location} className="text-white">
          <HiDotsHorizontal />
        </Link>
      </div>
      {loading ? (
        <Skeleton />
      ) : (
        <div className="space-y-3 overflow-y-auto max-h-[400px] pr-1">
          {data.map((item, index) => (
            <div
              key={index}
              className="flex items-center justify-between bg-[#0E234F] hover:bg-[#122b5a] p-3 rounded-lg transition-all duration-200"
            >
              <div className="flex items-center space-x-3">
                <Image
                  src={item.image}
                  width={100}
                  height={300}
                  alt={item.title || item.status}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h4 className="text-sm font-medium">{item.title || item.title}</h4>
                  <p className="text-xs text-gray-300">{item.status == "0" ? "new" :item.status}</p>
                </div>
              </div>
              {type === 'users' && (
                <div className="flex items-center space-x-4 text-white">
                  <HiMail size={16} />
                  <HiPhone size={16} />
                </div>
              )}
              {type === 'loads' && (
                <div className="text-sm font-bold text-[#D62D30]">{item.status == "0" ? "new" :item.status}</div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}