"use client"
import { useState } from "react";


export default function DistanseComponent() {

    const [distance, setDistance] = useState(50);

    return (
        <>
        <label className="block text-gray-700 dark:text-gray-300 font-medium">Distance (Miles): {distance}</label>
            
            <input
            type="range"
            min="0"
            max="100"
            value={distance}
            onChange={(e) => setDistance(parseInt(e.target.value))}
            className="w-full mt-2" required
                />
        </>
    )
}
