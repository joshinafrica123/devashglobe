import React from "react";

interface RecentActivityProps {
  activities: {
    id: number;
    action: string;
    company: string;
    type: string;
    timestamp: string;
    details?: string;
  }[];
  onViewMore?: () => void;
}
// type ActivityType = 'merchant' | 'shipper'
export default function RecentActivity({
  activities,
  onViewMore,
}: RecentActivityProps) {
  const tagStyles: { merchant: string; shipper: string; carrier: string } = {
    merchant: "bg-blue-100 text-blue-800",
    shipper: "bg-green-100 text-green-800",
    carrier: "bg-yellow-100 text-yellow-800",
  };

  function timeAgo(iso?: string) {
    if (!iso) return "unknown";
    const then = new Date(iso);
    const now = new Date();
    const s = Math.floor((now.getDate() - then.getDate()) / 1000);
    if (s < 60) return `${s}s ago`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    const d = Math.floor(h / 24);
    if (d < 30) return `${d}d ago`;
    return then.toLocaleDateString();
  }

  return (
    <section className="w-full bg-white dark:bg-slate-900 rounded-2xl shadow-sm p-4">
      {/* Header: View more (left) --- Recent Activity (right) */}
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-200">
          Recent Activity
        </h3>

        <button
          onClick={onViewMore}
          className="text-sm text-slate-500 hover:underline flex items-center gap-2"
          aria-label="View more activities"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M15 19l-7-7 7-7"
            />
          </svg>
          View more
        </button>
      </div>

      {/* Activity list */}
      <ul className="divide-y divide-slate-100 dark:divide-slate-800">
        {activities.length === 0 ? (
          <li className="p-4 text-sm text-slate-500">No recent activity</li>
        ) : (
          activities.map((a) => (
            <li key={a.id} className="p-3 flex items-start gap-3">
              {/* Avatar / icon */}
              <div className="flex-none">
                <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-sm font-medium text-slate-700">
                  {a.company?.charAt(0) ?? "?"}
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="truncate">
                    <p className="text-sm text-slate-800 dark:text-slate-100 truncate">
                      <span className="font-medium">{a.action}</span>
                      <span className="text-slate-500"> — {a.company}</span>
                    </p>
                  </div>

                  <div className="ml-3 flex items-center gap-2">
                    {/* Status tag */}
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        tagStyles.carrier || "bg-slate-100 text-slate-800"
                      }`}
                    >
                      {a.type}
                    </span>

                    {/* Time */}
                    <time
                      className="text-xs text-slate-400"
                      dateTime={a.timestamp}
                    >
                      {timeAgo(a.timestamp)}
                    </time>
                  </div>
                </div>

                {/* Optional secondary details */}
                {a.details && (
                  <p className="mt-1 text-xs text-slate-500 truncate">
                    {a.details}
                  </p>
                )}
              </div>
            </li>
          ))
        )}
      </ul>
    </section>
  );
}
