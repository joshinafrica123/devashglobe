import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Vendor from "@/app/datatype/vendor";

/**
 * VendorModal
 * Props:
 * - isOpen: boolean
 * - onClose: () => void
 * - vendor: { name, avatarUrl, verified, rating, trucks, loads, successRate, deliveryRate, bio }
 * - prices: { min, max }
 * - onBuy: (price) => void
 * - theme: 'light' | 'dark' (optional)
 *
 * Usage: import VendorModal from './VendorModal'
 * <VendorModal isOpen={open} onClose={...} vendor={v} prices={{min:100, max:200}} onBuy={(p)=>{}} />
 */

export default function VendorModal({
  isOpen = false,
  onClose = () => {},
  vendor = {} as Vendor,
  prices = { min: 0, max: 0 },
  onBuy = (price: number) => {
    console.log(price);
  },
  theme = "light",
}) {
  const [activeTab, setActiveTab] = useState("payment"); // 'payment' or 'negotiation'
  const [offerPrice, setOfferPrice] = useState(prices.max);
  const [messages, setMessages] = useState([
    { id: 1, from: "vendor", text: "Hi — how can I help with this load?" },
  ]);
  const [compose, setCompose] = useState("");

  const handleSend = () => {
    if (!compose.trim()) return;
    setMessages((m) => [
      ...m,
      { id: Date.now(), from: "you", text: compose.trim() },
    ]);
    setCompose("");
  };

  const handleBuy = () => {
    onBuy(prices.max);
  };

  // animations
  const backdrop = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
    exit: { opacity: 0 },
  };

  const modalAnim = {
    hidden: { opacity: 0, scale: 0.98, y: 12 },
    visible: { opacity: 1, scale: 1, y: 0, transition: { duration: 0.22 } },
    exit: { opacity: 0, scale: 0.98, y: 12 },
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className={`fixed inset-0 z-50 flex items-center justify-center px-4 py-6 overflow-y-auto ${
            theme === "dark" ? "dark" : ""
          }`}
          variants={backdrop}
          initial="hidden"
          animate="visible"
          exit="exit"
          onMouseDown={(e) => {
            // close when clicking backdrop
            if (e.target === e.currentTarget) onClose();
          }}
        >
          {/* centered modal */}
          <motion.div
            className="relative w-full max-w-6xl mx-auto my-10 sm:my-16 rounded-2xl shadow-2xl overflow-hidden bg-white dark:bg-gray-900 ring-1 ring-black/5 dark:ring-white/5"
            variants={modalAnim}
            initial="hidden"
            animate="visible"
            exit="exit"
            role="dialog"
            aria-modal="true"
          >
            <div className="relative">
              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 z-20 inline-flex items-center justify-center rounded-md p-2 hover:bg-gray-100 dark:hover:bg-gray-800"
                aria-label="Close"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 text-gray-700 dark:text-gray-200"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                    clipRule="evenodd"
                  />
                </svg>
              </button>

              <div className="flex flex-col lg:flex-row min-h-[480px] max-h-[90vh] overflow-y-auto">
                {/* LEFT: Vendor Details */}
                <div className="w-full lg:w-1/2 p-8 border-b lg:border-b-0 lg:border-r border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-transparent">
                  <div className="flex items-start gap-6">
                    <img
                      src={
                        vendor.avatarUrl ||
                        `https://ui-avatars.com/api/?name=${encodeURIComponent(
                          vendor.name || "Vendor"
                        )}&background=ddd&color=333`
                      }
                      alt={vendor.name}
                      className="h-24 w-24 rounded-full object-cover ring-2 ring-white dark:ring-gray-900 shadow-sm"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
                          {vendor.name || "Unnamed Vendor"}
                        </h3>
                        {vendor.verified ? (
                          <span className="inline-flex items-center gap-1 rounded-md bg-green-50 px-2 py-0.5 text-xs text-green-700 dark:bg-green-900/30 dark:text-green-300">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-3 w-3"
                              viewBox="0 0 20 20"
                              fill="currentColor"
                            >
                              <path
                                fillRule="evenodd"
                                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                clipRule="evenodd"
                              />
                            </svg>
                            Verified
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-md bg-orange-50 px-2 py-0.5 text-xs text-orange-700 dark:bg-orange-900/30 dark:text-orange-300">
                            Unverified
                          </span>
                        )}
                      </div>

                      <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                        {vendor.bio || "No bio provided."}
                      </p>

                      <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                        <div className="rounded-lg bg-white dark:bg-gray-800 p-3 shadow-sm">
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            Rating
                          </div>
                          <div className="mt-1 text-lg font-medium text-gray-900 dark:text-gray-100">
                            {vendor.rating ?? "—"} / 5
                          </div>
                        </div>
                        <div className="rounded-lg bg-white dark:bg-gray-800 p-3 shadow-sm">
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            Trucks
                          </div>
                          <div className="mt-1 text-lg font-medium text-gray-900 dark:text-gray-100">
                            {vendor.trucks ?? 0}
                          </div>
                        </div>
                        <div className="rounded-lg bg-white dark:bg-gray-800 p-3 shadow-sm">
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            Loads
                          </div>
                          <div className="mt-1 text-lg font-medium text-gray-900 dark:text-gray-100">
                            {vendor.loads ?? 0}
                          </div>
                        </div>
                        <div className="rounded-lg bg-white dark:bg-gray-800 p-3 shadow-sm">
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            Success
                          </div>
                          <div className="mt-1 text-lg font-medium text-gray-900 dark:text-gray-100">
                            {vendor.successRate ?? "—"}%
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                        <div>
                          Delivery Rate:{" "}
                          <span className="font-medium text-gray-800 dark:text-gray-200">
                            {vendor.deliveryRate ?? "—"}%
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* optional extra info */}
                  <div className="mt-6">
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-200">
                      About
                    </h4>
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                      {vendor.about ||
                        "Experienced carrier specializing in regional deliveries."}
                    </p>
                  </div>
                </div>

                {/* RIGHT: Payment / Negotiation */}
                <div className="w-full lg:w-1/2 p-8 bg-white dark:bg-gray-900">
                  {/* price header */}
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        Price Range
                      </div>
                      <div className="mt-1 flex items-baseline gap-3">
                        <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                          ${prices.min}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          to
                        </div>
                        <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                          ${prices.max}
                        </div>
                      </div>
                      <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                        Suggested:{" "}
                        <span className="font-medium text-gray-800 dark:text-gray-200">
                          ${offerPrice}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        Estimated ETA
                      </div>
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-200">
                        1-3 days
                      </div>
                    </div>
                  </div>

                  {/* Tabs */}
                  <div className="mt-6">
                    <div className="flex items-center gap-2 rounded-md bg-gray-100 dark:bg-gray-800 p-1">
                      <button
                        onClick={() => setActiveTab("payment")}
                        className={`px-4 py-2 rounded-md text-sm font-medium ${
                          activeTab === "payment"
                            ? "bg-white dark:bg-gray-900 shadow"
                            : "bg-transparent"
                        }`}
                      >
                        Payment
                      </button>
                      <button
                        onClick={() => setActiveTab("negotiation")}
                        className={`px-4 py-2 rounded-md text-sm font-medium ${
                          activeTab === "negotiation"
                            ? "bg-white dark:bg-gray-900 shadow"
                            : "bg-transparent"
                        }`}
                      >
                        Negotiate
                      </button>
                    </div>

                    {/* Panel */}
                    <div className="mt-4">
                      {activeTab === "payment" ? (
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm text-gray-600 dark:text-gray-300">
                              Offer price
                            </label>
                            <div className="mt-2 flex items-center gap-3">
                              <input
                                type="number"
                                value={offerPrice}
                                onChange={(e) =>
                                  setOfferPrice(Number(e.target.value))
                                }
                                className="w-full rounded-md border border-gray-200 dark:border-gray-800 px-3 py-2 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100"
                              />
                              <button
                                onClick={() => setOfferPrice(prices.min)}
                                className="px-3 py-2 rounded-md text-sm bg-gray-50 dark:bg-gray-800"
                              >
                                Min
                              </button>
                              <button
                                onClick={() => setOfferPrice(prices.max)}
                                className="px-3 py-2 rounded-md text-sm bg-gray-50 dark:bg-gray-800"
                              >
                                Max
                              </button>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <button
                              onClick={handleBuy}
                              className="flex-1 rounded-lg px-4 py-3 font-semibold text-white bg-[#06163A] hover:bg-[#030d23]"
                            >
                              Buy
                            </button>
                            <button
                              onClick={() => setActiveTab("negotiation")}
                              className="rounded-lg px-4 py-3 border border-gray-200 dark:border-gray-800"
                            >
                              Message Vendor
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col h-[320px]">
                          <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                            {messages.map((m) => (
                              <div
                                key={m.id}
                                className={`max-w-[80%] p-3 rounded-lg ${
                                  m.from === "you"
                                    ? "ml-auto bg-indigo-600 text-white"
                                    : "bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                                }`}
                              >
                                <div className="text-sm">{m.text}</div>
                              </div>
                            ))}
                          </div>

                          <div className="mt-3 flex items-center gap-3">
                            <input
                              value={compose}
                              onChange={(e) => setCompose(e.target.value)}
                              placeholder="Write a message..."
                              className="flex-1 rounded-md border border-gray-200 dark:border-gray-800 px-3 py-2 bg-white dark:bg-gray-900 text-sm text-gray-900 dark:text-gray-100"
                              onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                  e.preventDefault();
                                  handleSend();
                                }
                              }}
                            />
                            <button
                              onClick={handleSend}
                              className="px-4 py-2 rounded-md bg-indigo-600 text-white"
                            >
                              Send
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer small hint */}
              <div className="absolute left-6 bottom-4 text-xs text-gray-500 dark:text-gray-400">
                You can negotiate with the shipper before accepting.
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
