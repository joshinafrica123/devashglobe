"use client"

import { motion } from "framer-motion";
import { BookCheck, Clock, ExpandIcon, MapPin, Settings, Truck } from "lucide-react";
import { Suspense, useState, useEffect } from "react";
// import { FaShippingFast, FaTruck, FaClock, FaWarehouse, FaMapMarkerAlt } from "react-icons/fa";

const services = [
  { title: "Freight Shipping", description: "Reliable freight services for your business needs.", icon: <Truck className="w-10 h-10 text-[#D62D30]" /> },
  { title: "Logistics Management", description: "Optimized logistics solutions for efficiency.", icon: <Settings className="w-10 h-10 text-[#D62D30]" /> },
  { title: "Express Delivery", description: "Fast and secure package delivery services.", icon: <Clock className="w-10 h-10 text-[#D62D30]" /> },
  { title: "Load Board", description: "Safe and secure storage solutions.", icon: <BookCheck className="w-10 h-10 text-[#D62D30]" /> },
  { title: "Tracking Solutions", description: "Real-time tracking for your shipments.", icon: <MapPin className="w-10 h-10 text-[#D62D30]" /> },
  { title: "Load Broaking", description: "Real-time tracking for your shipments.", icon: <ExpandIcon className="w-10 h-10 text-[#D62D30]" /> },
];

function ServicesSkeleton() {
  return (
    <div className="grid md:grid-cols-3 gap-6 bg-gray-100 dark:bg-gray-900 py-10 px-10 rounded-3xl">
      {[...Array(6)].map((_, idx) => (
        <div key={idx} className="shadow-lg rounded-lg p-6 bg-gray-100 dark:bg-gray-800 animate-pulse text-center relative">
          <div className="w-16 h-16 rounded-full bg-gray-300 dark:bg-gray-700 mx-auto mb-3" />
          <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-2/3 mx-auto mb-2" />
          <div className="h-3 bg-gray-200 dark:bg-gray-600 rounded w-1/2 mx-auto" />
        </div>
      ))}
    </div>
  );
}

function ServicesList() {
  // Simulate loading for demonstration
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);
  if (loading) return <ServicesSkeleton />;
  return (
    <>
    <section className="relative py-20 px-6 overflow-hidden">
                        {/* Background gradient */}
                        <div className="absolute inset-0 bg-gradient-to-r from-[#06163A] via-[#0E244F] to-[#06163A]"></div>
                        <div className="absolute inset-0 bg-[url('/images/pattern.svg')] opacity-10"></div>
                        
                        <div className="relative max-w-6xl mx-auto text-center text-white">
                            <motion.h2
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 1 }}
                            className="text-4xl md:text-5xl font-extrabold mb-12"
                            >
                            What we do
                            </motion.h2>
    
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                            {services.map((value, i) => (
                                <motion.div
                                key={i}
                                initial={{ opacity: 0, y: 40 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.2, duration: 0.7 }}
                                viewport={{ once: true }}
                                whileHover={{ y: -8, scale: 1.03 }}
                                className="p-8 rounded-2xl bg-white/10 backdrop-blur-lg shadow-lg border border-white/20"
                                >
                                {/* Icon Circle */}
                                <div className="w-16 h-16 mx-auto flex items-center justify-center rounded-full bg-[#d62d303a] text-white text-3xl mb-6">
                                    {value.icon}
                                </div>
    
                                <h3 className="text-2xl font-bold text-white mb-3">
                                    {value.title}
                                </h3>
                                <p className="text-gray-300 leading-relaxed">
                                    {value.description}
                                </p>
                                </motion.div>
                            ))}
                            </div>
                        </div>
                    </section>
    </>
  );
}

export default function ServicesComponent() {
  return (
    <Suspense fallback={<ServicesSkeleton />}>
      <ServicesList />
    </Suspense>
  );
}
