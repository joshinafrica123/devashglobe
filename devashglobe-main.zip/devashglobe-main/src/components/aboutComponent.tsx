"use client";

import { ShieldCheck, Eye, Clock } from "lucide-react"; // I
import Image from "next/image";
import { motion } from "framer-motion";
import { Target, ArrowRight } from "lucide-react";

const ourValues = [
  {
    title: "Transparency",
    description:
      "We ensure openness in every transaction, offering real-time tracking and clear communication.",
    icon: <Eye className="w-10 h-10 text-[#D62D30]" />, // Transparency icon
  },
  {
    title: "Efficiency",
    description:
      "Our technology-driven approach optimizes logistics for seamless and timely operations.",
    icon: <Clock className="w-10 h-10 text-[#D62D30]" />, // Efficiency icon
  },
  {
    title: "Reliability",
    description:
      "We guarantee on-time deliveries and seamless coordination for a smooth logistics experience.",
    icon: <ShieldCheck className="w-10 h-10 text-[#D62D30]" />, // Reliability icon
  },
];

export default function aboutComponent({ isAbout }: { isAbout: boolean }) {
  return (
    <>
      {/* Who we are  */}
    
      <section className="relative overflow-hidden bg-gradient-to-b from-gray-100 via-white to-gray-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 py-20 px-6 sm:px-12">
        {/* Decorative background circles */}
        <div className="absolute -top-20 -left-20 w-72 h-72 bg-[#D62D30]/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 -right-20 w-96 h-96 bg-[#06163A]/10 rounded-full blur-3xl"></div>

        <div className="container mx-auto grid md:grid-cols-2 gap-14 items-center relative z-10">
          {/* Text Section */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            transition={{ staggerChildren: 0.2 }}
            className="space-y-6"
          >
            <motion.span
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 },
              }}
              className="text-lg text-[#D62D30] font-semibold tracking-wide"
            >
              Who We Are
            </motion.span>

            <motion.h2
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 },
              }}
              className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white leading-tight"
            >
              We Provide a{" "}
              <span className="text-[#D62D30]">Reliable Service</span>
            </motion.h2>

            <motion.p
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 },
              }}
              className="text-gray-700 dark:text-gray-300 max-w-xl"
            >
              At <span className="font-semibold">AshGlobe</span>, our mission is
              to revolutionize supply chain and logistics by providing seamless,
              efficient, and transparent solutions. We leverage technology and
              innovation to simplify complex challenges, ensuring timely and
              cost-effective delivery for businesses of all sizes.
            </motion.p>

            {/* Mission + Vision */}
            <div className="grid sm:grid-cols-2 gap-6 mt-8">
              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
                className="flex items-start space-x-4"
              >
                <div className="p-4 bg-[#D62D30] text-white rounded-full shadow-md">
                  <Target className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                    Our Mission
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">
                    Bridging local and global multi-modal freight to deliver
                    smart, value-driven logistics solutions.
                  </p>
                </div>
              </motion.div>

              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
                className="flex items-start space-x-4"
              >
                <div className="p-4 bg-[#D62D30] text-white rounded-full shadow-md">
                  <Eye className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                    Our Vision
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">
                    Inspiring excellence as a leading international platform,
                    empowering efficient, high-quality transportation solutions
                    across Africa and beyond.
                  </p>
                </div>
              </motion.div>
            </div>

            {/* Button */}
            {!isAbout && (
              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
                className="pt-4"
              >
                <a
                  href="/about"
                  className="inline-flex items-center px-8 py-4 bg-[#06163A] text-white rounded-xl shadow-lg hover:bg-[#D62D30] hover:shadow-xl transition-all duration-300"
                >
                  Explore More
                  <ArrowRight className="ml-2 w-5 h-5" />
                </a>
              </motion.div>
            )}
          </motion.div>

          {/* Image Section */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            whileInView={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            viewport={{ once: true }}
            className="relative group"
          >
            <div className="absolute -inset-2 bg-gradient-to-r from-[#D62D30] to-[#06163A] rounded-xl blur-2xl opacity-30 group-hover:opacity-60 transition duration-500"></div>
            <Image
              src="/assets/img/about/1.jpg"
              alt="About AshGlobe"
              width={600}
              height={420}
              className="rounded-xl shadow-2xl relative z-10 transform group-hover:scale-105 transition duration-500"
            />
          </motion.div>
        </div>
      </section>

      {/* our value  */}

      <section className="relative py-20 px-6 overflow-hidden">
        {/* Background gradient */}
        <div className="absolute -inset-2 bg-gradient-to-r from-[#D62D30] to-[#06163A]"></div>
        <div className="absolute inset-0 bg-[url('/images/pattern.svg')] opacity-10"></div>

        <div className="relative max-w-6xl mx-auto text-center text-white">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-4xl md:text-5xl font-extrabold mb-12"
          >
            Our Values
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {ourValues.map((value, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.2, duration: 0.7 }}
                viewport={{ once: true }}
                whileHover={{ y: -8, scale: 1.03 }}
                className="p-8 rounded-2xl bg-white/10 backdrop-blur-lg shadow-lg border border-white/20"
              >
                {/* Icon Circle */}
                <div className="w-16 h-16 mx-auto flex items-center justify-center rounded-full bg-[#d62d303a] text-white text-3xl mb-6">
                  {value.icon}
                </div>

                <h3 className="text-2xl font-bold text-white mb-3">
                  {value.title}
                </h3>
                <p className="text-gray-300 leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
