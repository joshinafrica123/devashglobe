"use client"

import { motion } from "framer-motion";


export default function aboutMoreComponent  () {

    return (
        <>

            {/* Who we are  */}
            <section className="bg-gray-100 dark:bg-gray-900 py-16">
                <div className="container mx-auto px-6">

                    <div className="grid md:grid-cols-2 gap-10 items-center">

                    {/* Text Content */}
                    <div>

                        <h2 className="text-4xl font-bold text-gray-900 dark:text-white mt-2 pl-10">
                        Connecting Continents, Delivering Trust:<span className="text-[#D62D30]"> The Ash International Express Journey</span>
                        </h2>
                            
                        <div className="flex items-center space-x-4 py-5 pb-5 pl-10" >
                        
                            <div>

                                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Our Story</h3>
                                
                                <p className="text-gray-600 text-justify dark:text-gray-400 text-lg mt-1">
                                In the heart of Accra, Ghana, a vision for seamless connectivity was born. Founded by the visionary Tuoyo Liberty in the bustling locale of Kasoa, <strong> Ash International Express </strong> embarked on its journey with a simple yet profound mission: to deliver gifts across Accra, weaving threads of connections with every package delivered. This initiative, grounded in trust and reliability, marked the humble beginnings of a venture that would soon transcend borders.
                                </p>

                            </div>
                        </div>

                        <div className="flex items-center space-x-4 pb-5 pl-10">
                        
                            <div>

                                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Today and Beyond</h3>
                                    
                                    <p className="text-gray-600 text-justify dark:text-gray-400 text-lg mt-1">
                                         Today, <strong> Ash International Express </strong> stands as a beacon of ambition, a bridge connecting continents, cultures, and communities. Our journey from the streets of Kasoa to the global stage is a story of perseverance, innovation, and the relentless pursuit of connecting the world.
                                    </p>
                                    <p className="text-gray-600 text-justify dark:text-gray-400 text-lg mt-1">
                                        As we look to the future, we remain committed to exploring new opportunities in the logistics sector, continuously pushing the boundaries of what is possible. Our foundation, built on trust and reliability, continues to guide us as we forge new paths and expand our horizons.
                                    </p>
                                    <p className="text-gray-600 text-justify dark:text-gray-400 text-lg mt-1">
                                         
                                        Join us on this journey of connection and discovery, as we continue to deliver more than just packages—we deliver promises, hope, and a sense of belonging in an ever-connected world.
                                    </p>

                            </div>

                        </div>

                        

                    </div>

                    <motion.div
                        initial={{ opacity: 0, x: 50 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5 }}
                        className="relative"
                    >

                        {/* Text Content */}
                        <div>
                                
                            <div className="flex items-center space-x-4 py-25 pb-5 px-10" >
                            
                                <div>

                                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Our Evolution </h3>
                                    
                                    <p className="text-gray-600 text-justify dark:text-gray-400 text-lg mt-1">
                                    From these modest roots, we nurtured an ambition not just to serve but to unite. We ventured beyond the familiar streets of Accra, pushing into new territories with the same zeal that guided us at our inception. The United Kingdom and later, the United States, became new homes for our expanding operations. With each step forward, our dreams grew, as did our capacity to realize them.
                                    </p>

                                    <p className="text-gray-600 text-justify dark:text-gray-400 text-lg mt-1">
                                    Incorporated in 2013, <strong> Ash International Express </strong> has charted a remarkable course through the logistics landscape. Initially serving around 20 clients with approximately 500 deliveries, we have grown not just in volume but in the scope of our services. This expansion from a local initiative to an international logistics provider is not just a testament to our growth but a reflection of our unwavering commitment to excellence and innovation.
                                    </p>

                                </div>
                            </div>

                            <div className="flex items-center space-x-4 pb-5 px-10">
                            
                                <div>

                                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Connect With Us </h3>
                                        
                                        <p className="text-gray-600 text-justify dark:text-gray-400 text-lg mt-1">
                                        Embark on this journey with us. Whether you&apos;re looking to send a token of love across Accra or bridge distances between continents, <strong> Ash International Express </strong> is here to make it happen. Let&apos;s connect the world, one delivery at a time.
                                        </p>
                                       

                                </div>

                            </div>

                            

                        </div>

                    </motion.div>
                    </div>
                </div>
            </section>



        </>
    )

}