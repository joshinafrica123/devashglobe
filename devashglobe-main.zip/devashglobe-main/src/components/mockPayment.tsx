"use client";
import { PaymentPayload } from "@/app/core/util";
import { useState } from "react";

/**
 * Plain Tailwind checkout-style modal (no external UI libs)
 * - Controlled with `open` + `onClose`
 * - Fires `onPay` with a fake payload; wire it to Paystack or  API
 */



export default function PaymentCheckoutModal({
  open,
  onClose,
  amount = 5000, // in NGN
  merchant = "Ashglobe Logistics",
  reference = "REF-123456",
  onPay,
}: {
  open: boolean;
  onClose: () => void;
  amount?: number;
  merchant?: string;
  reference?: string;
  onPay?: (payload: PaymentPayload) => Promise<void> | void;
}) {
  const [holder, setHolder] = useState("");
  const [number, setNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!open) return null;

  const handlePay = async () => {
    setLoading(true);
    try {
      const payload:PaymentPayload = { holder, number, expiry, cvv, amount, merchant, reference };
      await onPay?.(payload);
      setSuccess(true);
    } finally {
      setLoading(false);
    }
  };

  const handleSpecialClose = () => {
    setSuccess(false);
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50" onClick={handleSpecialClose} />

      {/* Modal */}
      <div className="relative z-10 w-full max-w-md rounded-2xl bg-white p-6 shadow-xl dark:bg-gray-900">
        {/* Header */}
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Checkout</h2>
            <p className="text-xs text-gray-500">Pay {merchant}</p>
          </div>
          <button
            onClick={handleSpecialClose}
            className="rounded-full p-2 hover:bg-gray-100 dark:hover:bg-gray-800"
            aria-label="Close"
          >
            {/* X icon */}
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        {/* Summary card */}
        <div className="mb-6 rounded-xl border border-gray-200 p-4 dark:border-gray-800">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Amount</p>
              <p className="text-xl font-bold">${amount.toLocaleString()}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500">Reference</p>
              <p className="font-mono text-sm">{reference}</p>
            </div>
          </div>
        </div>

        {/* Success state */}
        {success ? (
          <div className="space-y-5">
            <div className="flex flex-col items-center text-center">
              {/* Check icon */}
              <svg className="mb-3 h-12 w-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                <polyline points="22 4 12 14.01 9 11.01" />
              </svg>
              <h3 className="text-lg font-semibold">Payment Completed</h3>
              <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">Your transaction was successful.</p>
            </div>
            <button
              onClick={handleSpecialClose}
              className="w-full rounded-xl bg-gray-900 px-4 py-3 text-white transition hover:opacity-90 dark:bg-gray-100 dark:text-gray-900"
            >
              Close
            </button>
          </div>
        ) : (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handlePay(); }}>
            <div>
              <label className="mb-1 block text-sm font-medium">Cardholder Name</label>
              <input
                type="text"
                value={holder}
                onChange={(e) => setHolder(e.target.value)}
                placeholder="Jane Doe"
                required
                className="w-full rounded-xl border border-gray-300 p-3 outline-none ring-offset-0 focus:border-gray-400 focus:ring-2 focus:ring-gray-200 dark:border-gray-700 dark:bg-gray-950"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">Card Number</label>
              <input
                inputMode="numeric"
                autoComplete="cc-number"
                value={number}
                onChange={(e) => setNumber(e.target.value.replace(/[^0-9 ]/g, ""))}
                placeholder="4242 4242 4242 4242"
                required
                className="w-full rounded-xl border border-gray-300 p-3 tracking-widest outline-none ring-offset-0 focus:border-gray-400 focus:ring-2 focus:ring-gray-200 dark:border-gray-700 dark:bg-gray-950"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-sm font-medium">Expiry (MM/YY)</label>
                <input
                  inputMode="numeric"
                  autoComplete="cc-exp"
                  value={expiry}
                  onChange={(e) => setExpiry(e.target.value.replace(/[^0-9/]/g, ""))}
                  placeholder="12/28"
                  required
                  className="w-full rounded-xl border border-gray-300 p-3 outline-none ring-offset-0 focus:border-gray-400 focus:ring-2 focus:ring-gray-200 dark:border-gray-700 dark:bg-gray-950"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">CVV</label>
                <input
                  inputMode="numeric"
                  autoComplete="cc-csc"
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value.replace(/[^0-9]/g, ""))}
                  placeholder="123"
                  required
                  className="w-full rounded-xl border border-gray-300 p-3 outline-none ring-offset-0 focus:border-gray-400 focus:ring-2 focus:ring-gray-200 dark:border-gray-700 dark:bg-gray-950"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-green-600 px-4 py-3 text-white shadow transition hover:bg-green-700 disabled:opacity-60 cursor-pointer"
            >
              {loading ? "Processing…" : `Pay $${amount.toLocaleString()}`}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-700 transition hover:bg-gray-50 dark:border-gray-700 dark:text-gray-200 dark:hover:bg-gray-800 cursor-pointer"
            >
              Close
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
