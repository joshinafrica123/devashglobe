"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
// import { useRouter } from "next/navigation";
import { FaBook, FaBox, FaTruck, FaUserAlt } from "react-icons/fa";
import { useRouter } from "next/navigation";
// import Link from "next/link";

const slides = [
  {
    image: "assets/img/banner/d.jpg",
    title: "Reliable Logistics Solutions",
    subtitle: "Seamlessly connecting businesses across the globe.",
  },
  {
    image: "assets/img/banner/c.jpg",
    title: "Fast & Secure Delivery",
    subtitle: "Your goods delivered on time, every time.",
  },
  {
    image: "assets/img/banner/e.jpg",
    title: "Trusted by Businesses",
    subtitle: "Simplifying supply chains with innovation.",
  },
  {
    image: "assets/img/banner/d.jpg",
    title: "Efficient Load Matching",
    subtitle: "Supply chains like no one else.",
  },
];

// Custom animated number component
function AnimatedNumber({ value }: { value: number }) {
  const [display, setDisplay] = useState(value);

  useEffect(() => {
    const start = display;
    const end = value;
    const duration = 700;
    const stepTime = 30;
    const steps = Math.floor(duration / stepTime);
    const increment = (end - start) / steps;

    let current = start;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      current += increment;
      setDisplay(Math.floor(current));
      if (step >= steps) {
        setDisplay(end);
        clearInterval(timer);
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [value]);

  return <span>{display.toLocaleString()}</span>;
}

export default function Hero() {
  const [current, setCurrent] = useState(0);
  const [stats, setStats] = useState({
    loads: 1200,
    trucks: 350,
    users: 5400,
    transactions: 8700,
  });
  const [trackingnumber, setTrackingnumber] = useState(""); 
  const [istracking, setIsTracking] = useState(false);

  const router = useRouter();

  // const router = useRouter();

  const trackItem = () => {
    setIsTracking(true);
    if (trackingnumber.trim() !== "") {
      router.push(`/tracking?id=${trackingnumber}`);
    } 
    setIsTracking(false);
  };

  const nextSlide = () => setCurrent((prev) => (prev + 1) % slides.length);
  const prevSlide = () =>
    setCurrent((prev) => (prev - 1 + slides.length) % slides.length);

  // Auto-update stats every 7s with small increments
  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => ({
        loads: prev.loads + Math.floor(Math.random() * 6 + 5),
        trucks: prev.trucks + Math.floor(Math.random() * 3 + 2),
        users: prev.users + Math.floor(Math.random() * 10 + 5),
        transactions: prev.transactions + Math.floor(Math.random() * 15 + 8),
      }));
    }, 7000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative w-full h-[90vh] overflow-hidden">
      <AnimatePresence>
        <motion.div
          key={current}
          className="absolute inset-0 w-full h-full"
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 1 }}
          style={{
            backgroundImage: `url(${slides[current].image})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          {/* bg-gradient-to-r from-[#06163A]/90 via-[#06163A]/70 to-transparent */}
          {/* Overlay */}
          <div className="absolute inset-0  pointer-events-none" />

          {/* Hero Text */}
          <div className="relative z-20 flex flex-col justify-center h-full px-6 md:px-16 max-w-2xl text-white">
            <motion.h1
              key={slides[current].title}
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.7 }}
              className="text-3xl md:text-5xl font-bold mb-4 leading-tight"
            >
              {slides[current].title}
            </motion.h1>
            <motion.p
              key={slides[current].subtitle}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-base md:text-lg mb-6 text-[#03203b]"
            >
              {slides[current].subtitle}
            </motion.p>

            {/* Mobile Stats */}
            <div className="mt-10 grid grid-cols-2 gap-6 lg:hidden">
              {Object.entries(stats).map(([key, val], idx) => (
                <div
                  key={idx}
                  className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center border border-white/20"
                >
                  <p className="text-2xl font-bold text-[#D62D30]">
                    <AnimatedNumber value={val} />
                  </p>
                  <p className="text-sm uppercase tracking-wide text-gray-200">
                    {key}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Controls */}
      <div className="absolute inset-0 flex items-center justify-between px-4 z-30">
        <button
          onClick={prevSlide}
          className="p-3 bg-white/20 hover:bg-white/40 rounded-full text-white transition"
        >
          <ChevronLeft size={28} />
        </button>
        <button
          onClick={nextSlide}
          className="p-3 bg-white/20 hover:bg-white/40 rounded-full text-white transition"
        >
          <ChevronRight size={28} />
        </button>
      </div>

      {/* CTA Button */}
      {/* <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => router.push("/joinus")}
        className="absolute z-30 inset-0 bg-[#D62D30] hover:bg-red-700 text-white 
  top-[80%] sm:top-[78%] md:top-[78%] lg:top-[61%]
  left-6 sm:left-8 md:left-14 rounded-full font-semibold w-30 h-10 shadow-lg"
      >
        Get Started
      </motion.button> */}

      <form
        onSubmit={(e) => {
          e.preventDefault();
        }}
        className="
    absolute z-30 flex items-center gap-3 bg-white shadow-lg rounded-2xl p-2
    top-[83%] sm:top-[80%] md:top-[80%] lg:top-[61%]
    left-1/2 -translate-x-1/2   /* Default: center */
    lg:left-20 lg:translate-x-0 /* On large screens: left aligned */
    w-11/12 max-w-md
  "
      >
        <input
          type="text"
          placeholder="Enter your tracking number"
          value={trackingnumber}
          onChange={(e) => setTrackingnumber(e.target.value)}
          className="flex-1 p-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-[#d2dcf0] outline-none"
        />
        <button
          type="submit"
          className="p-3 bg-[#D62D30] text-white rounded-xl cursor-pointer hover:bg-red-700 transition"
          onClick={() => trackItem()}
        >
          {
          istracking ? "Tracking...":"Track"}
        </button>
      </form>

      {/* Dots */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-30">
        {slides.map((_, idx) => (
          <div
            key={idx}
            onClick={() => setCurrent(idx)}
            className={`w-3 h-3 rounded-full cursor-pointer transition ${
              idx === current ? "bg-[#D62D30]" : "bg-white/50"
            }`}
          />
        ))}
      </div>
      {/* new comment */}
      {/* Desktop Stat Pane */}
      {/* bg-[#06163A]/90 */}
      <div className="hidden lg:flex flex-col gap-6 absolute top-1/2 right-10 -translate-y-1/2 z-30  bg-white/10 backdrop-blur-sm backdrop-blur-xl p-6 rounded-2xl shadow-2xl border border-white/10 w-72">
        <div className="border-1 border-lime-100 p-2 rounded-xl bg-[#03203bb8]">
          <h1 className="text-white font-serif">Ash Globe at a glance</h1>
        </div>
        {Object.entries(stats).map(([key, val], idx) => (
          <div key={idx} className="flex flex-col items-start">
            <div className="flex items-start justify-between">
              <div className=" p-6 bg-[#aa00007b] rounded-full ">
                {key === "users" ? (
                  <FaUserAlt size={20} color="#fff" />
                ) : key === "transactions" ? (
                  <FaBook size={20} color="#fff" />
                ) : key === "loads" ? (
                  <FaBox size={20} color="#fff" />
                ) : key === "trucks" ? (
                  <FaTruck size={20} color="#fff" />
                ) : (
                  ""
                )}
              </div>
              <div className="pl-4">
                <p className="text-3xl font-extrabold text-[#D62D30]">
                  <AnimatedNumber value={val} />
                </p>
                <p className="text-sm uppercase tracking-wider text-gray-300">
                  {key}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
