
"use client"

import { BASE_URL } from "@/app/core/api";
// import { truncateText } from "@/app/datatype/frontEndCookiee";
import { loadboard } from "@/app/datatype/loadboards";
import { useState, useRef } from "react";



interface SmartSearchInputProps {
  onChange: (selected: loadboard[]) => void;
}

export default function SmartSearchInput({ onChange }: SmartSearchInputProps) {
  const [value, setValue] = useState("");
  const [suggestions, setSuggestions] = useState<loadboard[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setValue(val);

    if (val.length >= 3) {
      setShowSuggestions(true);
      // Debounce API calls
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(async () => {
        const res = await fetch(`${BASE_URL}/loadboards?q=${val}`);
        const data = await res.json();
        setSuggestions(data.loadboard || []);
      }, 300);
    } else {
      setShowSuggestions(false);
      setSuggestions([]);
    }
  };

  const handleSelect = (item: loadboard) => {
    setValue(item.from_state);
    setShowSuggestions(false);
    onChange([item]);
  };
  const handleClose = () => {
    setShowSuggestions(false);
    setValue("")
  };

  return (
    <div className="relative flex items-center w-full  mx-auto my-2 ">
      <input
        type="text"
        className="w-full pl-2 pr-2 py-2 border rounded focus:outline-none text-[#06163A]"
        placeholder=""
        value={value}
        onChange={handleInputChange}
        autoComplete="off"
      />
      {/* <span className="absolute right-3 text-yellow-500">
        <FaHandSparkles size={22} />
      </span> */}
      {showSuggestions && (
        <ul className="absolute top-full left-0 w-full bg-white border rounded shadow-lg z-10 mt-1">
          <li onClick={() =>   handleClose()} className="font-bold text-[#898e89] text-sm font-serif p-2"> 
            {/* {`"${truncateText(value,20)}"    ${suggestions.length}   result Found`} */}
            </li>
          {suggestions.map((item) => (
            <li
              key={item.id}
              className="px-4 py-2 cursor-pointer hover:bg-gray-100"
              onClick={() => handleSelect(item)}
            >
              {/* <span className="font-semibold">{item.title}</span>
              <span className="ml-2 text-xs text-gray-500">{item.type}</span> */}
              <span className="ml-2 text-xs text-gray-400">{item.from_state}</span>
            </li>
          ))}

         
        </ul>
      )}
    </div>
  );
}