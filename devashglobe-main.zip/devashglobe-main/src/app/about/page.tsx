import React from "react";
import AboutComponent from "@/components/aboutComponent"; 
import TestimonialsComponent from "@/components/testimonialComponent"
import BannerComponent from "@/components/bannerComponent"
import AboutMoreComponent from "@/components/aboutMoreComponent"

export default function AboutUs() {
  return (
     <div className="bg-white text-gray-900 dark:bg-gray-900 dark:text-white min-h-screen">

        {/* banner component */}
        <BannerComponent backgroudImage = "/assets/img/banner/ash-slider.jpg" pageTitle = "About" bannerImage = "/assets/img/banner/pm-bg.png"/>        

        {/* about component */}
        <AboutComponent isAbout={true} />


        {/* about more content component */}
        <AboutMoreComponent />

        {/* testimonial component */}

        <TestimonialsComponent  />
    
     </div>
    
  );
}
