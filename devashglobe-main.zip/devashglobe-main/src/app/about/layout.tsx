import type { Metadata } from "next";

import Header from "../includes/header";
import Footer from "../includes/footer";

import "../globals.css";


export const metadata: Metadata = {
  title: "AshGlobe Logistics",
  description: "Smart Logistics on smart contracts",
};

export default function RootLayout( {children,}: Readonly<{children: React.ReactNode;}> ) {
  
  return (
        <main>
          <Header isHome={true} />
          {children}
          <Footer />
</main>
  );
}
