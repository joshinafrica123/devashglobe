"use client";

import Link from "next/link";

export default function PrivacyPolicy() {
  return (
    <div>
      <section
        className="relative  py-15 bg-transparent"
        // style={{ backgroundImage: `url(/assets/img/banner/ash-slider.jpg)` }}
      >
        <span className="absolute inset-0 bg-transparent] opacity-50"></span>
        <div className="container mx-auto relative z-10 text-center"></div>
        <div className="absolute bottom-18.5  left-0 w-50 h-50"></div>
      </section>

      <div className="bg-gray-50 text-gray-800 px-6 md:px-16 lg:px-32 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <h1 className="text-3xl md:text-4xl font-bold text-[#06163A] mb-6">
            Privacy Policy
          </h1>
          <p className="text-gray-600 mb-10">Effective Date: January 1, 2025</p>

          {/* Intro */}
          <p className="mb-6 leading-relaxed">
            At <span className="font-semibold"> Ash globe </span>, we respect
            your privacy and are committed to protecting the personal
            information you share with us. This Privacy Policy explains how we
            collect, use, disclose, and safeguard your data when you use our
            logistics web application and related services. By accessing or
            using our platform, you agree to the practices outlined below.
          </p>

          {/* Section 1 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            1. Information We Collect
          </h2>
          <p className="mb-4">
            We may collect the following types of information:
          </p>
          <ul className="list-disc list-inside mb-6 space-y-2">
            <li>
              <span className="font-medium">Personal Information:</span> Full
              name, email address, phone number, company details, billing and
              payment details.
            </li>
            <li>
              <span className="font-medium">Account Data:</span> Login
              credentials, profile settings, and communication preferences.
            </li>
            <li>
              <span className="font-medium">Logistics Data:</span> Load
              postings, truck availability, route details, transaction history,
              and communication between shippers and carriers.
            </li>
            <li>
              <span className="font-medium">
                Device & Technical Information:
              </span>{" "}
              IP address, browser type, device identifiers, and app usage
              statistics.
            </li>
            <li>
              <span className="font-medium">Cookies & Tracking:</span> Small
              files stored on your device that help us improve user experience,
              monitor traffic, and deliver personalized services.
            </li>
          </ul>

          {/* Section 2 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            2. How We Use Your Information
          </h2>
          <p className="mb-4">Your information may be used to:</p>
          <ul className="list-disc list-inside mb-6 space-y-2">
            <li>Provide, maintain, and improve our logistics services.</li>
            <li>
              Match loads with available trucks and streamline dispatching.
            </li>
            <li>Facilitate secure transactions and process payments.</li>
            <li>
              Communicate with you about account activity, system updates, and
              service alerts.
            </li>
            <li>
              Personalize your experience with recommendations and insights.
            </li>
            <li>
              Detect, prevent, and address fraud, security risks, or technical
              issues.
            </li>
            <li>
              Comply with legal obligations and enforce our Terms of Service.
            </li>
          </ul>

          {/* Section 3 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            3. Sharing of Information
          </h2>
          <p className="mb-4">
            We do not sell your personal data. However, we may share information
            with:
          </p>
          <ul className="list-disc list-inside mb-6 space-y-2">
            <li>
              <span className="font-medium">Business Partners:</span> Shippers,
              carriers, and brokers for the purpose of fulfilling logistics
              operations.
            </li>
            <li>
              <span className="font-medium">Service Providers:</span> Payment
              processors, hosting services, analytics providers, and IT support
              teams.
            </li>
            <li>
              <span className="font-medium">Legal Compliance:</span> Authorities
              or regulators when required by law, court order, or to protect our
              rights.
            </li>
            <li>
              <span className="font-medium">Corporate Transactions:</span> In
              case of mergers, acquisitions, or asset transfers, your data may
              be part of the transferred assets.
            </li>
          </ul>

          {/* Section 4 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            4. Data Retention
          </h2>
          <p className="mb-6">
            We retain your information for as long as necessary to provide our
            services, comply with legal obligations, resolve disputes, and
            enforce agreements. When your data is no longer required, we
            securely delete or anonymize it.
          </p>

          {/* Section 5 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            5. Security of Information
          </h2>
          <p className="mb-6">
            We implement appropriate administrative, technical, and physical
            safeguards to protect your data against unauthorized access,
            disclosure, alteration, or destruction. While we strive to secure
            your information, no online system is 100% safe, and we cannot
            guarantee absolute security.
          </p>

          {/* Section 6 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            6. Your Rights
          </h2>
          <p className="mb-4">
            Depending on your jurisdiction, you may have rights to:
          </p>
          <ul className="list-disc list-inside mb-6 space-y-2">
            <li>Access the personal data we hold about you.</li>
            <li>Request corrections to inaccurate or incomplete data.</li>
            <li>
              Request deletion of your information, subject to legal limits.
            </li>
            <li>Restrict or object to how your information is processed.</li>
            <li>Withdraw consent for optional data processing activities.</li>
          </ul>

          {/* Section 7 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            7. Cookies & Tracking
          </h2>
          <p className="mb-6">
            We use cookies and similar technologies to remember preferences,
            analyze traffic patterns, and improve performance. You can control
            or disable cookies through your browser settings, but some features
            of the platform may not function correctly without them.
          </p>

          {/* Section 8 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            8. Third-Party Links
          </h2>
          <p className="mb-6">
            Our platform may contain links to third-party websites or services.
            Please note that we are not responsible for the privacy practices of
            those third parties, and we encourage you to review their policies
            before sharing personal data.
          </p>

          {/* Section 9 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            9. International Data Transfers
          </h2>
          <p className="mb-6">
            If you access our services outside of the United States, your
            information may be transferred to and stored in countries with
            different data protection laws. We take measures to ensure that such
            transfers comply with applicable laws and safeguard your
            information.
          </p>

          {/* Section 10 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            10. Updates to This Policy
          </h2>
          <p className="mb-6">
            {`We may update this Privacy Policy from time to time. Any changes will
          be posted on this page with an updated "Effective Date." We encourage
          you to review this policy periodically to stay informed about how we
          protect your data.`}
          </p>

          {/* Section 11 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            11. Contact Us
          </h2>
          <p className="mb-6">
            If you have any questions or concerns regarding this Privacy Policy
            or your personal information, please contact us at:
          </p>
          <p className="mb-2">
            <span className="font-medium">Email:</span> support@yourcompany.com
          </p>
          <p className="mb-10">
            <span className="font-medium">Address:</span> [Your Company Address]
          </p>

          {/* Back Link */}
          <Link
            href="/"
            className="text-[#D62D30] font-semibold hover:underline"
          >
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
