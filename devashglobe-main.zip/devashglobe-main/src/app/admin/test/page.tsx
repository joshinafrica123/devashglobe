
"use client"

// import ApiData from '@/app/api/loadboard/data'
// import { useRouter } from "next/navigation";
// import { useState } from "react";
// import Image from "next/image";
// import { FaCloudDownloadAlt, FaMapMarkerAlt, FaTrash } from "react-icons/fa";

export default function sample () {

    // const router = useRouter();
    //   const [filter, setFilter] = useState('All');
    //   const [sortAsc, setSortAsc] = useState(true);
    
    //   const filteredContracts = ApiData.contracts
    //   .filter((contract) => filter === 'All' || contract.status === filter)
    //   .sort((a, b) => {
    //     const dateA = new Date(a.date).getTime();
    //     const dateB = new Date(b.date).getTime();
    //     return sortAsc ? dateA - dateB : dateB - dateA;
    //   });
    
    
    //   const handleRowClick = (id: string) => {
    //     const contractId = id.replace('#', '');
    //     router.push(`/contracts/${contractId}`);
      // };

    return (
          <>
          </>

          
// <div className="w-full overflow-hidden bg-white dark:bg-[#06163A] rounded-md shadow-sm">
//   <div className="w-full overflow-x-auto">
//     <table className="min-w-[1000px] w-full text-sm text-left border-collapse">
//       <thead className="bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white">
//         <tr>
//           <th className="py-2 px-3">Contract ID</th>
//           <th className="py-2 px-3">Load</th>
//           <th className="py-2 px-3">Shipper</th>
//           <th className="py-2 px-3">Carrier</th>
//           <th className="py-2 px-3">Truck</th>
//           <th
//             className="py-2 px-3 cursor-pointer hover:text-[#D62D30]"
//             onClick={() => setSortAsc(!sortAsc)}
//           >
//             Date {sortAsc ? '↑' : '↓'}
//           </th>
//           <th className="py-2 px-3">Location</th>
//           <th className="py-2 px-3">Price</th>
//           <th className="py-2 px-3">Status</th>
//           <th className="py-2 px-3">Action</th>
//         </tr>
//       </thead>
//       <tbody className="text-gray-700 dark:text-gray-200">
//         {filteredContracts.map((contract) => (
//           <tr
//             key={contract.id}
//             onClick={() => handleRowClick(contract.id)}
//             className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-[#0b1f41] cursor-pointer"
//           >
//             <td className="py-3 px-3">{contract.id}</td>
//             <td className="py-3 px-3">
//               <div className="flex items-center gap-2">
//                 <Image
//                   src={contract.load}
//                   alt="Load"
//                   width={40}
//                   height={40}
//                   className="rounded"
//                 />
//                 <span>{contract.title}</span>
//               </div>
//             </td>
//             <td className="py-3 px-3">{contract.shipper}</td>
//             <td className="py-3 px-3">{contract.carrier}</td>
//             <td className="py-3 px-3">
//               <Image
//                 src={contract.truck}
//                 alt="Truck"
//                 width={40}
//                 height={40}
//                 className="rounded"
//               />
//             </td>
//             <td className="py-3 px-3 whitespace-nowrap">
//               {new Date(contract.date).toDateString()}
//             </td>
//             <td className="py-3 px-3 flex items-center gap-1">
//               <FaMapMarkerAlt  className="text-[#D62D30]" />
//               <span>{contract.location}</span>
//             </td>
//             <td className="py-3 px-3">{contract.price}</td>
//             <td className="py-3 px-3">
//               <span
//                 className={`px-3 py-1 rounded-full text-xs font-medium ${
//                   contract.status === 'Pending'
//                     ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-700 dark:text-white'
//                     : contract.status === 'Completed'
//                     ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-white'
//                     : 'bg-blue-100 text-blue-800 dark:bg-blue-700 dark:text-white'
//                 }`}
//               >
//                 {contract.status}
//               </span>
//             </td>
//             <td className="py-3 px-3">
//               <div
//                 className="flex items-center gap-3 text-gray-500 dark:text-gray-300"
//                 onClick={(e) => e.stopPropagation()}
//               >
//                 <button>
//                   <FaTrash />
//                 </button>
//                 <button>
//                   <FaCloudDownloadAlt />
//                 </button>
//               </div>
//             </td>
//           </tr>
//         ))}
//       </tbody>
//     </table>
//   </div>

//   {filteredContracts.length === 0 && (
//     <div className="text-center text-sm text-gray-500 dark:text-gray-300 mt-4">
//       No contracts found.
//     </div>
//   )}
// </div>


    );
}