"use client";
import { FaMapMarkerAlt, FaTrashAlt } from "react-icons/fa";

import { useEffect, useState } from "react";
import Image from "next/image";
import { loadboard } from "@/app/datatype/loadboards";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { MdRemoveRedEye } from "react-icons/md";
import { Dialog } from "@headlessui/react";
import { apiCall, BASE_URL } from "@/app/core/api";
import responce from "@/app/datatype/response";
import { filterLoadboardByType } from "@/app/core/util";



const x : loadboard = {
  id: 0,
  account_id:0,
    type:"", 
    equipment_id:1, 
    date_upper_range:"", 
    date_lower_range:"",
    from_state:"",
    to_state:"",
    from_city:"",
    to_city:"",
    title:"",
    type_load:"",
    size:0,
    long_lat:"",
    price_upper_range:"",
    price_best_range:"",
    price_low_range:"",
    image:"",
    track_id: "",
    status: "",
    date: "",
    deleted: 0,
    updated_at: ""

};


export default function TruckPage() {

  const [filter, setFilter] = useState('All');
  const [sortAsc, setSortAsc] = useState(true);
   const [loadboards, setLoadboards] = useState<loadboard[]>([]);
    const [trucks, setTrucks] = useState<loadboard[]>([]);
    const [Trucking,setTrucking] =useState(false);
    const [errors,setErrors] = useState<string[]>([]);
     const [selectedTruck, setSelectedTruck] = useState<loadboard>(x);
      const [viewModalOpen, setViewModalOpen] = useState(false);
      const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  const filteredTrucks = trucks?.filter((truck) => filter === 'All' || truck.status === filter)
  .sort((a, b) => {
    const dateA = new Date(a.date).getTime();
    const dateB = new Date(b.date).getTime();
    return sortAsc ? dateA - dateB : dateB - dateA;
  });

      const handleView = (Truck: loadboard) => {
      setSelectedTruck(Truck);
      setViewModalOpen(true);
    };
  
    const handleDelete = (Truck: loadboard) => {
      setSelectedTruck(Truck);
      setDeleteModalOpen(true);
    };
  
    const confirmDelete = () => {
      alert(`Truck ${selectedTruck?.id} deleted (simulate)`);
      setDeleteModalOpen(false);
    };
  
  useEffect(()=>{
    handleGetloadboard();
  },[])

  // const handleRowClick = (id: string) => {
  //   const truckId = id.replace('#', '');
  //   router.push(`/Truck/${truckId}`);
  // };
  
    const setLoadTruct = (x:loadboard[]) => {
        console.log(loadboards);
        setTrucks(filterLoadboardByType(x,"truck"));
    }

   async function handleGetloadboard() {
    setTrucking(true)
    try {
      const token = getCookie("not_usertoken");

      const response = await apiCall(token + "", `${BASE_URL}/Loadboards`, "GET", null);
     
      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }
      const data = await response.json();
      const dataTypeed = data as responce;
      if (dataTypeed.error) {
        setErrors([dataTypeed.error]);
      } else {
          setLoadboards(dataTypeed.loadboard);
          setLoadTruct(dataTypeed.loadboard);
          setTrucking(false);

      }
    } catch (error) {
      setTrucking(false);
      console.error("faq error:", error);
      console.error("faq error:", errors);
    }
  }
    return (
    <>
      <div className="bg-white shadow rounded-lg p-4 mb-4">
        <h1 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
            Trucks
        </h1>


          <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-semibold text-[#06163A] dark:text-white">
                    All Customer Trucks
                  </h2>
                  
                  {/* <span className="text-xl text-gray-400">⋮</span>  FOR FUTURE PURPOSE!!!!! */} 
        
                    <select
                      className="bg-gray-100 dark:bg-[#112244] text-sm p-2 rounded text-[#06163A] dark:text-white"
                      value={filter}
                      onChange={(e) => setFilter(e.target.value)}
                    >
                      <option value="All">All Statuses</option>
                      {/* <option value="Pending">Pending</option>
                      <option value="Dispatched">Dispatched</option>
                      <option value="Completed">Completed</option> */}
                    </select>
                  
        
        
          </div>


          <div className="w-full overflow-hidden bg-white dark:bg-[#06163A] rounded-md shadow-sm">
        <div className="w-full overflow-x-auto">
           <table className="min-w-[1000px] w-full text-sm text-left border-collapse">
                      <thead className="bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white">
                        <tr>
                          <th className="py-2 px-3">Truck ID</th>
                          <th className="py-2 px-3">Truck </th>
                          <th className="py-2 px-3">Lowest Price</th>
                          <th className="py-2 px-3">Highest price</th>
                          <th
                            className="py-2 px-3 cursor-pointer hover:text-[#D62D30]"
                            onClick={() => setSortAsc(!sortAsc)}
                          >
                            Date {sortAsc ? '↑' : '↓'}
                          </th>
                          <th className="py-2 px-3">Location</th>
                          <th className="py-2 px-3">Price</th>
                          <th className="py-2 px-3">Status</th>
                          <th className="py-2 px-3">Action</th>
                        </tr>
                      </thead>
                      {
                        Trucking ? (
                            <p>searhing...</p>
                        ):(
                      <tbody className="text-gray-700 dark:text-gray-200">
                        {filteredTrucks?.map((Truck) => (
                          <tr
                            key={Truck.id}
                            className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-[#0b1f41] cursor-pointer"
                          >
                            <td className="py-3 px-3">{Truck.id}</td>
                            <td className="py-3 px-3">
                              <div className="flex items-center gap-2">
                                <Image
                                  src={Truck.image}
                                  alt="Truck"
                                  width={40}
                                  height={40}
                                  className="rounded"
                                />
                                <span>{Truck.title || Truck.long_lat}</span>
                              </div>
                            </td>
                            <td className="py-3 px-3">${Truck.price_low_range}</td>
                            <td className="py-3 px-3">${Truck.price_upper_range}</td>
                           
                            <td className="py-3 px-3 whitespace-nowrap">
                              {new Date(Truck.date).toDateString()}
                            </td>
                            <td className="py-3 px-3 flex items-center gap-1">
                              <FaMapMarkerAlt className="text-[#D62D30]" />
                              <span>{Truck.long_lat}</span>
                            </td>
                            <td className="py-3 px-3">${Truck.price_best_range}</td>
                            <td className="py-3 px-3">
                              <span
                                className={`px-3 py-1 rounded-full text-xs font-medium ${
                                  Truck.status === '0'
                                    ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-700 dark:text-white'
                                    : Truck.status === 'Completed'
                                    ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-white'
                                    : 'bg-blue-100 text-blue-800 dark:bg-blue-700 dark:text-white'
                                }`}
                              >
                                {Truck.status == "0"? "new":Truck.status}
                              </span>
                            </td>
                          <td className="py-3 px-4 text-center">
                            <div className="flex justify-center gap-3 text-xl">
                              <button
                                onClick={() => handleView(Truck)}
                                className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                              >
                                <MdRemoveRedEye />
                              </button>
                              <button
                                onClick={() => handleDelete(Truck)}
                                className="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                              >
                                <FaTrashAlt />
                              </button>
                            </div>
                          </td>
                          </tr>
                        ))}
                      </tbody>
                      )}
                    </table>
        </div>
      
        {filteredTrucks?.length === 0 && (
          <div className="text-center text-sm text-gray-500 dark:text-gray-300 mt-4">
            No Truck found yet.
          </div>
        )}
      </div>




                {/* View Modal */}
                <Dialog open={viewModalOpen} onClose={() => setViewModalOpen(false)} onClick={() => setViewModalOpen(false)} className="fixed z-50 inset-0 flex items-center justify-center">
                  <div className="bg-black bg-opacity-50 fixed inset-0" />
                  <div className="bg-white dark:bg-[#06163A] p-6 rounded-lg z-10 max-w-sm mx-auto">
                    <Dialog.Title className="text-lg font-bold text-[#06163A] dark:text-white">Truck Details</Dialog.Title>
                    {selectedTruck && (
                      <div className="mt-4 space-y-2 text-sm dark:text-gray-200">
                        <p><strong>ID:</strong> {selectedTruck.id}</p>
                        <p><strong>Lowest Price:</strong> {selectedTruck.price_low_range}</p>
                        <p><strong>Highest price:</strong> {selectedTruck.price_upper_range}</p>
                        <p><strong>Date:</strong> {selectedTruck.date}</p>
                        <p><strong>Location:</strong> {selectedTruck.long_lat}</p>
                        <p><strong>Price:</strong> {selectedTruck.price_best_range}</p>
                        <p><strong>Status:</strong> {selectedTruck.status == "0"?"new":selectedTruck.status}</p>
                      </div>
                    )}
                    <div className="mt-4 text-right">
                      <button onClick={() => setViewModalOpen(false)} className="text-sm px-4 py-2 bg-gray-300 dark:bg-gray-600 rounded">
                        Close
                      </button>
                    </div>
                  </div>
                </Dialog>
          
                {/* Delete Modal */}
                <Dialog open={deleteModalOpen} onClose={() => setDeleteModalOpen(false)} onClick={() => setViewModalOpen(false)}  className="fixed z-50 inset-0 flex items-center justify-center">
                  <div className="bg-black bg-opacity-50 fixed inset-0" />
                  <div className="bg-white dark:bg-[#06163A] p-6 rounded-lg z-10 max-w-sm mx-auto">
                    <Dialog.Title className="text-lg font-bold text-red-600 dark:text-red-400">Delete Confirmation</Dialog.Title>
                    <p className="mt-4 text-sm text-gray-700 dark:text-gray-300">
                      Are you sure you want to delete Truck <strong>{selectedTruck?.id}</strong>?
                    </p>
                    <div className="mt-6 flex justify-end gap-2">
                      <button onClick={() => setDeleteModalOpen(false)} className="px-4 py-2 text-sm bg-gray-300 dark:bg-gray-600 rounded">
                        Cancel
                      </button>
                      <button onClick={confirmDelete} className="px-4 py-2 text-sm bg-red-600 text-white rounded">
                        Delete
                      </button>
                    </div>
                  </div>
                </Dialog>
            

      </div>



      

    </>
    );


}


