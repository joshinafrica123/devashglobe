"use client";

import { useRouter } from "next/navigation";
import { FaFolder } from "react-icons/fa";

export default function ContactPage() {
  const router = useRouter();
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Main Content */}
      <main className="p-4 sm:p-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-xl sm:text-2xl font-bold text-[#06163A]">
            Compliance Overview
          </h2>
          <p className="text-sm sm:text-base text-gray-600 mt-1">
            Monitor verification status, expired documents, and compliance risks.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Document Submitted", value: 200 },
            { label: "Verified / Approved", value: 15 },
            { label: "Expired Documents", value: 85 },
            { label: "Rejected Documents", value: 15 },
          ].map((x, i) => (
            <div
              key={i}
              onClick={() => {router.push('/admin/contact/documents')}}
              className="bg-white p-4 rounded-xl shadow flex flex-col cursor-pointer hover:shadow-md transition"
            >
              <p className="text-sm text-gray-500 mb-4">{x.label}</p>
              <h3 className="text-2xl font-bold mt-2">{x.value}</h3>
            </div>
          ))}
        </div>

        {/* Section title */}
        <h2 className="text-lg sm:text-xl text-[#06163A] mb-4">
          Recently Uploaded Documents
        </h2>

        {/* Table Wrapper */}
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="min-w-[700px] w-full text-sm text-left">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-4 font-semibold text-gray-600">Folder Type</th>
                <th className="p-4 font-semibold text-gray-600">Role</th>
                <th className="p-4 font-semibold text-gray-600">Docs</th>
                <th className="p-4 font-semibold text-gray-600">
                  Date & Time
                </th>
              </tr>
            </thead>

            <tbody>
              {[
                { file: "KYC DOCUMENTS.pdf", role: "Merchant", doc: "3/6" },
                { file: "COMPLIANCE DOCUMENTS.pdf", role: "Shipper", doc: "2/6" },
                { file: "KYC DOCUMENTS.pdf", role: "Carrier", doc: "6/6" },
                { file: "COMPLIANCE DOCUMENTS.pdf", role: "Shipper", doc: "2/6" },
                { file: "KYC DOCUMENTS.pdf", role: "Carrier", doc: "6/6" },
                { file: "COMPLIANCE DOCUMENTS.pdf", role: "Shipper", doc: "2/6" },
                { file: "KYC DOCUMENTS.pdf", role: "Carrier", doc: "6/6" },
              ].map((row, i) => (
                <tr
                  key={i}
                  className="border-t hover:bg-gray-50 transition"
                >
                  <td className="p-4 flex items-center gap-2">
                    <FaFolder className="text-slate-600 shrink-0" />
                    <span className="whitespace-nowrap">{row.file}</span>
                  </td>
                  <td className="p-4">{row.role}</td>
                  <td className="p-4">{row.doc}</td>
                  <td className="p-4 whitespace-nowrap">
                    10/12/2025 – 10:30 AM
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
