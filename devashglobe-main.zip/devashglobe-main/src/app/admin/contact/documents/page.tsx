"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { FaFilter, FaFolder, FaSearch } from "react-icons/fa";

export default function DocumentsPage() {
  const router = useRouter();

  const [search, setSearch] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  console.log(search);
  console.log(filterOpen);

  return (
    <div className="p-4 md:p-6">
      <div className="mb-4 flex justify-items-start items-center">
        <FaFolder size={20} color="#8C8C8C" />
        <p
          onClick={() => router.push("/admin/contact/")}
          className="text-xl text-[#8C8C8C] m-5 cursor-pointer"
        >
          Compliance
        </p>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={1.5}
          stroke="#8C8C8C"
          className="w-5 h-5"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
        </svg>
        <h2 className="text-xl font-semibold text-[#06163A] dark:text-white">
          Documents Submitted
        </h2>
      </div>

      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-5 gap-2">
        <div>
          <h3 className="text-lg font-semibold text-[#06163A] dark:text-white"></h3>
        </div>

        <div>
          <div className="flex m-3  text-sm text-gray-500 dark:text-gray-300">
            {/* SEARCH INPUT */}
            <div className="relative">
              <FaSearch className="absolute left-2 top-2.5 text-gray-400 text-sm" />
              <input
                type="text"
                placeholder="Search..."
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 pr-3 py-2 text-sm rounded-md border dark:bg-[#112244] text-gray-700 dark:text-white outline-none"
              />
            </div>
            {/* FILTER BUTTON */}
            <button
              onClick={() => setFilterOpen(true)}
              className="flex justify-between items-end ml-4  p-2 rounded-md border dark:bg-[#112244] text-[#475569] dark:text-white hover:bg-gray-200 dark:hover:bg-[#0b1f41] transition"
            >
              Filter
              <FaFilter size={12} className="mb-1 mr-2 ml-2" />
            </button>
          </div>
        </div>
      </div>

      {/* Table Wrapper */}
      <div className="bg-white rounded-xl shadow overflow-x-auto">
        <table className="min-w-[700px] w-full text-sm text-left">
          <thead className="bg-gray-50">
            <tr>
              <th className="p-4 font-semibold text-gray-600">Folder Type</th>
              <th className="p-4 font-semibold text-gray-600">User</th>
              <th className="p-4 font-semibold text-gray-600">Role</th>
              <th className="p-4 font-semibold text-gray-600">Status</th>
              <th className="p-4 font-semibold text-gray-600">Date & Time</th>
              <th className="p-4 font-semibold text-gray-600">Size</th>
            </tr>
          </thead>

          <tbody>
            {[
              { file: "KYC DOCUMENTS.pdf", user: "John Doe", role: "Merchant", doc: "3/6", status: "Completed", size: "1.2MB" },
              { file: "COMPLIANCE DOCUMENTS.pdf", user: "Jane Smith", role: "Shipper", doc: "2/6", status: "In Progress", size: "800KB" },
              { file: "KYC DOCUMENTS.pdf", user: "Alice Johnson", role: "Carrier", doc: "6/6", status: "Completed", size: "1.5MB" },
              { file: "COMPLIANCE DOCUMENTS.pdf", user: "Bob Brown", role: "Shipper", doc: "2/6", status: "In Progress", size: "800KB" },
              { file: "KYC DOCUMENTS.pdf", user: "Charlie Davis", role: "Carrier", doc: "6/6", status: "Completed", size: "1.5MB" },
              { file: "COMPLIANCE DOCUMENTS.pdf", user: "David Wilson", role: "Shipper", doc: "2/6", status: "In Progress", size: "800KB" },
              { file: "KYC DOCUMENTS.pdf", user: "Eve Adams", role: "Carrier", doc: "6/6", status: "Completed", size: "1.5MB" },
              { file: "KYC DOCUMENTS.pdf", user: "Charlie Davis", role: "Carrier", doc: "6/6", status: "Completed", size: "1.5MB" },
              { file: "COMPLIANCE DOCUMENTS.pdf", user: "David Wilson", role: "Shipper", doc: "2/6", status: "In Progress", size: "800KB" },
              { file: "KYC DOCUMENTS.pdf", user: "Eve Adams", role: "Carrier", doc: "6/6", status: "Completed", size: "1.5MB" },
            ].map((row, i) => (
              <tr key={i} className="border-t hover:bg-gray-50 transition">
                <td className="p-4 flex items-center gap-2">
                  <FaFolder className="text-slate-600 shrink-0" />
                  <span className="whitespace-nowrap">{row.file}</span>
                </td>
                <td className="p-4">{row.user}</td>
                <td className="p-4">{row.role}</td>
                <td className={`p-4 whitespace-nowrap `}><span className={` ${row.status === "Completed" ? "text-[#027A48]" : "text-[#F59E0B]"} p-2 rounded-xl ${row.status === "Completed" ? "bg-[#ECFDF3]" : "bg-[#FFFBEB]"}`}>{row.status}</span></td>
                <td className="p-4"> 13/1/2023 at 10:30 AM</td>
                <td className="p-4 whitespace-nowrap">{row.size}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
