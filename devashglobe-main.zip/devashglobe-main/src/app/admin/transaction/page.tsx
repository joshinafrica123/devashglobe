"use client";

import {Contracts} from '@/app/datatype/data'
import { useState } from "react";
import Image from "next/image";


import { MdLocationPin, MdRemoveRedEye } from 'react-icons/md';
import { FaTrashAlt } from 'react-icons/fa';
import { Dialog } from '@headlessui/react';
import contract from "@/app/datatype/type";

export default function TransactionsPage() {

  const [filter, setFilter] = useState('All');
  const [sortAsc, setSortAsc] = useState(true);
  const [contracts] = useState<Contracts[]>([]);

  const filteredContracts = contracts
  .filter((contract) => filter === 'All' || contract.status === filter)
  .sort((a, b) => {
    const dateA = new Date(a.date).getTime();
    const dateB = new Date(b.date).getTime();
    return sortAsc ? dateA - dateB : dateB - dateA;
  });  

  const [currentPage, setCurrentPage] = useState(1);
  const contractsPerPage = 3;
  const indexOfLast = currentPage * contractsPerPage;
  const indexOfFirst = indexOfLast - contractsPerPage;
  const currentContracts = filteredContracts.slice(indexOfFirst, indexOfLast);

  const [selectedContract, setSelectedContract] = useState(contracts[0]);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  const handleView = (contract: contract) => {
    setSelectedContract(contract);
    setViewModalOpen(true);
  };

  const handleDelete = (contract: contract) => {
    setSelectedContract(contract);
    setDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    alert(`Contract ${selectedContract?.id} deleted (simulate)`);
    setDeleteModalOpen(false);
  };

  return (
    <div className="p-4 md:p-6">
      <div className="mb-4 flex justify-between items-center">
        <h2 className="text-xl font-semibold text-[#06163A] dark:text-white">
          Transaction
        </h2>
      </div>

      <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-semibold text-[#06163A] dark:text-white">
                    All smart contracts
                  </h2>
                  
                  {/* <span className="text-xl text-gray-400">⋮</span>  FOR FUTURE PURPOSE!!!!! */} 
        
                    <select
                      className="bg-gray-100 dark:bg-[#112244] text-sm p-2 rounded text-[#06163A] dark:text-white"
                      value={filter}
                      onChange={(e) => setFilter(e.target.value)}
                    >
                      <option value="All">All Statuses</option>
                      <option value="Pending">Pending</option>
                      <option value="Dispatched">Dispatched</option>
                      <option value="Completed">Completed</option>
                    </select>
                  
        
        
      </div>

      <p className="text-xs text-gray-500 mb-2 md:hidden">📱 Swipe to scroll →</p>

      <div className="overflow-x-auto w-full bg-white dark:bg-[#06163A] rounded-lg shadow-md">
        <table className="min-w-[1000px] w-full text-sm text-left border-collapse">
          <thead className="bg-[#06163A] text-white sticky top-0 z-10">
            <tr>
              <th className="py-3 px-4">Contract ID</th>
              <th className="py-3 px-4">Load</th>
              <th className="py-2 px-3">Shipper</th>
              <th className="py-2 px-3">Carrier</th>
              <th className="py-3 px-4">Truck</th>
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4">Location</th>
              <th className="py-3 px-4">Price</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="text-gray-700 dark:text-gray-200">
            {currentContracts.map((contract, index) => (
              <tr
                key={contract.id}
                className={`border-b hover:bg-gray-100 dark:hover:bg-[#1A1E3D] ${
                  index % 2 === 0 ? 'bg-white dark:bg-[#0B1126]' : 'bg-gray-50 dark:bg-[#11193E]'
                }`}
              >
                <td className="py-3 px-4 font-medium">{contract.id}</td>
                <td className="py-3 px-4">
                  <Image src={contract.load} alt="Load" width={40} height={40} className="rounded" />
                </td>
                <td className="py-3 px-4">{contract.shipper}</td>
                <td className="py-3 px-4">{contract.carrier}</td>
                <td className="py-3 px-4">
                  <Image src={contract.truck} alt="Truck" width={40} height={40} className="rounded" />
                </td>
                <th
                  className="py-2 px-3 cursor-pointer hover:text-[#D62D30]"
                  onClick={() => setSortAsc(!sortAsc)}
                >
                  {contract.date} {sortAsc ? '↑' : '↓'}
                </th>
                <td className="py-3 px-4 flex items-center gap-1">
                  <MdLocationPin className="text-lg text-red-500" />
                  {contract.location}
                </td>
                <td className="py-3 px-4 font-semibold">{contract.price}</td>
                <td className="py-3 px-4">
                  <span
                    className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      contract.status === 'Completed'
                        ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-white'
                        : contract.status === 'Pending'
                        ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-700 dark:text-white'
                        : contract.status === 'Canceled'
                        ? 'bg-red-100 text-red-800 dark:bg-red-700 dark:text-white'
                        : 'bg-blue-100 text-blue-800 dark:bg-blue-700 dark:text-white'
                    }`}
                  >
                    {contract.status}
                  </span>
                </td>
                <td className="py-3 px-4 text-center">
                  <div className="flex justify-center gap-3 text-xl">
                    <button
                      onClick={() => handleView(contract)}
                      className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      <MdRemoveRedEye />
                    </button>
                    <button
                      onClick={() => handleDelete(contract)}
                      className="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                    >
                      <FaTrashAlt />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
            {filteredContracts.length === 0 && (
            <div className="text-center text-sm text-gray-500 mt-4">No contracts found yet.</div>
          )}
      </div>

      {/* Pagination Controls */}
      <div className="flex justify-center mt-4 gap-2">
        {Array.from({ length: Math.ceil(contracts.length / contractsPerPage) }, (_, i) => (
          <button
            key={i}
            onClick={() => setCurrentPage(i + 1)}
            className={`px-3 py-1 rounded ${
              currentPage === i + 1
                ? 'bg-[#D62D30] text-white'
                : 'bg-gray-200 dark:bg-gray-600 dark:text-white'
            }`}
          >
            {i + 1}
          </button>
        ))}
      </div>

      {/* View Modal */}
      <Dialog open={viewModalOpen} onClose={() => setViewModalOpen(false)} onClick={() => setViewModalOpen(false)} className="fixed z-50 inset-0 flex items-center justify-center">
        <div className="bg-black bg-opacity-50 fixed inset-0" />
        <div className="bg-white dark:bg-[#06163A] p-6 rounded-lg z-10 max-w-sm mx-auto">
          <Dialog.Title className="text-lg font-bold text-[#06163A] dark:text-white">Load Details</Dialog.Title>
          {selectedContract && (
            <div className="mt-4 space-y-2 text-sm dark:text-gray-200">
              <p><strong>ID:</strong> {selectedContract.id}</p>
              <p><strong>Shipper:</strong> {selectedContract.shipper}</p>
              <p><strong>Carrier:</strong> {selectedContract.carrier}</p>
              <p><strong>Date:</strong> {selectedContract.date}</p>
              <p><strong>Location:</strong> {selectedContract.location}</p>
              <p><strong>Price:</strong> {selectedContract.price}</p>
              <p><strong>Status:</strong> {selectedContract.status}</p>
            </div>
          )}
          <div className="mt-4 text-right">
            <button onClick={() => setViewModalOpen(false)} className="text-sm px-4 py-2 bg-gray-300 dark:bg-gray-600 rounded">
              Close
            </button>
          </div>
        </div>
      </Dialog>

      {/* Delete Modal */}
      <Dialog open={deleteModalOpen} onClose={() => setDeleteModalOpen(false)} onClick={() => setViewModalOpen(false)} className="fixed z-50 inset-0 flex items-center justify-center">
        <div className="bg-black bg-opacity-50 fixed inset-0" />
        <div className="bg-white dark:bg-[#06163A] p-6 rounded-lg z-10 max-w-sm mx-auto">
          <Dialog.Title className="text-lg font-bold text-red-600 dark:text-red-400">Delete Confirmation</Dialog.Title>
          <p className="mt-4 text-sm text-gray-700 dark:text-gray-300">
            Are you sure you want to delete contract <strong>{selectedContract?.id}</strong>?
          </p>
          <div className="mt-6 flex justify-end gap-2">
            <button onClick={() => setDeleteModalOpen(false)} className="px-4 py-2 text-sm bg-gray-300 dark:bg-gray-600 rounded">
              Cancel
            </button>
            <button onClick={confirmDelete} className="px-4 py-2 text-sm bg-red-600 text-white rounded">
              Delete
            </button>
          </div>
        </div>
      </Dialog>

    </div>
  );


}









