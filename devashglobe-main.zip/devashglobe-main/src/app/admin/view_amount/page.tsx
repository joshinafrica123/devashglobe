export default function payNow () {

    return (
        <>
            Pay now
        </>
    )

}