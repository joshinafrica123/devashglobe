"use client";

import { useEffect, useState } from "react";
// import Image from "next/image";

// import { MdRemoveRedEye } from "react-icons/md";
import { FaMapMarked, FaMapPin, FaSearch, FaUserFriends } from "react-icons/fa";
import user from "@/app/datatype/user";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { apiCall, BASE_URL } from "@/app/core/api";
import responce from "@/app/datatype/response";
import { useRouter } from "next/navigation";
// import Image from "next/image";
// import Link from "next/link";
// type responce = {
//   error?: string;
//   user?: user[];
// };

export default function UsersPage() {
  const [filter] = useState("All");
  const [sortAsc] = useState(true);
  const [users, setUser] = useState<user[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  // const [selectedUser, setSelectedUser] = useState<user>(x);
  // const [ setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [filterOpen] = useState(false);
  const count = users?.length || 0;
  //router 
  const router = useRouter();

  console.log(users);

  const filteredUsers = users
    ?.filter((user) => filter === "All" || user.status === filter)
    .sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

  useEffect(() => {
    handleGetUser();
    // setLoading(false);
    console.log(search, filteredUsers, filterOpen);
  }, []);

  async function handleGetUser() {
    try {
      // get logged in admin token
      const token = getCookie("not_usertoken");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/users`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }

      const data = await response.json();
      console.log(data);

      const dataTypeed = data as responce;

      if (dataTypeed.error) {
        const errList: string[] = [dataTypeed?.error];
        setErrors(errList);
      } else {
        console.log(dataTypeed.notuser);
        setUser(dataTypeed.user);
      }
    } catch (error) {
      console.error("equipment error:", error);
      console.error("equipment error:", errors);
    }
  }

  return (
    <div className="p-4 md:p-6">
      <div className="mb-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <FaUserFriends size={20} color="#8C8C8C" />
          <p className="text-xl text-[#8C8C8C] m-5 ">Load Board</p>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="#8C8C8C"
            className="w-5 h-5"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M9 5l7 7-7 7"
            />
          </svg>
          <h2 className="text-xl font-semibold text-[#06163A] dark:text-white">
            Merchant Offers
          </h2>
        </div>

        <div className="ml-3 text-sm text-gray-500 dark:text-gray-300">
          {/* SEARCH INPUT */}
          <div className="relative">
            <FaSearch className="absolute left-2 top-2.5 text-gray-400 text-sm" />
            <input
              type="text"
              placeholder="Search..."
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 pr-3 py-2 text-sm rounded-md border  dark:bg-[#112244] text-gray-700 dark:text-white outline-none"
            />
          </div>
        </div>
      </div>

      <div className="w-full bg-white dark:bg-slate-900 rounded-2xl   border border-[#E8E8E8] dark:border-slate-800 mb-6">
        {/* Header */}
        <div className="flex justify-items-start items-center border-b border-[#E8E8E8] dark:border-slate-700 p-3">
          <h3 className="text-sm font-semibold text-[#000000] dark:text-slate-200">
            Filter Load
          </h3>
          <span className="text-xs px-2 py-0.5 rounded-full  text-[#8A38F5]">
            ({count})
          </span>
        </div>

        {/* Footer Content */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6 p-3">
          <div>
            <p className="text-sm text-[#8C8C8C] mb-3">Filter By</p>
            {/* Select Filter */}
            <select className="w-full text-sm p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent">
              <option>Select Filter</option>
              <option>Merchant</option>
              <option>Shipper</option>
              <option>Carrier</option>
            </select>
          </div>

          <div>
            {/* Select Filter */}
            <p className="text-sm text-[#8C8C8C] mb-3"> Date </p>
            {/* Date */}
            <input
              type="date"
              className="w-full text-sm p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
            />
          </div>

          <div>
            <p className="text-sm text-[#8C8C8C] mb-3">Price</p>
            {/* Price */}
            <input
              type="number"
              placeholder="Enter Price"
              className="w-full text-sm p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
            />
          </div>

          <div className=" flex grid-cols-1">
            <button className=" bg-[#011E4A] text-white text-sm p-2 m-2   hover:bg-[#011e4a9c] transition">
              Apply Filters
            </button>
            <button className=" p-2 m-2  bg-[#fff] text-[#011E4A] text-sm border-2 border-[#011e4a]  hover:bg-gray-400 transition">
              Clear Filters
            </button>
          </div>
        </div>
      </div>

      {/* Boby of tge content  */}
      {[1, 2, 3, 10].map((item) => (
        <div
          key={item}
          className="w-full bg-white dark:bg-slate-900 rounded-2xl p-4 mb-4 border border-[#E8E8E8] dark:border-slate-800"
        >
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:justify-between gap-3 border-b border-[#E8E8E8] dark:border-slate-700 pb-3">
            <div className="space-y-1">
              <p className="text-sm font-semibold text-[#8C8C8C] dark:text-slate-200">
                Date Posted:
                <span className="ml-2 text-xs text-gray-700 dark:text-gray-300">
                  11/11/2025
                </span>
              </p>

              <p className="text-sm font-semibold text-[#8C8C8C] dark:text-slate-200">
                Load ID:
                <span className="ml-2 text-xs text-gray-700 dark:text-gray-300">
                  2798384002
                </span>
              </p>
            </div>

            <div>
              <p className="text-sm font-semibold text-[#8C8C8C] dark:text-slate-200">
                Merchant:
                <span className="ml-2 text-xs text-gray-700 dark:text-gray-300">
                  FastLogix Haulage
                </span>
              </p>
            </div>
          </div>

          {/* Content */}
          <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
            {/* Origin & Destination */}
            <div>
              <p className="text-sm text-[#8C8C8C] mb-4">
                Origin & Destination
              </p>

              <div className="flex items-start gap-2 mb-3">
                <FaMapMarked className="text-[#F19105] mt-1" />
                <p className="text-sm text-[#8C8C8C] dark:text-slate-200">
                  Origin:
                  <span className="ml-2 text-[#8A38F5]">Germany NRT Chan</span>
                </p>
              </div>

              <div className="flex items-start gap-2 mb-3">
                <FaMapPin className="text-[#49AE5F] mt-1" />
                <p className="text-sm text-[#8C8C8C] dark:text-slate-200">
                  Destination:
                  <span className="ml-2 text-[#8A38F5]">USA Charlton 123</span>
                </p>
              </div>

              <p className="text-xs text-[#8C8C8C] dark:text-slate-200">
                Route:
                <span className="ml-2 text-[#8A38F5] underline cursor-pointer" onClick={() => router.push("/admin/offers/location")}>Germany → USA</span>
              </p>
            </div>

            {/* Cargo */}
            <div>
              <p className="text-sm text-[#8C8C8C] mb-4">Cargo</p>

              <p className="text-sm text-[#8C8C8C] dark:text-slate-200 mb-2">
                Cargo Type:
                <span className="ml-2 text-[#404040] dark:text-gray-300">
                  Electronics
                </span>
              </p>

              <p className="text-sm text-[#8C8C8C] dark:text-slate-200">
                Weight:
                <span className="ml-2 text-[#404040] dark:text-gray-300">
                  20 tons
                </span>
              </p>
            </div>

            {/* Dates */}
            <div>
              <p className="text-sm text-[#8C8C8C] mb-4">Dates</p>

              <p className="text-sm text-[#8C8C8C] dark:text-slate-200 mb-2">
                Pick-Up:
                <span className="ml-2 text-[#404040] dark:text-gray-300">
                  12/07/2025
                </span>
              </p>

              <p className="text-sm text-[#8C8C8C] dark:text-slate-200">
                Delivery:
                <span className="ml-2 text-[#404040] dark:text-gray-300">
                  20/07/2025
                </span>
              </p>
            </div>

            {/* Price */}
            <div className="flex items-center justify-center sm:justify-end">
              <div className="w-full sm:w-auto text-center bg-gray-50 dark:bg-slate-800 rounded-xl px-6 py-4 text-xl font-semibold text-[#011E4A] dark:text-white">
                $7,000 – $10,000
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
