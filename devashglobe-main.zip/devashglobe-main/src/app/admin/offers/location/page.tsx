"use client";

import { useEffect } from "react";
import { FaPhoneAlt, FaSearch, FaUserFriends } from "react-icons/fa";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function Location() {
  const router = useRouter();

  useEffect(() => {
    // fetch logic untouched
  }, []);

  return (
    <div className="p-4 md:p-6 overflow-x-hidden">
      {/* HEADER */}
      <div className="mb-4 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <FaUserFriends size={20} className="text-gray-400" />

          <p
            className="text-lg text-gray-400 cursor-pointer"
            onClick={() => router.push("/admin/offers/")}
          >
            Load Board
          </p>

          <span className="text-gray-400">{">"}</span>

          <h2 className="text-lg font-semibold text-[#06163A] dark:text-white">
            Routes
          </h2>
        </div>

        {/* SEARCH */}
        <div className="w-full md:w-64">
          <div className="relative">
            <FaSearch className="absolute left-3 top-3 text-gray-400 text-sm" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-md border dark:bg-[#112244] dark:text-white"
            />
          </div>
        </div>
      </div>

      {/* MAIN GRID */}
      <section className="grid grid-cols-1 lg:grid-cols-[2fr_4fr] gap-6">
        {/* LEFT PANE */}
        <div className="space-y-4 max-h-[500px] overflow-y-auto">
          {[1, 2].map((l) => (
            <div
              key={l}
              className="border border-gray-300 rounded-xl shadow p-4 bg-white dark:bg-[#06163A]"
            >
              {/* CARD HEADER */}
              <div className="flex justify-between items-center mb-3">
                <p className="text-sm text-gray-500">
                  Load ID: <b>1828182</b>
                </p>

                <span className="text-xs bg-green-500 text-white px-2 py-1 rounded-full">
                  Delivered
                </span>
              </div>

              {/* CARD BODY */}
              <div className="border rounded-xl p-3 space-y-4">
                {["Lagos, Nigeria", "Kotoka Airport"].map((loc, i) => (
                  <div key={i} className="flex justify-between items-start">
                    <div>
                      <h4 className="text-sm font-semibold text-purple-500">
                        {loc}
                      </h4>
                      <p className="text-xs text-gray-500">200 Street Lane</p>
                    </div>

                    <div className="text-right">
                      <p className="text-xs font-semibold">Tue Aug 26 2025</p>
                      <p className="text-xs text-gray-500">10:30 AM</p>
                    </div>
                  </div>
                ))}

                {/* PROGRESS */}
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-gray-200 rounded-full">
                    <div className="h-full bg-green-500 w-[70%] rounded-full" />
                  </div>
                  <span className="text-xs text-gray-500">70%</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* RIGHT PANE */}
        <div className="bg-white dark:bg-gray-900 border rounded-xl shadow p-4">
          <h2 className="text-lg font-semibold mb-4">Overview</h2>

          {/* MAP */}
          <div className="aspect-video w-full rounded-lg overflow-hidden border mb-6">
            <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434509374!2d144.9537353155042!3d-37.81627974202171!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf577d6fb4d6d8b0!2sFederation%20Square!5e0!3m2!1sen!2sau!4v1614031234567!5m2!1sen!2sau"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen={false}
                    loading="lazy"
                  ></iframe>
          </div>

          {/* INFO GRID */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { title: "Carrier", name: "Reece James" },
              { title: "Merchant", name: "Jadon Sancho" },
            ].map((x, i) => (
              <div
                key={i}
                className="border rounded-xl p-3 flex items-center gap-3"
              >
                <Image
                  src="/assets/img/banner/c.jpg"
                  alt="profile"
                  width={48}
                  height={48}
                  className="rounded-full"
                />
                <div className="flex-1">
                  <h4 className="font-semibold">{x.name}</h4>
                  <p className="text-sm text-gray-500">FastDrive Int Cargo</p>
                </div>
                <FaPhoneAlt className="text-gray-400" />
              </div>
            ))}
          </div>

          {/* CARGO & PRICE */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="border rounded-xl p-4">
              <h4 className="font-semibold mb-1">Cargo</h4>
              <p className="text-sm text-gray-500">Truck No: TK 0292 4455</p>
            </div>

            <div className="border rounded-xl p-4">
              <h4 className="font-semibold mb-1">Price</h4>
              <p className="text-sm text-gray-500">$2,000</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
 