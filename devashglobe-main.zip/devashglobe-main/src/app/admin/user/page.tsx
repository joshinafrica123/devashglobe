"use client";

import { useEffect, useState } from "react";
// import Image from "next/image";

// import { MdRemoveRedEye } from "react-icons/md";
import {
  FaFilter,
  FaMapMarkerAlt,
  FaSearch,
  FaUserFriends,
} from "react-icons/fa";
import { Dialog } from "@headlessui/react";
import user from "@/app/datatype/user";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { apiCall, BASE_URL } from "@/app/core/api";
import responce from "@/app/datatype/response";
import { useRouter } from "next/navigation";

// import Image from "next/image";
// import Link from "next/link";
// type responce = {
//   error?: string;
//   user?: user[];
// };

// const x: user = {
//   id: 0,
//   name: "",
//   email: "",
//   first_name: "",
//   last_name: "",
//   business_type_id: 1,
//   user_type: "",
//   password_hash: "",
//   phone_number: "",
//   roles: "",
//   photo: "",
//   address_one: "",
//   address_two: "",
//   Means_ID: "",
//   category_business: "",
//   Business_cert: "",
//   list_share_holder: "",
//   licenses: "",
//   img: "",
//   status: "",
//   date: "",
//   type: "",
//   deleted: 0,
//   updated_at: "",
//   isVerified: false,
//   isEmailVerified: false,
// };

export default function UsersPage() {
  const [filter] = useState("All");
  const [sortAsc] = useState(true);
  const [users, setUser] = useState<user[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  // const [selectedUser, setSelectedUser] = useState<user>(x);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);

  const handleRowClick = (userId: number) => {
    console.log("Row clicked for user ID:", userId);
    // Implement further actions, e.g., open a detail view
  };

  console.log(users);

  const filteredUsers = users
    ?.filter((user) => filter === "All" || user.status === filter)
    .sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

  const [currentPage, setCurrentPage] = useState(1);
  const usersPerPage = 10;
  const indexOfLast = currentPage * usersPerPage;
  const indexOfFirst = indexOfLast - usersPerPage;
  const currentContracts = filteredUsers?.slice(indexOfFirst, indexOfLast);
  const router = useRouter();

  // const handleView = (user: user) => {
  //   setSelectedUser(user);
  //   setViewModalOpen(true);
  // };

  // const handleDelete = (user: user) => {
  //   setSelectedUser(user);
  //   setDeleteModalOpen(true);
  // };

  // const confirmDelete = () => {
  //   alert(`Contract ${selectedUser?.id} deleted (simulate)`);
  //   setDeleteModalOpen(false);
  // };

  useEffect(() => {
    handleGetUser();
    setLoading(false);
    console.log(search, filteredUsers, filterOpen);
  }, []);

  async function handleGetUser() {
    try {
      // get logged in admin token
      const token = getCookie("not_usertoken");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/users`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }

      const data = await response.json();
      console.log(data);

      const dataTypeed = data as responce;

      if (dataTypeed.error) {
        const errList: string[] = [dataTypeed?.error];
        setErrors(errList);
      } else {
        console.log(dataTypeed.notuser);
        setUser(dataTypeed.user);
      }
    } catch (error) {
      console.error("equipment error:", error);
      console.error("equipment error:", errors);
    }
  }

  const CardsSkeleton = () => (
    <>
      {[...Array(5)].map((_, idx) => (
        <div
          key={idx}
          className="p-4 rounded shadow-md text-white animate-pulse"
          style={{ backgroundColor: idx % 2 === 0 ? "#06163A" : "#D62D30" }}
        >
          <div className="flex justify-between items-center">
            <div>
              <div className="h-4 w-24 bg-gray-700 rounded mb-2" />
              <div className="h-6 w-16 bg-gray-600 rounded" />
            </div>
            <div className="w-8 h-8 bg-gray-700 rounded-full" />
          </div>
        </div>
      ))}
    </>
  );

  const dashboardCards = [
    // {
    //   label: "Total Users",
    //   value: totalusers,
    //   icon: <FaUsers size={28} />,
    //   bg: "#06163A",
    //   footerText: "View all users",
    // },
    // {
    //   label: "Active Shipments",
    //   value: "426",
    //   icon: <FaDollarSign size={28} />,
    //   bg: "#D62D30",
    //   footerText: "View revenue details",
    // },
    {
      label: "TOTAL SHIPPERS",
      value: "426",
      icon: <FaUserFriends size={18} />,
      bg: "#06163A",
      footerText: "View all Disputes",
    },
    {
      label: "TOTAL CARRIERS",
      value: 46,
      icon: <FaUserFriends size={18} />,
      bg: "#D62D30",
      footerText: "View all Registered Users",
    },
    {
      label: "TOTAL merchant",
      value: 10,
      icon: <FaUserFriends size={18} />,
      bg: "#06163A",
      footerText: "View all registerd Loads",
    },
  ];

  return (
    <div className="p-4 md:p-6">
      <div className="mb-4 grid justify-between items-center">
        <h2 className="text-xl font-semibold text-[#06163A] dark:text-white">
          User Management
        </h2>
        <p className="text-[#8C8C8C]">
          Manage user accounts, roles, permissions and platform activities.
        </p>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 mb-6">
        {loading ? (
          <CardsSkeleton />
        ) : (
          dashboardCards?.map((item, idx) => (
            <div
              key={idx}
              className=" rounded-xl shadow-md  flex flex-col justify-between mt-5 border-1 border-[#E4E4E7] "
            >
              {/* TOP SECTION */}
              <div className="flex justify-between items-start p-4 w-full">
                {/* LEFT SIDE CONTENT */}
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-[#71717A]">
                    {item.label}
                  </p>

                  <h3 className="text-3xl font-bold mt-2">{item.value}</h3>
                </div>

                {/* RIGHT SIDE ICON */}
                <div className="p-5  bg-[#E4E4E7] rounded-full text-[#475569]">
                  {item.icon}
                </div>
              </div>

              {/* FOOTER (CLICKABLE) */}
              <button
                onClick={() => item.label === "TOTAL SHIPPERS" ? router.push("/admin/shipper"): item.label === "TOTAL CARRIERS" ? router.push("/admin/carrier") : router.push("/admin/merchant")}
                className="bg-[#FFC4C426] mt-4 p-4 flex justify-between items-center w-full text-left text-sm font-medium opacity-90 hover:opacity-100 transition cursor-pointer"
              >
                <span className="text-[#E3000080]">{item.footerText}</span>
                <span className="text-lg">
                  {/* Example arrow icon */}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="#E3000080"
                    className="w-5 h-5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </span>
              </button>
            </div>
          ))
        )}
      </div>

      {/* <div className="flex justify-between items-center mb-4">

        <select
          className="bg-gray-100 dark:bg-[#112244] text-sm p-2 rounded text-[#06163A] dark:text-white"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="All">All Statuses</option>
          <option value="new">new</option>
          <option value="long">long</option>
          <option value="long ago">long ago</option>
          <option value="old">old</option>
        </select>
      </div>

      <p className="text-xs text-gray-500 mb-2 md:hidden">
        📱 Swipe to scroll →
      </p> */}

      {/* <div className="overflow-x-auto w-full bg-white dark:bg-[#06163A] rounded-lg shadow-md">
        <table className="min-w-[1000px] w-full text-sm text-left border-collapse">
          <thead className="bg-[#06163A] text-white sticky top-0 z-10">
            <tr>
              <th className="py-3 px-4">Contract ID</th>
              <th className="py-3 px-4">User</th>
              <th className="py-2 px-3">user type</th>
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="text-gray-700 dark:text-gray-200">
            {currentContracts?.map((contract, index) => (
              <tr
                key={contract.id}
                className={`border-b hover:bg-gray-100 dark:hover:bg-[#1A1E3D] ${
                  index % 2 === 0
                    ? "bg-white dark:bg-[#0B1126]"
                    : "bg-gray-50 dark:bg-[#11193E]"
                }`}
              >
                <td className="py-3 px-4 font-medium">{contract.id}</td>
                <td className="py-3 px-4">
                  <Image
                    src={contract.img}
                    alt="Load"
                    width={40}
                    height={40}
                    className="rounded"
                  />
                </td>
                <td className="py-3 px-4">{contract.email}</td>
                <th
                  className="py-2 px-3 cursor-pointer hover:text-[#D62D30]"
                  onClick={() => setSortAsc(!sortAsc)}
                >
                  {contract.date} {sortAsc ? "↑" : "↓"}
                </th>
                <td className="py-3 px-4">
                  <span
                    className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      contract.status === "Completed"
                        ? "bg-green-100 text-green-800 dark:bg-green-700 dark:text-white"
                        : contract.status === "Pending"
                        ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-700 dark:text-white"
                        : contract.status === "Canceled"
                        ? "bg-red-100 text-red-800 dark:bg-red-700 dark:text-white"
                        : "bg-blue-100 text-blue-800 dark:bg-blue-700 dark:text-white"
                    }`}
                  >
                    {contract.status}
                  </span>
                </td>
                <td className="py-3 px-4 text-center">
                  <div className="flex justify-center gap-3 text-xl">
                    <button
                      onClick={() => handleView(contract)}
                      className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      <MdRemoveRedEye />
                    </button>
                    <button
                      onClick={() => handleDelete(contract)}
                      className="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                    >
                      <FaTrashAlt />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {currentContracts?.length === 0 && (
          <div className="text-center text-sm text-gray-500 dark:text-gray-300 mt-4">
            No Truck found yet.
          </div>
        )}
      </div> */}

      {/* Smart Contracts Table */}
      <div className="bg-white dark:bg-[#06163A] shadow border border-[#CBD5E1] rounded-xl p-5 w-full mt-10">
        {/* TOP BAR — TITLE + SUBTITLE + CONTROLS */}
        <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-5 gap-3">
          {/* LEFT SIDE TITLES */}
          <div>
            <h2 className="text-lg font-semibold text-[#06163A] dark:text-white">
              Recent Activities
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-300 mt-1">
              Latest user actions and updates
            </p>
          </div>

          {/* RIGHT SIDE CONTROLS */}
          <div className="flex items-center gap-3">
            {/* SEARCH INPUT */}
            <div className="relative">
              <FaSearch className="absolute left-2 top-2.5 text-gray-400 text-sm" />
              <input
                type="text"
                placeholder="Search..."
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 pr-3 py-2 text-sm rounded-md border dark:bg-[#112244] text-gray-700 dark:text-white outline-none"
              />
            </div>

            {/* FILTER BUTTON */}
            <button
              onClick={() => setFilterOpen(true)}
              className="p-2 rounded-md bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white hover:bg-gray-200 dark:hover:bg-[#0b1f41] transition"
            >
              <FaFilter />
            </button>

            {/* VIEW ALL BUTTON */}
            {/* <Link
              href="../admin/transaction"
              className="text-sm px-4 py-2 rounded-md bg-[#06163A] text-white dark:bg-white dark:text-[#06163A] hover:opacity-90 transition"
            >
              View All
            </Link> */}
          </div>
        </div>

        {/* TABLE */}
        <div className="overflow-x-auto">
          <table className="min-w-[800px] w-full text-sm text-left border-collapse">
            <thead className="bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white">
              <tr>
                <th
                  className="py-2 px-3 cursor-pointer hover:text-[#D62D30]"
                  // onClick={() => setSortAsc(!sortAsc)}
                >
                  Date {sortAsc ? "↑" : "↓"}
                </th>
                <th className="py-2 px-3">User</th>
                <th className="py-2 px-3">Role</th>
                <th className="py-2 px-3">Activity</th>
                {/* <th className="py-2 px-3">Amount</th> */}
                {/* <th className="py-2 px-3">Status</th> */}

                {/* <th className="py-2 px-3" onClick={() => setFilter("All")}>
                  Location
                </th>
                <th className="py-2 px-3">Price</th>  */}
                <th className="py-2 px-3">Status</th>
              </tr>
            </thead>

            <tbody className="text-gray-700 dark:text-gray-200">
              {currentContracts?.map((contract) => (
                <tr
                  key={contract.id}
                  onClick={() => handleRowClick(contract.id)}
                  className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-[#0b1f41] cursor-pointer"
                >
                  <td className="py-3 px-3">
                    {new Date(contract.date).toDateString()}
                  </td>
                  <td className="py-3 px-3">{`${contract.first_name} ${contract.last_name} `}</td>
                  {/* <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <Image
                        src={contract.img}
                        alt="Load"
                        width={40}
                        height={40}
                        className="rounded"
                      />
                      <span>{contract.first_name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3">{contract.first_name}</td> */}
                  <td className="py-3 px-3">{contract.email}</td>
                  {/* <td className="py-3 px-3">
                    <Image
                      src={contract.img}
                      alt="Truck"
                      width={40}
                      height={40}
                      className="rounded"
                    />
                  </td> */}
                  <td className="py-3 px-3 flex items-center gap-1">
                    <FaMapMarkerAlt className="text-[#D62D30]" />
                    <span>{contract.first_name}</span>
                  </td>
                  {/* <td className="py-3 px-3">{contract.Business_cert}</td> */}
                  <td className="py-3 px-3">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        contract.status === "Pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : contract.status === "Completed"
                          ? "bg-green-100 text-green-800"
                          : "bg-blue-100 text-blue-800"
                      }`}
                    >
                      {contract.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredUsers.length === 0 && (
            <div className="text-center text-sm text-gray-500 mt-4">
              No contracts found yet.
            </div>
          )}
        </div>
      </div>

      {/* Pagination Controls */}
      <div className="flex justify-center mt-4 gap-2">
        {Array.from(
          { length: Math.ceil(users?.length / usersPerPage) },
          (_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPage(i + 1)}
              className={`px-3 py-1 rounded ${
                currentPage === i + 1
                  ? "bg-[#D62D30] text-white"
                  : "bg-gray-200 dark:bg-gray-600 dark:text-white"
              }`}
            >
              {i + 1}
            </button>
          )
        )}
      </div>

      {/* View Modal */}
      <Dialog
        open={viewModalOpen}
        onClose={() => setViewModalOpen(false)}
        onClick={() => setViewModalOpen(false)}
        className="fixed z-50 inset-0 flex items-center justify-center"
      >
        <div className="bg-black bg-opacity-50 fixed inset-0" />
        <div className="bg-white dark:bg-[#06163A] p-6 rounded-lg z-10 max-w-sm mx-auto">
          <Dialog.Title className="text-lg font-bold text-[#06163A] dark:text-white">
            User Details
          </Dialog.Title>
          {/* {selectedUser && (
            <div className="mt-4 space-y-2 text-sm dark:text-gray-200">
              <p>
                <strong>ID:</strong> {selectedUser.id}
              </p>
              <p>
                <strong>Shipper:</strong> {selectedUser.email}
              </p>
              <p>
                <strong>Carrier:</strong> {selectedUser.date}
              </p>
              <p>
                <strong>Date:</strong> {selectedUser.date}
              </p>
              <p>
                <strong>Location:</strong> {selectedUser.name}
              </p>
              <p>
                <strong>Price:</strong> {selectedUser.name}
              </p>
              <p>
                <strong>Status:</strong> {selectedUser.status}
              </p>
            </div>
          )} */}
          <div className="mt-4 text-right">
            <button
              onClick={() => setViewModalOpen(false)}
              className="text-sm px-4 py-2 bg-gray-300 dark:bg-gray-600 rounded"
            >
              Close
            </button>
          </div>
        </div>
      </Dialog>

      {/* Delete Modal */}
      <Dialog
        open={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onClick={() => setViewModalOpen(false)}
        className="fixed z-50 inset-0 flex items-center justify-center"
      >
        <div className="bg-black bg-opacity-50 fixed inset-0" />
        <div className="bg-white dark:bg-[#06163A] p-6 rounded-lg z-10 max-w-sm mx-auto">
          <Dialog.Title className="text-lg font-bold text-red-600 dark:text-red-400">
            Delete Confirmation
          </Dialog.Title>
          <p className="mt-4 text-sm text-gray-700 dark:text-gray-300">
            Are you sure you want to delete contract{" "}
            {/* <strong>{selectedUser?.id}</strong>? */}
          </p>
          <div className="mt-6 flex justify-end gap-2">
            <button
              onClick={() => setDeleteModalOpen(false)}
              className="px-4 py-2 text-sm bg-gray-300 dark:bg-gray-600 rounded"
            >
              Cancel
            </button>
            <button
              // onClick={confirmDelete}
              className="px-4 py-2 text-sm bg-red-600 text-white rounded"
            >
              Delete
            </button>
          </div>
        </div>
      </Dialog>
    </div>
  );
}
