"use client";

import { useEffect, useState } from "react";
// import Image from "next/image";import jsPDF from "jspdf";

import jsPDF from "jspdf";
import html2canvas from "html2canvas";
// import { MdRemoveRedEye } from "react-icons/md";
import { FaDollarSign, FaUserFriends } from "react-icons/fa";
import user from "@/app/datatype/user";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { apiCall, BASE_URL } from "@/app/core/api";
import responce from "@/app/datatype/response";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import RecentActivity from "@/components/recentactivity";


// import { dataStat } from "@/app/core/util";
// import Image from "next/image";
// import Link from "next/link";
// type responce = {
//   error?: string;
//   user?: user[];
// };

// const x: user = {
//   id: 0,
//   name: "",
//   email: "",
//   first_name: "",
//   last_name: "",
//   business_type_id: 1,
//   user_type: "",
//   password_hash: "",
//   phone_number: "",
//   roles: "",
//   photo: "",
//   address_one: "",
//   address_two: "",
//   Means_ID: "",
//   category_business: "",
//   Business_cert: "",
//   list_share_holder: "",
//   licenses: "",
//   img: "",
//   status: "",
//   date: "",
//   type: "",
//   deleted: 0,
//   updated_at: "",
//   isVerified: false,
//   isEmailVerified: false,
// };

const data = [
  { name: "Jan", shippers: 40, carrier: 28 },
  { name: "Feb", shippers: 30, carrier: 35 },
  { name: "Mar", shippers: 45, carrier: 50 },
  { name: "Apr", shippers: 25, carrier: 20 },
  { name: "May", shippers: 60, carrier: 48 },
];

// --- SAMPLE YEAR DATA (REPLACE WITH YOURS) ---
const initialData = [
  { month: "Jan", payout: 1200, holdings: 800 },
  { month: "Feb", payout: 1400, holdings: 950 },
  { month: "Mar", payout: 900, holdings: 700 },
  { month: "Apr", payout: 1800, holdings: 1100 },
  { month: "May", payout: 1600, holdings: 950 },
  { month: "Jun", payout: 2000, holdings: 1600 },
  { month: "Jul", payout: 1700, holdings: 1200 },
  { month: "Aug", payout: 2200, holdings: 1600 },
  { month: "Sep", payout: 1400, holdings: 1300 },
  { month: "Oct", payout: 2600, holdings: 1900 },
  { month: "Nov", payout: 2300, holdings: 1750 },
  { month: "Dec", payout: 2800, holdings: 2000 },
];


const activities = [
   { id: 1, action: 'Payment received', company: 'Acme Corp', type: 'merchant', timestamp: '2025-12-06T09:12:00Z', details: '₦ 1,200,000' },
   { id: 2, action: 'Shipment picked', company: 'FastShip', type: 'shipper', timestamp: '2025-12-06T07:50:00Z' },
   { id: 3, action: 'Carrier assigned', company: 'TransLoad', type: 'carrier', timestamp: '2025-12-05T22:00:00Z' },
      { id: 1, action: 'Payment received', company: 'Acme Corp', type: 'merchant', timestamp: '2025-12-06T09:12:00Z', details: '₦ 1,200,000' },
   { id: 2, action: 'Shipment picked', company: 'FastShip', type: 'shipper', timestamp: '2025-12-06T07:50:00Z' },
   { id: 3, action: 'Carrier assigned', company: 'TransLoad', type: 'carrier', timestamp: '2025-12-05T22:00:00Z' },
];

export default function UsersPage() {
  // const [filter] = useState("All");
  // const [sortAsc] = useState(true);
  const [users, setUser] = useState<user[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  // const [selectedUser, setSelectedUser] = useState<user>(x);
  // const [viewModalOpen, setViewModalOpen] = useState(false);
  // const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  // const [search, setSearch] = useState("");
  // // const [filterOpen, setFilterOpen] = useState(false);
  // const [statloaddata] = useState<dataStat[]>();
  // const [rangeType, setRangeType] = useState("month");
  // const [search, setSearch] = useState("");
  // const [filterOpen, setFilterOpen] = useState(false);
  const [year, setYear] = useState("2024");
  const ckdata = [
    { name: "Successful (30)", value: 40 },
    { name: "Pending (15)", value: 25 },
    { name: "Refunded (5)", value: 15 },
  ];
  // const handleRowClick = (userId: number) => {
  //   console.log("Row clicked for user ID:", userId);
  //   // Implement further actions, e.g., open a detail view
  // };

  console.log(users);

  // const filteredUsers = users
  //   ?.filter((user) => filter === "All" || user.status === filter)
  //   .sort((a, b) => {
  //     const dateA = new Date(a.date).getTime();
  //     const dateB = new Date(b.date).getTime();
  //     return sortAsc ? dateA - dateB : dateB - dateA;
  //   });

  // const [currentPage] = useState(1);
  // const usersPerPage = 10;
  // const indexOfLast = currentPage * usersPerPage;
  // const indexOfFirst = indexOfLast - usersPerPage;
  // const currentContracts = filteredUsers?.slice(indexOfFirst, indexOfLast);

  // const handleView = (user: user) => {
  //   setSelectedUser(user);
  //   setViewModalOpen(true);
  // };

  // const handleDelete = (user: user) => {
  //   setSelectedUser(user);
  //   setDeleteModalOpen(true);
  // };

  // const confirmDelete = () => {
  //   alert(`Contract ${selectedUser?.id} deleted (simulate)`);
  //   setDeleteModalOpen(false);
  // };

  const [filter, setFilter] = useState("12m");

  const getFilteredData = () => {
    switch (filter) {
      case "6m":
        return initialData.slice(-6);
      case "3m":
        return initialData.slice(-3);
      case "30d":
        return initialData.slice(-1); // last month as 30 days
      case "7d":
        return initialData.slice(-1); // last 7 days (can replace with your logic)
      default:
        return initialData;
    }
  };

  // EXPORT GRAPH AS PDF
  const exportPDF = async () => {
    const chart = document.getElementById("chartCapture");
    const canvas = await html2canvas(chart || document.body);
    const img = canvas.toDataURL("image/png");

    const pdf = new jsPDF("landscape");
    pdf.addImage(img, "PNG", 10, 10, 270, 160);
    pdf.save("transaction-report.pdf");
  };

  useEffect(() => {
    handleGetUser();
    setLoading(false);
    // console.log(search, filteredUsers, filterOpen);
  }, []);

  async function handleGetUser() {
    try {
      // get logged in admin token
      const token = getCookie("not_usertoken");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/users`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }

      const data = await response.json();
      console.log(data);

      const dataTypeed = data as responce;

      if (dataTypeed.error) {
        const errList: string[] = [dataTypeed?.error];
        setErrors(errList);
      } else {
        console.log(dataTypeed.notuser);
        setUser(dataTypeed.user);
      }
    } catch (error) {
      console.error("equipment error:", error);
      console.error("equipment error:", errors);
    }
  }

  const CardsSkeleton = () => (
    <>
      {[...Array(5)].map((_, idx) => (
        <div
          key={idx}
          className="p-4 rounded shadow-md text-white animate-pulse"
          style={{ backgroundColor: idx % 2 === 0 ? "#06163A" : "#D62D30" }}
        >
          <div className="flex justify-between items-center">
            <div>
              <div className="h-4 w-24 bg-gray-700 rounded mb-2" />
              <div className="h-6 w-16 bg-gray-600 rounded" />
            </div>
            <div className="w-8 h-8 bg-gray-700 rounded-full" />
          </div>
        </div>
      ))}
    </>
  );

  const dashboardCards = [
    // {
    //   label: "Total Users",
    //   value: totalusers,
    //   icon: <FaUsers size={28} />,
    //   bg: "#06163A",
    //   footerText: "View all users",
    // },
    {
      label: "Active shipper OFFERS",
      value: "426",
      icon: <FaDollarSign size={28} />,
      bg: "#D62D30",
      footerText: "View all Escrow Balance",
    },
    {
      label: "Active Carrier OFFERS",
      value: "426",
      icon: <FaUserFriends size={18} />,
      bg: "#06163A",
      footerText: "View all Escrow Balance",
    },
    {
      label: "MATCHED LOADS",
      value: 46,
      icon: <FaUserFriends size={18} />,
      bg: "#D62D30",
      footerText: "View all Escrow Balance",
    },
    {
      label: "PENDING BIDS",
      value: 10,
      icon: <FaUserFriends size={18} />,
      bg: "#06163A",
      footerText: "View all Escrow Balance",
    },
  ];

  return (
    <div className="p-4 md:p-6">
      <div className="mb-4 grid justify-between items-center">
        <h2 className="text-xl font-semibold text-[#06163A] dark:text-white">
          Load Board
        </h2>
        <p className="text-[#8C8C8C]">
          Monitor all active shipments, offers, and matches across the logistics
          network
        </p>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {loading ? (
          <CardsSkeleton />
        ) : (
          dashboardCards?.map((item, idx) => (
            <div
              key={idx}
              className=" rounded-xl shadow-md  flex flex-col justify-between mt-5 border-1 border-[#E4E4E7] "
            >
              {/* TOP SECTION */}
              <div className="flex justify-between items-start p-4 w-full">
                {/* LEFT SIDE CONTENT */}
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-[#71717A]">
                    {item.label}
                  </p>

                  <h3 className="text-3xl font-bold mt-2">{item.value}</h3>
                </div>

                {/* RIGHT SIDE ICON */}
                {/* <div className="p-5  bg-[#E4E4E7] rounded-full text-[#475569]">
                  {/* {item.icon} 
                </div> */}
              </div>

              {/* FOOTER (CLICKABLE) */}
              <button
                onClick={() => console.log("Clicked")}
                className="bg-[#FFC4C426] mt-4 p-4 flex justify-between items-center w-full text-left text-sm font-medium opacity-90 hover:opacity-100 transition cursor-pointer"
              >
                <span className="text-[#E3000080]">{item.footerText}</span>
                <span className="text-lg">
                  {/* Example arrow icon */}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="#E3000080"
                    className="w-5 h-5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </span>
              </button>
            </div>
          ))
        )}
      </div>

      {/* Graphs Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
        {["Shipment Status"].map((title, i) => (
          <div
            key={i}
            className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md"
          >
            {/* HEADER BAR */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-3">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                {title}
              </h2>

              {/* YEAR FILTER */}
              <div className="flex items-center gap-2">
                <select
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                  className="bg-gray-100 dark:bg-gray-700 text-sm p-1 rounded text-gray-900 dark:text-white"
                >
                  <option value="2025">2025</option>
                  <option value="2024">2024</option>
                </select>
              </div>
            </div>

            {/* PIE + LEGEND AREA */}
            <div className="flex justify-between items-center">
              {/* DONUT CHART */}
              <ResponsiveContainer width="60%" height={240}>
                <PieChart>
                  <Pie
                    data={ckdata}
                    dataKey="value"
                    cx="50%"
                    cy="50%"
                    outerRadius={85}
                    innerRadius={50} // <<< THIS MAKES IT A DONUT 🎉
                    stroke="none"
                    label
                  >
                    {["#1685AA", "#FE5000", "#0FA958"].map((color, idx) => (
                      <Cell key={idx} fill={color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>

              {/* LEGEND */}
              <div className="flex flex-col gap-3 text-sm text-gray-700 dark:text-gray-200 pr-3">
                {ckdata.map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{
                        background: ["#1685AA", "#FE5000", "#0FA958"][i],
                      }}
                    ></span>
                    <span>{item.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}

        <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Active Offers Breakdown
          </h2>

          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <XAxis dataKey="name" stroke="#ccc" />
              <YAxis stroke="#ccc" />
              <Tooltip />
              <Legend />

              {/* TWO COLORS FOR BAR */}
              <Bar dataKey="shippers" fill="#3B82F6" radius={[6, 6, 0, 0]} />
              <Bar dataKey="carrier" fill="#DD4F4F" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[70%_30%] gap-4">
        <div className="bg-white dark:bg-gray-900 shadow-md p-6 rounded-xl">
          {/* HEADER WITH EXPORT PDF */}
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-lg font-bold dark:text-white">
              Escrow Payment Flow
            </h2>

            <button
              onClick={exportPDF}
              className="bg-red-600 text-white px-3 py-2 rounded-md font-medium hover:bg-red-700"
            >
              Export PDF
            </button>
          </div>

          {/* FILTER TABS */}
          <div className="flex gap-3 mb-4">
            {[
              { label: "7 Days", value: "7d" },
              { label: "30 Days", value: "30d" },
              { label: "3 Months", value: "3m" },
              { label: "6 Months", value: "6m" },
              { label: "12 Months", value: "12m" },
            ].map((tab) => (
              <button
                key={tab.value}
                onClick={() => setFilter(tab.value)}
                className={`px-3 py-1 rounded-md font-medium
              ${
                filter === tab.value
                  ? "bg-red-600 text-white"
                  : "bg-gray-200 dark:bg-gray-700 dark:text-white"
              }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* CHART AREA */}
          <div id="chartCapture">
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={getFilteredData()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />

                {/* 2 LINES - DIFFERENT COLORS */}
                <Line
                  type="monotone"
                  dataKey="payout"
                  stroke="#D62D2D"
                  strokeWidth={3}
                />
                <Line
                  type="monotone"
                  dataKey="holdings"
                  stroke="#1685AA"
                  strokeWidth={3}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

 <RecentActivity activities={activities} onViewMore={() => console.log('view more')} />

      </div>

      {/* Donut Charts */}
      {/* <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-6 w-full mt-10">
          <h1 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
            Smart contract progress track
          </h1>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
            {donutdata?.map((item, index) => {
              const donutValue = [
                { name: item.label, value: item.value },
                { name: "Remaining", value: item.total - item.value },
              ];
  
              return (
                <div
                  key={index}
                  className="border dark:border-gray-700 rounded-lg p-4 text-center"
                >
                  <div className="flex justify-center h-[130px]">
                    <ResponsiveContainer width={130} height={130}>
                      <PieChart>
                        <Pie
                          data={donutValue}
                          innerRadius={40}
                          outerRadius={60}
                          paddingAngle={2}
                          dataKey="value"
                          startAngle={90}
                          endAngle={450}
                        >
                          <Cell fill={item.color} />
                          <Cell fill="#06163a26" />
                        </Pie>
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <h6 className="mt-3 text-sm font-semibold text-gray-800 dark:text-white">
                    {item.label} : {item.count}
                  </h6>
                </div>
              );
            })}
          </div>
        </div> */}
    </div>
  );
}
