"use client";

import { useEffect, useState } from "react";
// import Image from "next/image";

// import { MdRemoveRedEye } from "react-icons/md";
import user from "@/app/datatype/user";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { apiCall, BASE_URL } from "@/app/core/api";
import responce from "@/app/datatype/response";
import {  FaBoxOpen, FaCalendar, FaPlaceOfWorship, FaSearch, FaUserFriends } from "react-icons/fa";
import { useRouter } from "next/navigation";

// import Image from "next/image";

const tabs = [
  { name: "All", count: 23, color: "#757575" },
  { name: "New", count: 7, color: "#8A38F5" },
  { name: "Under Review", count: 7, color: "#FFA500" },
  { name: "Resolved", count: 7, color: "#14BA6D" },
];

export default function DisputePage() {
  const [filter] = useState("All");
  const [sortAsc] = useState(true);
  const [users, setUser] = useState<user[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  // const [selectedUser, setSelectedUser] = useState<user>(x);
  // const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  // const [filterOpen, setFilterOpen] = useState(false);
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("All");
  const [disputes] = useState([
    {
      id: 1,
      Shipment_ID: {
        id: "SHP-12345",
        icons: <FaBoxOpen size={16} color="#E30000" />,
      },
      Dispute_Date: {
        date: "2023-09-01",
        icons: <FaCalendar size={16} color="#E30000" />,
      },
      Shipper: {
        name: "John Doe",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      Carrier: {
        name: "Acme Logistics",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      status: { name: "new", bgcolor: "#8A38F50A", color: "#8A38F5" },
      Complaint:{
        complaint:"The shipment has been delayed beyond the expected delivery date.",
         icons: <FaPlaceOfWorship size={16} color="#E30000" className="pr-2"/>,
      },
    },
    {
      id: 2,
      Shipment_ID: {
        id: "SHP-12346",
        icons: <FaBoxOpen size={16} color="#E30000" />,
      },
      Dispute_Date: {
        date: "2023-09-05",
        icons: <FaCalendar size={16} color="#E30000" />,
      },
      Shipper: {
        name: "Jane Smith",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      Carrier: {
        name: "Global Transport",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      status: { name: "Under Review", bgcolor: "#FFFBEB", color: "#F59E0B" },
      Complaint: {
        complaint:"The shipment has been delayed beyond the expected delivery date.",
         icons: <FaPlaceOfWorship size={16} color="#E30000" className="pr-2" />,
      },
    },
    {
      id: 3,
      Shipment_ID: {
        id: "SHP-12347",
        icons: <FaBoxOpen size={16} color="#E30000" />,
      },
      Dispute_Date: {
        date: "2023-09-10",
        icons: <FaCalendar size={16} color="#E30000" />,
      },
      Shipper: {
        name: "Mike Johnson",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      Carrier: {
        name: "Speedy Couriers",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      status: { name: "Resolved", bgcolor: "#14BA6D40", color: "#22C55E" },
      Complaint: {
        complaint:"The shipment has been delayed beyond the expected delivery date.",
         icons: <FaPlaceOfWorship size={16} color="#E30000" className="pr-2" />,
      },
    },{
      id: 4,
      Shipment_ID: {
        id: "SHP-12347",
        icons: <FaBoxOpen size={16} color="#E30000" />,
      },
      Dispute_Date: {
        date: "2023-09-10",
        icons: <FaCalendar size={16} color="#E30000" />,
      },
      Shipper: {
        name: "Mike Johnson",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      Carrier: {
        name: "Speedy Couriers",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      status: { name: "Resolved", bgcolor: "#14BA6D40", color: "#22C55E" },
      Complaint: {
        complaint:"The shipment has been delayed beyond the expected delivery date.",
         icons: <FaPlaceOfWorship size={16} color="#E30000" className="pr-2" />,
      },
    },
    {
      id: 5,
      Shipment_ID: {
        id: "SHP-12347",
        icons: <FaBoxOpen size={16} color="#E30000" />,
      },
      Dispute_Date: {
        date: "2023-09-10",
        icons: <FaCalendar size={16} color="#E30000" />,
      },
      Shipper: {
        name: "Mike Johnson",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      Carrier: {
        name: "Speedy Couriers",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      status: { name: "Resolved", bgcolor: "#14BA6D40", color: "#22C55E" },
      Complaint: {
        complaint:"The shipment has been delayed beyond the expected delivery date.",
         icons: <FaPlaceOfWorship size={16} color="#E30000" className="pr-2" />,
      },
    },
    {
      id: 6,
      Shipment_ID: {
        id: "SHP-12347",
        icons: <FaBoxOpen size={16} color="#E30000" />,
      },
      Dispute_Date: {
        date: "2023-09-10",
        icons: <FaCalendar size={16} color="#E30000" />,
      },
      Shipper: {
        name: "Mike Johnson",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      Carrier: {
        name: "Speedy Couriers",
        icons: <FaUserFriends size={16} color="#E30000" />,
      },
      status: { name: "Resolved", bgcolor: "#14BA6D40", color: "#22C55E" },
      Complaint: {
        complaint:"The shipment has been delayed beyond the expected delivery date.",
         icons: <FaPlaceOfWorship size={16} color="#E30000" className="pr-2" />,
      },
    },
  ]);

  console.log(users);
  console.log(search);

  const filteredUsers = users
    ?.filter((user) => filter === "All" || user.status === filter)
    .sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

  useEffect(() => {
    handleGetUser();
    // setLoading(false);
    console.log(filteredUsers);
  }, []);

  async function handleGetUser() {
    try {
      // get logged in admin token
      const token = getCookie("not_usertoken");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/users`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }

      const data = await response.json();
      console.log(data);

      const dataTypeed = data as responce;

      if (dataTypeed.error) {
        const errList: string[] = [dataTypeed?.error];
        setErrors(errList);
      } else {
        console.log(dataTypeed.notuser);
        setUser(dataTypeed.user);
      }
    } catch (error) {
      console.error("equipment error:", error);
      console.error("equipment error:", errors);
    }
  }

  // const CardsSkeleton = () => (
  //   <>
  //     {[...Array(5)].map((_, idx) => (
  //       <div
  //         key={idx}
  //         className="p-4 rounded shadow-md text-white animate-pulse"
  //         style={{ backgroundColor: idx % 2 === 0 ? "#06163A" : "#D62D30" }}
  //       >
  //         <div className="flex justify-between items-center">
  //           <div>
  //             <div className="h-4 w-24 bg-gray-700 rounded mb-2" />
  //             <div className="h-6 w-16 bg-gray-600 rounded" />
  //           </div>
  //           <div className="w-8 h-8 bg-gray-700 rounded-full" />
  //         </div>
  //       </div>
  //     ))}
  //   </>
  // );

  // const dashboardCards = [
  //   // {
  //   //   label: "Total Users",
  //   //   value: totalusers,
  //   //   icon: <FaUsers size={28} />,
  //   //   bg: "#06163A",
  //   //   footerText: "View all users",
  //   // },
  //   {
  //     label: "ACTIVE SHIPPERS",
  //     value: "426",
  //     icon: <FaUserFriends size={18} color="#22C55E" />,
  //     bg: "#22C55E33",
  //     footerText: "View revenue details",
  //   },
  //   {
  //     label: "Total shipments",
  //     value: "426",
  //     icon: <FaBoxOpen size={18} color="#FE5000" />,
  //     bg: "#FE500033",
  //     footerText: "View all Disputes",
  //   },
  //   {
  //     label: "Pending KYC",
  //     value: 46,
  //     icon: <FaGgCircle size={18} color="#FACC15" />,
  //     bg: "#FACC1533",
  //     footerText: "View all Registered Users",
  //   },
  //   {
  //     label: "suspended SHIPPERS",
  //     value: 10,
  //     icon: <FaUserAltSlash size={18} color="#E30000" />,
  //     bg: "#FF454533",
  //     footerText: "View all registerd Loads",
  //   },
  // ];

  return (
    <div className="p-4 md:p-6">
      <div className="mb-4  justify-items-start items-center">
        <h2 className="text-xl font-semibold text-[#06163A] dark:text-white">
          Disoute Center
        </h2>
        <p className="text-sm text-[#8C8C8C] m-3">
          Review and resolve disputes, issues, and activity reports.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-5 gap-2">
        {/* LEFT SIDE TITLES */}
        <div>
          <div className="m-3  text-sm text-gray-500 dark:text-gray-300">
            {/* SEARCH INPUT */}
            <div className="relative">
              <FaSearch className="absolute left-2 top-2.5 text-gray-400 text-sm" />
              <input
                type="text"
                placeholder="Search..."
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 pr-3 py-2 text-sm rounded-md border dark:bg-[#112244] text-gray-700 dark:text-white outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-3 mt-10 border-b border-gray-200 dark:border-gray-700 pb-2">
        {tabs.map((tab) => (
          <button
            key={tab.name}
            onClick={() => setActiveTab(tab.name)}
            className={`
              px-4 py-2  text-sm font-medium transition
              ${
                activeTab === tab.name
                  ? "border-b-[#0000001A] text-black dark:text-white font-bold border-b-2"
                  : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#0B1F41]"
              }
            `}
          >
            {tab.name}{" "}
            <span
              style={{
                background: tab.color,
                padding: "2px 4px",
                borderRadius: "4px",
                color: "#fff",
              }}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* dispute cards here */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4  pt-4">
        {disputes.map((dispute) => (
          <div
            key={dispute.id}
            onClick={() => router.push("/admin/opendispute/")}
            className=" bg-[#fff] dark:bg-[#06163A] border border-[#CBD5E1] rounded-xl shadow cursor-pointer"
          >
            {/* header   */}
            <div className="flex items-center justify-between mb-4 border-b-2  p-4">
              <div className="flex items-center gap-2 text-[#8C8C8C]">
                Status
              </div>
              <div className="flex items-center gap-2 ">
                <span
                  style={{
                    background: dispute.status.bgcolor,
                    fontSize: "12px ",
                    padding: "2px 6px",
                    borderRadius: "10px",
                    color: dispute.status.color,
                    border: "2px",
                    borderColor: dispute.status.color,
                  }}
                >
                  .{dispute.status.name}
                </span>
              </div>
            </div>
            {/* body */}
            <div className="flex items-center justify-between mb-2  px-4">
              <div className="flex items-center gap-2 text-[#8C8C8C]">
                {dispute.Shipment_ID.icons}
                Shipment ID
              </div>
              <div className="flex items-center gap-2 text-[#404040] ">
                {dispute.Shipment_ID.id}
              </div>
            </div>

            <div className="flex items-center justify-between mb-2  px-4">
              <div className="flex items-center gap-2 text-[#8C8C8C]">
                {dispute.Dispute_Date.icons}
                Dispute Date
              </div>
              <div className="flex items-center gap-2 text-[#404040] ">
                {dispute.Dispute_Date.date}
              </div>
            </div>

            <div className="flex items-center justify-between mb-2  px-4">
              <div className="flex items-center gap-2 text-[#8C8C8C]">
                {dispute.Shipper.icons}
                Shipper
              </div>
              <div className="flex items-center gap-2 text-[#404040] ">
                {dispute.Shipper.name}
              </div>
            </div>

            <div className="flex items-center justify-between mb-2  px-4">
              <div className="flex items-center gap-2 text-[#8C8C8C]">
                {dispute.Carrier.icons}
                Carrier
              </div>
              <div className="flex items-center gap-2 text-[#404040] ">
                {dispute.Carrier.name}
              </div>
            </div>

            <div className="grid p-4 mt-2">
              <h3 className="flex  text-[#8C8C8C] dark:text-white ">
                {dispute.Complaint.icons}
                Complaint
              </h3>
              <p className="text-xs font-semibold text-[#404040] mt-2 wrap-normal ">
                {dispute.Complaint.complaint}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
