"use client";
import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Eye, EyeOff } from "lucide-react";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState(1);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [code, setCode] = useState(["", "", "", ""]);
  const router = useRouter();

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setMessage("");
    if (!email.trim()) {
      setError("Please enter your email address.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setMessage("Reset link sent successfully!");
      setStep(2);
    }, 1000);
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!newPassword || !confirmPassword) {
      setError("Please fill in both password fields.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep(3);
    }, 1000);
  };

  const handleCodeChange = (index: number, value: string) => {
    if (value.length > 1) return;
    const newCode = [...code];
    newCode[index] = value.replace(/\D/, ""); // only digits
    setCode(newCode);
  };

  const handleCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.join("").length < 4) {
      setError("Please enter all four digits.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      router.push("/admin"); // redirect to login
    }, 1000);
  };

  //   const handleSubmit = (e: React.FormEvent) => {
  //     e.preventDefault();
  //     setLoading(true);
  //     setError("");
  //     setMessage("");

  //     // Simulate API call
  //     setTimeout(() => {
  //       if (email === "") {
  //         setError("Please enter a valid email address.");
  //       } else {
  //         setMessage("Password reset link sent successfully!");
  //       }
  //       setLoading(false);
  //     }, 1200);
  //   };

  return (
    <div className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-900 px-4 sm:px-6">
      <form
        onSubmit={
          step === 1
            ? handleEmailSubmit
            : step === 2
            ? handlePasswordSubmit
            : handleCodeSubmit
        }
        className="bg-white dark:bg-gray-900 p-6 sm:p-10 w-full max-w-xl text-center transition-all duration-300"
      >
        {/* Step-based Icon */}
        <div className="flex justify-center mb-6">
          <Image
            src={
              step === 1
                ? "/assets/img/reset-password.png"
                : step === 2
                ? "/assets/img/reset-password.png"
                : "/assets/img/mfa.png"
            }
            alt="Ashglobe Icon"
            width={80}
            height={80}
            className="rounded-full"
          />
        </div>

        {/* Headings */}
        {step === 1 && (
          <>
            <h1 className="text-3xl sm:text-4xl font-bold text-[#06163A] dark:text-[#D62D30] mb-3">
              Forgot Password?
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mb-8 text-base sm:text-lg">
              Enter your registered email address below to receive a reset link.
            </p>
            <div className="mb-6 text-left">
              <label className="block mb-1 font-semibold text-sm sm:text-base">
                Email Address
              </label>
              <input
                type="email"
                className="w-full p-3 border-2 border-[#D0D5DD] rounded focus:outline-none focus:ring-2 focus:ring-[#D62D30]"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@example.com"
                required
              />
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <h1 className="text-3xl sm:text-4xl font-bold text-[#06163A] dark:text-[#D62D30] mb-3">
              Change Your Password
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mb-8 text-base sm:text-lg">
              Enter new login passwords.
            </p>

            {/* New Password */}
            <div className="mb-4 relative text-left">
              <label className="block mb-1 font-semibold">New Password</label>
              <input
                type={showPassword ? "text" : "password"}
                className="w-full p-3 border-2 border-[#D0D5DD] rounded focus:outline-none focus:ring-2 focus:ring-[#D62D30]"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-10 text-gray-500 hover:text-[#D62D30]"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>

            {/* Confirm Password */}
            <div className="mb-6 relative text-left">
              <label className="block mb-1 font-semibold">
                Confirm Password
              </label>
              <input
                type={showConfirm ? "text" : "password"}
                className="w-full p-3 border-2 border-[#D0D5DD] rounded focus:outline-none focus:ring-2 focus:ring-[#D62D30]"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
              <button
                type="button"
                onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-3 top-10 text-gray-500 hover:text-[#D62D30]"
              >
                {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <h1 className="text-3xl sm:text-4xl font-bold text-[#06163A] dark:text-[#D62D30] mb-3">
              Multi Factor Authentication
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mb-8 text-base sm:text-lg">
              Enter  verification code sent to your email.
            </p>

            <div className="flex justify-center gap-3 mb-8">
              {code.map((digit, i) => (
                <input
                  key={i}
                  type="text"
                  inputMode="numeric"
                  value={digit}
                  onChange={(e) => handleCodeChange(i, e.target.value)}
                  className="w-12 h-12 text-center border-2 border-[#D0D5DD] rounded focus:outline-none focus:ring-2 focus:ring-[#D62D30] text-lg font-bold"
                />
              ))}
            </div>
          </>
        )}

        {/* Messages */}
        {error && <div className="text-red-600 mb-4 text-sm">{error}</div>}
        {message && (
          <div className="text-green-600 mb-4 text-sm">{message}</div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full py-2 rounded bg-[#01245A] text-white font-bold hover:bg-[#D62D30] transition"
          disabled={loading}
        >
          {loading
            ? "Processing..."
            : step === 1
            ? "Reset Password"
            : step === 2
            ? "Change Password"
            : "Contniue"}
        </button>

        {/* Back to Login */}
        {step === 1 && (
          <div className="mt-6 text-sm">
            <a
              href="/admin"
              className="text-[#320DFF] font-semibold hover:underline"
            >
              Back to Login
            </a>
          </div>
        )}
      </form>
    </div>
  );
}
