"use client"

import { Bar, Line, ResponsiveContainer, Tooltip, XAxis, YAxis,BarChart, PieChart, Pie, Cell,LineChart, CartesianGrid} from "recharts";

import { FaChartLine, FaUserPlus, FaTruck, FaDollarSign, FaEllipsisH } from "react-icons/fa";
import { useState } from "react";
import {weeklyData,monthLoadData, lineData, pieData, COLORS} from '@/app/datatype/data'


export default function AnalyticsPage() {

      const [year, setYear] = useState('2025');
      const [month, setMonth] = useState('All');


    return (

      // p-6 bg-white dark:bg-gray-900 min-h-screen
      

        <div className="p-6 bg-white dark:bg-gray-900 min-h-screen">
          <h1 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
            Analytics Overview
          </h1>
          <p className="text-gray-600 dark:text-gray-300 pb-5">Insights and statistics.</p>

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
            <div className="bg-[#06163A] text-white p-4 rounded shadow-md">
              <div className="flex items-center">
                <FaChartLine className="mr-2" size={24} />
                <div>
                  <p className="text-sm">Monthly Visits</p>
                  <h3 className="text-xl font-semibold">15,300</h3>
                </div>
              </div>
            </div>

            <div className="bg-[#D62D30] text-white p-4 rounded shadow-md">
              <div className="flex items-center">
                <FaUserPlus className="mr-2" size={24} />
                <div>
                  <p className="text-sm">New Users</p>
                  <h3 className="text-xl font-semibold">1,200</h3>
                </div>
              </div>
            </div>

            <div className="bg-[#06163A] text-white p-4 rounded shadow-md">
              <div className="flex items-center">
                <FaTruck className="mr-2" size={24} />
                <div>
                  <p className="text-sm">Deliveries</p>
                  <h3 className="text-xl font-semibold">980</h3>
                </div>
              </div>
            </div>

            <div className="bg-[#D62D30] text-white p-4 rounded shadow-md">
              <div className="flex items-center">
                <FaDollarSign className="mr-2" size={24} />
                <div>
                  <p className="text-sm">Revenue</p>
                  <h3 className="text-xl font-semibold">$45,000</h3>
                </div>
              </div>
            </div>
          </div>

          {/* Graph Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white dark:bg-gray-800 p-4 rounded shadow-md">
              <h2 className="text-lg font-semibold mb-3 text-gray-700 dark:text-white">
                Monthly Load Review
              </h2>
              
              <div className="col-span-1 bg-white dark:bg-gray-800 p-4 rounded-lg shadow animate-pulse">
                    <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
                      <h6 className="text-lg font-semibold text-gray-900 dark:text-white"></h6>
                      <div className="flex gap-2">
                        <select
                          value={year}
                          onChange={(e) => setYear(e.target.value)}
                          className="bg-gray-100 dark:bg-gray-700 text-sm text-gray-900 dark:text-white p-1 rounded"
                        >
                          <option value="2025">2025</option>
                          <option value="2024">2024</option>
                        </select>
                        <select
                          value={month}
                          onChange={(e) => setMonth(e.target.value)}
                          className="bg-gray-100 dark:bg-gray-700 text-sm text-gray-900 dark:text-white p-1 rounded"
                        >
                          <option value="All">All</option>
                          <option value="Jan">January</option>
                          <option value="Feb">February</option>
                          {/* Add rest of months */}
                        </select>
                      </div>
                    </div>
                    <ResponsiveContainer width="100%" height={250}>
                      <BarChart data={monthLoadData}>
                        <XAxis dataKey="month" stroke="#8884d8" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="trucks" fill="#06163A" barSize={30} />
                        <Bar dataKey="loads" fill="#D62D30" barSize={30} />
                      </BarChart>
                    </ResponsiveContainer>
              </div>

                  
            </div>
    
            <div className="bg-white dark:bg-gray-800 p-4 rounded shadow-md">
              <h2 className="text-lg font-semibold mb-3 text-gray-700 dark:text-white">
                Monthly Truck  Review
              </h2>
                {/* Placeholder for animated graph */}

                <div className="col-span-1 bg-white dark:bg-gray-800 p-4 rounded-lg shadow animate-pulse">
                    <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
                      <h6 className="text-lg font-semibold text-gray-900 dark:text-white">  </h6>
                      <div className="flex gap-2">
                        <select
                          value={year}
                          onChange={(e) => setYear(e.target.value)}
                          className="bg-gray-100 dark:bg-gray-700 text-sm text-gray-900 dark:text-white p-1 rounded"
                        >
                          <option value="2025">2025</option>
                          <option value="2024">2024</option>
                        </select>
                        <select
                          value={month}
                          onChange={(e) => setMonth(e.target.value)}
                          className="bg-gray-100 dark:bg-gray-700 text-sm text-gray-900 dark:text-white p-1 rounded"
                        >
                          <option value="All">All</option>
                          <option value="Jan">January</option>
                          <option value="Feb">February</option>
                          {/* Add rest of months */}
                        </select>
                      </div>
                    </div>
                    <ResponsiveContainer width="100%" height={250}>
                      <BarChart data={monthLoadData}>
                        <XAxis dataKey="month" stroke="#8884d8" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="trucks" fill="#06163A" barSize={30} />
                        <Bar dataKey="loads" fill="#06163A" barSize={30} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>


            </div>
          </div>

          {/* PERFORMANCE  */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-10">
                  
                  {/* Performance Card */}
                  <div className="col-span-2 bg-white dark:bg-gray-900 rounded-lg shadow p-6 w-full">
                    <div className="flex justify-between items-center mb-4">
                      <h5 className="text-lg font-semibold text-gray-800 dark:text-white">Performance</h5>
                      <FaEllipsisH className="text-gray-600 dark:text-white cursor-pointer" />
                    </div>
          
                    <div className="flex flex-wrap justify-between gap-4 border p-4 rounded-lg mb-4 bg-gray-50 dark:bg-gray-800">
                      <div>
                        <h5 className="text-xl font-semibold text-gray-900 dark:text-white">
                          974 <span className="text-green-500 text-sm ml-2">56% ↑</span>
                        </h5>
                        <p className="text-sm text-gray-600 dark:text-gray-300">Page Views</p>
                      </div>
                      <div>
                        <h5 className="text-xl font-semibold text-gray-900 dark:text-white">
                          1,218 <span className="text-red-500 text-sm ml-2">34% ↓</span>
                        </h5>
                        <p className="text-sm text-gray-600 dark:text-gray-300">Total Sales</p>
                      </div>
                      <div>
                        <h5 className="text-xl font-semibold text-gray-900 dark:text-white">
                          42.8% <span className="text-green-500 text-sm ml-2">22% ↑</span>
                        </h5>
                        <p className="text-sm text-gray-600 dark:text-gray-300">Conversion Rate</p>
                      </div>
                    </div>
          
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={lineData}>
                        <XAxis dataKey="name" stroke="#ccc" />
                        <YAxis stroke="#ccc" />
                        <Tooltip />
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke="#06163A"
                          strokeWidth={2}
                          fill="#06163A"
                          dot={{ r: 4 }}
                          activeDot={{ r: 6 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
          
                  {/* Top Categories Card */}
                  <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-6  w-full">
                    <div className="flex justify-between items-center mb-4">
                      <h5 className="text-lg font-semibold text-gray-800 dark:text-white">Top Categories</h5>
                      <FaEllipsisH className="text-gray-600 dark:text-white cursor-pointer" />
                    </div>
          
                    <div className="flex flex-col items-center">
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">8,452</h2>
                      <h6 className="text-sm text-gray-500 dark:text-gray-400 mb-4">Total Sessions</h6>
          
                      <ResponsiveContainer width="100%" height={250}>
                        <PieChart>
                          <Pie
                            data={pieData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            innerRadius={50}
                            fill="#06163A"
                            label
                          >
                            {pieData.map((_, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
          
                    <ul className="mt-6 space-y-2 text-sm text-gray-700 dark:text-gray-300">
                      <li className="flex justify-between items-center border-t pt-2">
                        <span>Clothing</span>
                        <span className="bg-gray-200 text-black px-3 py-1 rounded-full">558</span>
                      </li>
                      <li className="flex justify-between items-center">
                        <span>Electronics</span>
                        <span className="bg-gray-300 text-black px-3 py-1 rounded-full">204</span>
                      </li>
                      <li className="flex justify-between items-center">
                        <span>Furniture</span>
                        <span className="bg-gray-400 text-black px-3 py-1 rounded-full">108</span>
                      </li>
                    </ul>
                  </div>
          </div>

          {/* WEEKLY USER REGISTRATION DISTRIBUTION */}
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-6 w-full mt-10">
                  {/* Header */}
                  <div className="flex justify-between items-center mb-4">
                    <h5 className="text-lg font-semibold text-gray-800 dark:text-white">Weekly Registration</h5>
                    <div className="relative">
                      <FaEllipsisH className="text-gray-600 dark:text-white cursor-pointer" />
                      {/* Dropdown Menu - Placeholder (functional version can use headlessui/menu or radix-ui) */}
                      <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-gray-800 shadow-lg rounded-md p-2 z-10">
                        <button className="w-full text-left text-sm text-gray-700 dark:text-gray-200 px-2 py-1 hover:bg-gray-100 dark:hover:bg-gray-700">Action</button>
                        <button className="w-full text-left text-sm text-gray-700 dark:text-gray-200 px-2 py-1 hover:bg-gray-100 dark:hover:bg-gray-700">Another Action</button>
                        <button className="w-full text-left text-sm text-gray-700 dark:text-gray-200 px-2 py-1 hover:bg-gray-100 dark:hover:bg-gray-700">Something Else</button>
                      </div> 
                    </div>
                  </div>
          
                  {/* Chart */}
                  <div className="w-full h-[300px] sm:h-[380px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={weeklyData} margin={{ top: 10, right: 20, bottom: 0, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="name" stroke="#9ca3af" />
                        <YAxis stroke="#9ca3af" />
                        <Tooltip />
                        <Line
                          type="monotone"
                          dataKey="visits"
                          stroke="#06163A"
                          fill="#06163A"
                          strokeWidth={2}
                          dot={{ r: 4 }}
                          activeDot={{ r: 6 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
          </div>
          


        </div>
    


    );
  }
  



