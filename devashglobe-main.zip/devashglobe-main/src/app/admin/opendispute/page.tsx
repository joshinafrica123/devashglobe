"use client";

import { useEffect, useState } from "react";
// import Image from "next/image";

// import { MdRemoveRedEye } from "react-icons/md";
import user from "@/app/datatype/user";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { apiCall, BASE_URL } from "@/app/core/api";
import responce from "@/app/datatype/response";
import {
  FaBars,
  FaCircle,
  FaCopy,
  FaFileAlt,
  FaPaperPlane,
  FaTimes,
  FaUserFriends,
} from "react-icons/fa";
import { useRouter } from "next/navigation";

export default function DisputePage() {
  const [filter] = useState("All");
  const [sortAsc] = useState(true);
  const [users, setUser] = useState<user[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [messages, setMessages] = useState([
    { id: 1, from: "vendor", text: "Hi — how can I help with this load?" },
  ]);

  const [compose, setCompose] = useState("");

  const handleSend = () => {
    if (!compose.trim()) return;
    setMessages((m) => [
      ...m,
      { id: Date.now(), from: "you", text: compose.trim() },
    ]);
    setCompose("");
  };
  // const [selectedUser, setSelectedUser] = useState<user>(x);
  // const [loading, setLoading] = useState(false);
  // const [filterOpen, setFilterOpen] = useState(false);
  const router = useRouter();

  console.log(users);

  const filteredUsers = users
    ?.filter((user) => filter === "All" || user.status === filter)
    .sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

  useEffect(() => {
    handleGetUser();
    // setLoading(false);
    console.log(filteredUsers);
  }, []);

  async function handleGetUser() {
    try {
      // get logged in admin token
      const token = getCookie("not_usertoken");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/users`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }

      const data = await response.json();
      console.log(data);

      const dataTypeed = data as responce;

      if (dataTypeed.error) {
        const errList: string[] = [dataTypeed?.error];
        setErrors(errList);
      } else {
        console.log(dataTypeed.notuser);
        setUser(dataTypeed.user);
      }
    } catch (error) {
      console.error("equipment error:", error);
      console.error("equipment error:", errors);
    }
  }

  return (
    <div className="p-4 md:p-6">
      <div className="mb-4 flex justify-items-start items-center">
        <FaUserFriends size={20} color="#8C8C8C" />
        <p
          onClick={() => router.push("/admin/dispute/")}
          className="text-xl text-[#8C8C8C] m-5 cursor-pointer"
        >
          Disputes
        </p>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={1.5}
          stroke="#8C8C8C"
          className="w-5 h-5"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
        </svg>
        <h2 className="text-xl font-semibold text-[#06163A] dark:text-white">
          New Dispute
        </h2>
      </div>

      {/* main content */}
      <section className="grid grid-cols-1 md:grid-cols-[2fr_3fr] gap-6">
        {/*   LEFT PANE */}
        <div className=" bg-[#fff] dark:bg-[#06163A] border border-[#CBD5E1] rounded-xl shadow cursor-pointer">
          {/* header   */}
          <div className="flex items-center justify-between mb-4 border-b-2  p-4">
            <div className="grid items-center gap-2 text-[#8C8C8C]">
              <span className="font-semibold text-[#000000]">Open Dispute</span>
              <div className="flex items-center justify-center rounded-full text-[#8C8C8C] text-xs">
                Dispute ID: 1319635737{" "}
                <FaCopy size={12} className="ml-2 cursor-pointer" />
              </div>
            </div>
            <div className="flex items-center gap-2 ">
              <span
                style={{
                  fontSize: "12px ",
                  padding: "2px 6px",
                  borderRadius: "10px",
                  border: "2px",
                }}
              ></span>
            </div>
          </div>
          {/* body */}
          <div className="flex items-center justify-between mb-2  px-4">
            <div className="flex items-center gap-2 text-[#8C8C8C]">
              Shipment Amount:
            </div>
            <div className="flex items-center gap-2 text-[#D62D2D] ">
              $7,000
            </div>
          </div>

          <div className="flex items-center justify-between mb-2  px-4">
            <div className="flex items-center gap-2 text-[#8C8C8C]">
              Cargo Type:
            </div>
            <div className="flex items-center gap-2 text-[#000000] ">
              Electronics
            </div>
          </div>

          <div className="flex items-center justify-between mb-2  px-4">
            <div className="flex items-center gap-2 text-[#8C8C8C]">
              Weight:
            </div>
            <div className="flex items-center gap-2 text-[#000000] ">
              20 tons
            </div>
          </div>

          <hr className="my-4 border-[#CBD5E1]" />

          <div className="flex items-center justify-between mb-2  px-4">
            <div className="flex items-center gap-2 text-[#8C8C8C]">
              Merchant
            </div>
            <div className="flex items-center gap-2 text-[#000000] ">
              Florence Cyan
            </div>
          </div>

          <div className="flex items-center justify-between mb-2  px-4">
            <div className="flex items-center gap-2 text-[#8C8C8C]">
              Carrier
            </div>
            <div className="flex items-center gap-2 text-[#000000] ">
              Argo-Import
            </div>
          </div>

          <hr className="my-4 border-[#CBD5E1]" />

          <div className="flex items-center justify-between mb-2  px-4">
            <div className="flex items-center gap-2 text-[#8C8C8C]">
              Pickup Date
            </div>
            <div className="flex items-center gap-2 text-[#000000] ">
              12/11/2025
            </div>
          </div>

          <div className="flex items-center justify-between mb-2  px-4">
            <div className="flex items-center gap-2 text-[#8C8C8C]">
              Delivery Date
            </div>
            <div className="flex items-center gap-2 text-[#000000] ">
              15/11/2025
            </div>
          </div>

          <hr className="my-4 border-[#CBD5E1]" />

          <div className="grid p-4 mt-2">
            <h3 className="flex  text-[#8C8C8C] dark:text-white ">Reason for Dispute</h3>
            <p className="text-xs font-semibold text-[#404040] mt-2 wrap-normal ">
              Damaged goods during transit
            </p>
          </div>
        </div>

        {/* RIGHT: Payment / Negotiation */}
        <div className="w-full   bg-white  dark:bg-gray-900">
          {/* price header */}
          <div className="flex items-center justify-between p-4 border-2 border-[#CFE7FB]">
            <div>
              <div className="flex font-bold text-sm text-gray-500 dark:text-gray-400">
                Dispute - 032
                <span
                  style={{
                    background: "#FFFBEB",
                    fontSize: "12px ",
                    padding: "2px 6px",
                    borderRadius: "10px",
                    color: "#F59E0B",
                    border: "2px",
                    borderColor: "#F59E0B",
                  }}
                >
                  .Under Review
                </span>
              </div>
              <div className="flex mt-2 text-sm text-gray-500 dark:text-gray-400">
                <span className="flex font-medium text-gray-800 dark:text-gray-200 ml-2">
                  <FaCircle size={18} color="#10B981" className="pr-2" />
                  Florence Cyan
                </span>

                <span className="flex font-medium text-gray-800 dark:text-gray-200 ml-2">
                  <FaCircle size={18} color="#CBD5E1" className="pr-2" />
                  Argo-Import
                </span>
              </div>
            </div>

            <div className="flex flex-col items-end gap-2">
              <FaBars size={16} />
            </div>
          </div>

          <div className="mt-6">
            {/* Panel */}
            <div className="">
              <div className="grid items-center gap-2 m-4">
                <div className="flex mt-2 text-sm text-gray-500 dark:text-gray-400">
                  <span className="flex text-xs p-2 rounded-2xl text-[#1976D2] bg-[#CFE7FB] dark:text-gray-200 ml-2">
                    @Florence
                  </span>
                  <span className="flex text-xs p-2 font-medium text-gray-800 dark:text-gray-200 ml-2">
                    Welcome
                  </span>
                </div>

                <div
                  className={`max-w-[60%] p-3  rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-100`}
                >
                  <div className="text-sm">
                    Support will be you shortly. To close this press the close
                    button below
                  </div>
                </div>
                {/* FILTER BUTTON */}
                <button className="max-w-[80px] flex justify-between items-end  p-2 rounded-md bg-[#1976D2] dark:bg-[#112244] mb-4 text-white dark:text-white hover:bg-gray-200 dark:hover:bg-[#0b1f41] transition">
                  <FaTimes size={12} className="mb-1 mr-2 ml-2" />
                  Close
                </button>
              </div>

              <div className="flex flex-col h-[320px]">
                <div className="flex-1 overflow-y-auto space-y-3 pr-2 p-4">
                  {messages.map((m) => (
                    <div
                      key={m.id}
                      className={`max-w-[60%] p-3 rounded-lg ${
                        m.from === "you"
                          ? "ml-auto bg-indigo-600 text-white"
                          : "bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                      }`}
                    >
                      <div className="text-sm">{m.text}</div>
                    </div>
                  ))}
                </div>

                <div className="mt-3 flex items-center gap-3 border-2 border-[#CFE7FB] p-4">
                  <FaFileAlt color="#8C8C8C" size={14} />
                  <input
                    value={compose}
                    onChange={(e) => setCompose(e.target.value)}
                    placeholder="Enter message here..."
                    className="flex-1 rounded-md  dark:border-gray-800 px-3 py-2 bg-white dark:bg-gray-900 text-sm text-gray-900 dark:text-gray-100"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleSend();
                      }
                    }}
                  />
                  <button
                    onClick={handleSend}
                    className="px-4 py-2 rounded-md  text-white"
                  >
                    <FaPaperPlane color="#8C8C8C" size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
