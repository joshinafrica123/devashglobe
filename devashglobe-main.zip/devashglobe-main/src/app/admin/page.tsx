"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
 import {  setCookies } from "../datatype/frontEndCookiee";
//  import { BASE_URL } from "../core/api";
import Image from "next/image";
import { Eye, EyeOff } from "lucide-react";

interface Admin {
    id: number, 
    email: string,
    user_type: string , 
    level:number,
    password_hash:string,
    status:string ,
    date:string,
    deleted:number,
    updated_at:string,
    };


    interface i {
      message : string,
      token:string,
      Admin:Admin []
    }

const data: i = {
    "message": "Welcome back! admin@globlehigh.com",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNzY5MTg1NjgxLCJleHAiOjE3NzEwMDAwODF9.QQ1yRC6bFjq71HgUDxuA22b4rTp9KW7G8HRYG_zvDtI",
    "Admin": [
        {
            "id": 1,
            "email": "admin@globlehigh.com",
            "user_type": "admin",
            "level": 1,
            "password_hash": "",
            "date": "2025-08-19T16:23:24.000Z",
            "status": "active",
            "deleted": 0,
            "updated_at": "2025-08-19T16:23:24.000Z"
        }
    ]
}

export default function AdminLoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
   const router = useRouter();
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      // // TODO remove (uncomment) when there is server
      // const res = await fetch(`${BASE_URL}/different/login`, {
      //   method: "POST",
      //   headers: { "Content-Type": "application/json" },
      //   body: JSON.stringify({ email, password }),
      // });
      // const data = await res.json();
      // if (!res.ok || data.error) {
      //   console.error("Login error:", data.error || res.statusText);
      //   throw new Error("Login failed");
      // }
      // // Save token/cookie if needed
      // setCookie(data, "not_user", "", "", email);
       console.log(data);
      console.log(email,password);
      // TODO pending the time admin@globlehigh.com,Admin@test123#
      if( email === "admin@globlehigh.com" && password === "Admin@test123#" ){
              console.log(email,password," 👋");
               setCookies(data , "not_user", "", "", email);
        router.push("/admin/dashboard");
      }else{
        console.log("hello!!!")
         console.error("Login error:");
         throw new Error("Login failed");
      // router.push("/admin/dashboard");
      }

      console.log("hello!---")

    } catch (err) {
      setError(
        err instanceof Error ? err.message : "An unexpected error occurred"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left: Form Section */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-8 bg-gradient-to-br from-[#ffffff] to-[#f9fafb] dark:from-gray-900 dark:to-gray-800">
        <form
          onSubmit={handleSubmit}
          className="bg-white dark:bg-gray-900  p-6 sm:p-8 w-full "
        >
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <Image
              src="/assets/img/ASHlogo.png"
              alt="Ashglobe Logo"
              width={160}
              height={160}
              className="rounded-full"
            />
          </div>

          {/* Headings */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center mb-3 text-[#06163A] dark:text-[#D62D30]">
            Welcome to Ashglobe
          </h1>
          <p className="text-center text-lg sm:text-xl text-gray-600 dark:text-gray-400 mb-6">
            Your trusted space for global shipping and delivery.
          </p>

          {/* Email */}
          <div className="mb-6">
            <label className="block mb-1 font-semibold text-sm sm:text-base">
              Email
            </label>
            <input
              type="email"
              className="w-full p-3 border-2 border-[#D0D5DD] rounded focus:outline-none focus:ring-2 focus:ring-[#D62D30]"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="admin@example.com"
            />
          </div>

          {/* Password */}
          <div className="mb-2 relative">
            <label className="block mb-1 font-semibold text-sm sm:text-base">
              Password
            </label>
            <input
              type={showPassword ? "text" : "password"}
              className="w-full p-3 border-2 border-[#D0D5DD] rounded focus:outline-none focus:ring-2 focus:ring-[#D62D30]"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-10 text-gray-500 hover:text-[#D62D30]"
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          {/* Forgot Password */}
          <div className="text-right mb-6 mt-4">
            <a
              href="/admin/forgotpassword"
              className="text-sm text-[#320DFF] hover:underline font-semibold"
            >
              Forgot password?
            </a>
          </div>

          {/* Error Message */}
          {error && (
            <div className="text-red-600 mb-2 text-center text-sm">{error}</div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-2 rounded bg-[#01245A] text-white font-bold hover:bg-[#D62D30] transition"
            disabled={loading}
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>

      {/* Right: Image Section with Overlay */}
      <div className="flex-1 relative hidden md:block">
        <Image
          src="/assets/img/admin-cover.jpg"
          alt="Login Illustration"
          fill
          className="object-cover"
          priority
        />
        {/* Soft overlay */}
        <div className="absolute inset-0 bg-black/40 mix-blend-multiply" />
      </div>
    </div>
  );
}
