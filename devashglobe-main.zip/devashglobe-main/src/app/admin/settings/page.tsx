"use client";
import OrdersPage from "@/components/userprofile/OrdersPage";
import OverviewPage from "@/components/userprofile/OverviewPage";
import SettingsPage from "@/components/userprofile/SettingsPage";
import ShipmentsPage from "@/components/userprofile/ShipmentsPage";
// import Image from "next/image";
import { useState } from "react";
import {
  FaAdjust,
  FaBell,
  FaSave,
  FaUserAstronaut,
  FaUsersCog,
} from "react-icons/fa";

type UserStats = {
  followers?: number;
  following?: number;
  posts?: number;
};

export type OverviewUser = {
  id: string;
  name: string;
  email?: string;
  avatarUrl?: string;
  bio?: string;
  location?: string;
  website?: string;
  stats?: UserStats;
};

const AccountSettings = () => {
  const [filterOpen, setFilterOpen] = useState(false);

  //   const [user] = useState({
  //     id: "1",
  //     name: "John Doe",
  //     email: "john.doe@example.com",
  //     avatarUrl: "/path/to/avatar.jpg",
  //     bio: "Lorem ipsum dolor sit amet.",
  //     location: "New York, USA",
  //     website: "https://johndoe.com",
  //     stats: {
  //       followers: 100,
  //       following: 50,
  //       posts: 10,
  //     },
  //   }
  // );

  console.log("Filter Open:", filterOpen);

  const tabs = [
    {
      id: 1,
      label: "Account",
      icon: <FaUsersCog size={14} style={{ marginRight: 4 }} />,
      component: <OverviewPage />,
    },
    {
      id: 2,
      label: "User Account",
      icon: <FaUserAstronaut size={14} style={{ margin: 4 }} />,
      component: <OrdersPage />,
    },
    {
      id: 3,
      label: "Notification",
      icon: <FaBell size={14} style={{ margin: 4 }} />,
      component: <ShipmentsPage />,
    },
    {
      id: 4,
      label: "System Logs",
      icon: <FaAdjust size={14} style={{ margin: 4 }} />,
      component: <SettingsPage />,
    },
  ];

  const [activeTab, setActiveTab] = useState(1);

  return (
    <div className="p-4 md:p-6 ">
      {/* TOP BAR — TITLE + SUBTITLE + CONTROLS */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-5 gap-2">
        {/* LEFT SIDE TITLES */}
        <div>
          <h2 className="text-xl font-semibold text-[#06163A] dark:text-white">
            Settings
          </h2>
        </div>

        {/* RIGHT SIDE CONTROLS */}
        <div className="flex items-center gap-3">
          {/* FILTER BUTTON */}
          <button
            onClick={() => setFilterOpen(true)}
            className="flex justify-between items-end  p-2 rounded-md bg-[#01245A] dark:bg-[#112244] text-white dark:text-white hover:bg-gray-200 dark:hover:bg-[#0b1f41] transition"
          >
            <FaSave size={12} className="mb-1 mr-2 ml-2" />
            Save Changes
          </button>

          {/* VIEW ALL BUTTON */}
          {/* <Link
                    href="../admin/transaction"
                    className="text-sm px-4 py-2 rounded-md bg-[#06163A] text-white dark:bg-white dark:text-[#06163A] hover:opacity-90 transition"
                  >
                    View All
                  </Link> */}
        </div>
      </div>

      <div className="flex flex-col md:flex-row w-full min-h-[400px] bg-white dark:bg-slate-900 rounded-2xl shadow border border-slate-100 dark:border-slate-800">
        {/* MOBILE TABS (TOP) */}
        <div className="md:hidden border-b border-slate-200 dark:border-slate-700">
          <div className="flex overflow-x-auto scrollbar-hide">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 whitespace-nowrap px-4 py-3 text-sm font-medium transition
            ${
              activeTab === tab.id
                ? "border-b-2 border-[#D62D2D] text-[#D62D2D]"
                : "text-slate-500"
            }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* DESKTOP TABS (LEFT SIDEBAR) */}
        <aside className="hidden md:block w-56 border-r border-slate-200 dark:border-slate-700">
          <ul className="flex flex-col">
            {tabs.map((tab) => (
              <li key={tab.id}>
                <button
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex w-[90%] items-center gap-2 px-5 py-3 m-2 text-sm font-medium transition
              ${
                activeTab === tab.id
                  ? "bg-[#FF45450D] text-[#D62D2D] dark:bg-slate-800 dark:text-white"
                  : "text-[#999999] hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800"
              }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              </li>
            ))}
          </ul>
        </aside>

        {/* RIGHT CONTENT PANE */}
        <section className="flex-1 p-4 md:p-6 overflow-auto">
          {tabs.find((tab) => tab.id === activeTab)?.component}
        </section>
      </div>
    </div>
  );
};

export default AccountSettings;
