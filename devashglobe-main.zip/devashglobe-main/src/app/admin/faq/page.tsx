"use client"

import  { useState } from 'react';
// import { FaEye, FaTrash } from 'react-icons/fa';

// TODO TO  BE FIXED LATER

export default function FAQAccordion()  {

  const [expanded, setExpanded] = useState(0);
  const [openModal, setOpenModal] = useState(false);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [faqs, setFaqs] = useState([
    {
      id: 1,
      question: "Just once I'd like to eat dinner with a celebrity?",
      answer: 'Yes, if you make it look like an electrical fire...',
    },
    {
      id: 2,
      question: "Bender, I didn't know you liked cooking?",
      answer: "That's so cute. Can we have Bender Burgers again?",
    },
  ]);

  const handleAccordionClick = (index:number) => {
    setExpanded(expanded === index ? 0 : index);
  };

  const handleAddFaq = () => {
    const newFaq = {
      id: faqs.length + 1,
      question,
      answer,
    };
    setFaqs([...faqs, newFaq]);
    setQuestion('');
    setAnswer('');
    setOpenModal(false);
  };

  // const handleDeleteFaq = (id:number) => {
  //   setFaqs(faqs.filter((faq) => faq.id !== id));
  // };

  return (
    <div className="w-full max-w-2xl mx-auto p-4">
      {faqs.map((faq, index) => (
        <div
          key={faq.id}
          className="border border-gray-300 rounded-md mb-4 overflow-hidden bg-white shadow-md"
        >
          <button
            onClick={() => handleAccordionClick(index)}
            className="w-full flex justify-between items-center px-4 py-3 text-left text-[#06163A] font-semibold text-base md:text-lg bg-gray-100 hover:bg-gray-200 transition"
          >
            <span>{faq.question}</span>
            <div className="flex items-center gap-2">
              {/* <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteFaq(faq.id);
                }}
                className="text-[#D62D30] hover:text-red-600 text-sm"
              >
                <FaEye fill='#06163A' />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteFaq(faq.id);
                }}
                className="text-[#D62D30] hover:text-red-600 text-sm"
              >
                <FaTrash /> 
              </button> */}
              <span className="text-gray-500">{expanded === index ? '▲' : '▼'}</span>
            </div>
          </button>
          {expanded === index && (
            <div className="px-4 py-3 text-sm md:text-base text-gray-800 bg-white">
              {faq.answer}
            </div>
          )}
        </div>
      ))}

      <button
        onClick={() => setOpenModal(true)}
        className="mt-4 bg-[#D62D30] hover:bg-red-600 text-white px-4 py-2 rounded-md font-semibold flex items-center gap-2"
      >
        ➕ Add FAQ
      </button>

      {/* Modal */}
      {openModal && (
        <div className="fixed inset-0 bg-[#06163A] bg-opacity-50 z-50 flex items-center justify-center " >
         
          <div className="bg-white w-[90%] md:w-[400px] rounded-lg p-6 shadow-lg relative ">
             <button onClick={() => setOpenModal(false)} className='text-red-500 absolute  top-0 right-0  rounded-full text-sm p-2 '>x</button>
            <h2 className="text-xl font-semibold mb-4 text-[#06163A]">Add New FAQ</h2>

            <label className="block text-sm font-medium text-gray-700 mb-1">Question</label>
            <input
              type="text"
              className="w-full border border-gray-300 rounded px-3 py-2 mb-4 focus:outline-none focus:ring-2 focus:ring-[#06163A]"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Enter your question"
            />

            <label className="block text-sm font-medium text-gray-700 mb-1">Answer</label>
            <textarea
              rows={5}
              className="w-full border border-gray-300 rounded px-3 py-2 mb-4 resize-y focus:outline-none focus:ring-2 focus:ring-[#06163A]"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="Enter your answer"
            ></textarea>

            <button
              onClick={handleAddFaq}
              className="w-full bg-[#06163A] hover:bg-blue-900 text-white py-2 px-4 rounded-md font-semibold mb-2"
            >
              Save
            </button>
            <button
              onClick={() => setOpenModal(false)}
              className="w-full text-gray-600 hover:text-gray-800 text-sm"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

