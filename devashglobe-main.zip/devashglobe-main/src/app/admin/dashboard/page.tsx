"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { FaFilter, FaMapMarkerAlt, FaSearch } from "react-icons/fa";
import { Contracts } from "@/app/datatype/data";
import { FaDollarSign, FaBoxOpen, FaTruck } from "react-icons/fa";

import {
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";

// import Card from "@/components/admin/cardComponentTruck";
// import CardLoad from "@/components/admin/cardComponentLoad";
// import CardUser from "@/components/admin/cardComponentUser";
import Link from "next/link";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { apiCall, BASE_URL } from "@/app/core/api";
import responce from "@/app/datatype/response";
import { loadboard } from "@/app/datatype/loadboards";
// import user from "@/app/datatype/user";
import {
  dataStat,
  filterLoadboardByType,
  handleSetTructStat,
} from "@/app/core/util";

// No change needed at the top — same imports

export default function DashboardPage() {
  const router = useRouter();
  const [filter] = useState("All");
  const [sortAsc] = useState(true);
  const [year, setYear] = useState("2025");
  // const [month, setMonth] = useState('All');
  // const [totalusers, setTotalUser] = useState(0);
  const [errors, setErrors] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  // const [loadboards, setLoadboards] = useState<loadboard[]>([]);
  const [totalloads, setTotalLoad] = useState(0);
  // const [totaltrucks, setTotalTruck] = useState(0);
  // const [users_, setUser] = useState<user[]>([]);
  // const [donutdata] = useState<DonutData[]>([]);
  const [statloaddata, setStatLoadData] = useState<dataStat[]>();
  // const [stattruckdata, setStatTruckData] = useState<dataStat[]>();
  const [contracts] = useState<Contracts[]>([]);
  const [rangeType, setRangeType] = useState("month");
  const [search, setSearch] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  // setFilter('All');

  const ckdata = [
    { name: "Successful (30)", value: 40 },
    { name: "Pending (15)", value: 25 },
    { name: "Refunded (5)", value: 15 },
  ];
  const filteredContracts = contracts
    .filter((contract) => filter === "All" || contract.status === filter)
    .sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

  const handleRowClick = (id: string) => {
    const contractId = id.replace("#", "");
    router.push(`/contracts/${contractId}`);
  };

  useEffect(() => {
    handleGetLoadBoard();
    handleGetUser();
  }, []);

  const setLoadTruct = (x: loadboard[]) => {
    setTotalLoad(filterLoadboardByType(x, "load").length);
    // setTotalTruck(filterLoadboardByType(x, "truck").length);

    // set stat data
    // setStatTruckData(
    //   handleSetTructStat(
    //     { body: filterLoadboardByType(x, "truck"), status: true },
    //     "truck"
    //   )
    // );
    console.log("load stat data", search, filterOpen);
    setStatLoadData(
      handleSetTructStat(
        { body: filterLoadboardByType(x, "load"), status: true },
        "load"
      )
    );
  };

  async function handleGetUser() {
    try {
      // get logged in admin token
      const token = getCookie("not_usertoken");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/users`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }

      const data = await response.json();
      console.log(data);

      const dataTypeed = data as responce;

      if (dataTypeed.error) {
        const errList: string[] = [dataTypeed?.error];
        setErrors(errList);
      } else {
        console.log(dataTypeed.users);
        // setTotalUser(dataTypeed.size);
        // setUser(dataTypeed.user);
      }
    } catch (error) {
      console.error("equipment error:", error);
      console.error("equipment error:", errors);
    }
  }

  async function handleGetLoadBoard() {
    setLoading(true);
    try {
      const token = getCookie("not_usertoken");

      const response = await apiCall(
        token + "",
        `${BASE_URL}/loadboards`,
        "GET",
        null
      );

      if (!response.ok) {
        throw new Error(`Failed to get : ${response.status}`);
      }
      const data = await response.json();
      const dataTypeed = data as responce;
      if (dataTypeed.error) {
        setErrors([dataTypeed.error]);
      } else {
        // setLoadboards(dataTypeed.loadboard);
        setLoadTruct(dataTypeed.loadboard);

        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
      console.error("faq error:", error);
      console.error("faq error:", errors);
    }
  }

  const dashboardCards = [
    // {
    //   label: "Total Users",
    //   value: totalusers,
    //   icon: <FaUsers size={28} />,
    //   bg: "#06163A",
    //   footerText: "View all users",
    // },
    {
      label: "Active Shipments",
      value: "426",
      icon: <FaDollarSign size={28} />,
      bg: "#D62D30",
      footerText: "View revenue details",
    },
    {
      label: "Opened Disputes",
      value: "6",
      icon: <FaDollarSign size={28} />,
      bg: "#06163A",
      footerText: "View all Disputes",
    },
    {
      label: "Users Registered",
      value: 546,
      icon: <FaTruck size={28} />,
      bg: "#D62D30",
      footerText: "View all Registered Users",
    },
    {
      label: "Funds In Escrow",
      value: "$" + (totalloads + 500),
      icon: <FaBoxOpen size={28} />,
      bg: "#06163A",
      footerText: "View all registerd Loads",
    },
  ];

  const CardsSkeleton = () => (
    <>
      {[...Array(5)].map((_, idx) => (
        <div
          key={idx}
          className="p-4 rounded shadow-md text-white animate-pulse"
          style={{ backgroundColor: idx % 2 === 0 ? "#06163A" : "#D62D30" }}
        >
          <div className="flex justify-between items-center">
            <div>
              <div className="h-4 w-24 bg-gray-700 rounded mb-2" />
              <div className="h-6 w-16 bg-gray-600 rounded" />
            </div>
            <div className="w-8 h-8 bg-gray-700 rounded-full" />
          </div>
        </div>
      ))}
    </>
  );

  return (
    <div className="p-4 sm:p-6 bg-white dark:bg-gray-900 min-h-screen w-full">
      <h1 className="text-xl sm:text-2xl font-bold  text-[#000000] dark:text-white">
        Overview
      </h1>
      <p className="text-[#8C8C8C]">
        Overview of key insights and platform activities.
      </p>

      {/* Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {loading ? (
          <CardsSkeleton />
        ) : (
          dashboardCards?.map((item, idx) => (
            <div
              key={idx}
              className=" rounded-xl shadow-md  flex flex-col justify-between mt-5 border-1 border-[#E4E4E7] "
            >
              {/* TOP SECTION */}
              <div className="flex justify-between items-start p-4">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-[#71717A]">
                    {item.label}
                  </p>
                  <h3 className="text-3xl font-bold mt-4">{item.value}</h3>
                </div>
              </div>

              {/* FOOTER (CLICKABLE) */}
              <button
                onClick={() => console.log("Clicked")}
                className="bg-[#FFC4C426] mt-4 p-4 flex justify-between items-center w-full text-left text-sm font-medium opacity-90 hover:opacity-100 transition cursor-pointer"
              >
                <span className="text-[#E3000080]">{item.footerText}</span>
                <span className="text-lg">
                  {/* Example arrow icon */}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="#E3000080"
                    className="w-5 h-5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </span>
              </button>
            </div>
          ))
        )}
      </div>

      {/* Graphs Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {["Shipments Over Time"].map((title, i) => (
          <div
            key={i}
            className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md"
          >
            {/* HEADER SECTION */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-3">
              {/* LEFT TEXT */}
              <div>
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                  {title}
                </h2>
              </div>

              {/* RIGHT FILTERS */}
              <div className="flex items-center gap-3">
                {/* TABS */}
                <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                  {["Week", "Month", "Year"].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setRangeType(tab.toLowerCase())}
                      className={`px-3 py-1 text-sm rounded-md transition
                ${
                  rangeType === tab.toLowerCase()
                    ? "bg-blue-600 text-white"
                    : "text-gray-700 dark:text-gray-300"
                }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                {/* YEAR FILTER */}
                <select
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                  className="bg-gray-100 dark:bg-gray-700 text-sm p-1 rounded text-gray-900 dark:text-white"
                >
                  <option value="2025">2025</option>
                  <option value="2024">2024</option>
                </select>
              </div>
            </div>

            {/* LINE CHART */}
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={statloaddata}>
                <XAxis dataKey="month" stroke="#8884d8" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="loads"
                  stroke={i === 0 ? "#226CE0" : "#06163A"}
                  strokeWidth={1}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        ))}

        {["Shipment Status"].map((title, i) => (
          <div
            key={i}
            className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md"
          >
            {/* HEADER BAR */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-3">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                {title}
              </h2>

              {/* YEAR FILTER */}
              <div className="flex items-center gap-2">
                <select
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                  className="bg-gray-100 dark:bg-gray-700 text-sm p-1 rounded text-gray-900 dark:text-white"
                >
                  <option value="2025">2025</option>
                  <option value="2024">2024</option>
                </select>
              </div>
            </div>

            {/* PIE + LEGEND AREA */}
            <div className="flex justify-between items-center">
              {/* PIE CHART */}
              <ResponsiveContainer width="60%" height={240}>
                <PieChart>
                  <Pie
                    data={ckdata}
                    dataKey="value"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    label
                  >
                    {["#1685AA", "#FE5000E3", "#165BAAE3"].map((color, idx) => (
                      <Cell key={idx} fill={color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>

              {/* LEGEND (BOTTOM RIGHT) */}
              <div className="flex flex-col gap-3 text-sm text-gray-700 dark:text-gray-200 pr-3">
                {ckdata.map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-sm"
                      style={{
                        background: ["#1685AA", "#FE5000E3", "#165BAAE3"][i],
                      }}
                    ></span>
                    <span>{item.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Donut Charts */}
      {/* <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-6 w-full mt-10">
        <h1 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
          Smart contract progress track
        </h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
          {donutdata?.map((item, index) => {
            const donutValue = [
              { name: item.label, value: item.value },
              { name: "Remaining", value: item.total - item.value },
            ];

            return (
              <div
                key={index}
                className="border dark:border-gray-700 rounded-lg p-4 text-center"
              >
                <div className="flex justify-center h-[130px]">
                  <ResponsiveContainer width={130} height={130}>
                    <PieChart>
                      <Pie
                        data={donutValue}
                        innerRadius={40}
                        outerRadius={60}
                        paddingAngle={2}
                        dataKey="value"
                        startAngle={90}
                        endAngle={450}
                      >
                        <Cell fill={item.color} />
                        <Cell fill="#06163a26" />
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <h6 className="mt-3 text-sm font-semibold text-gray-800 dark:text-white">
                  {item.label} : {item.count}
                </h6>
              </div>
            );
          })}
        </div>
      </div> */}

      {/* Recent Categories */}
      {/* <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-6 w-full mt-10">
        <h5 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
          Recents Categories
        </h5>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          <CardUser
            title="Recently Registered"
            data={users_}
            type="users"
            location="../admin/user"
          />
          <CardLoad
            title="Recent Loads"
            data={filterLoadboardByType(loadboards, "load")}
            type="loads"
            location="../admin/load"
          />
          <Card
            title="Recent Trucks"
            data={filterLoadboardByType(loadboards, "truck")}
            type="trucks"
            location="../admin/truck"
          />
        </div>
      </div> */}

      {/* Smart Contracts Table */}
      <div className="bg-white dark:bg-[#06163A] shadow border border-[#CBD5E1] rounded-xl p-5 w-full mt-10">
        {/* TOP BAR — TITLE + SUBTITLE + CONTROLS */}
        <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-5 gap-3">
          {/* LEFT SIDE TITLES */}
          <div>
            <h2 className="text-lg font-semibold text-[#06163A] dark:text-white">
              Payment Status
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-300 mt-1">
              Monitor payment progress by shipment
            </p>
          </div>

          {/* RIGHT SIDE CONTROLS */}
          <div className="flex items-center gap-3">
            {/* SEARCH INPUT */}
            <div className="relative">
              <FaSearch className="absolute left-2 top-2.5 text-gray-400 text-sm" />
              <input
                type="text"
                placeholder="Search..."
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 pr-3 py-2 text-sm rounded-md border dark:bg-[#112244] text-gray-700 dark:text-white outline-none"
              />
            </div>

            {/* FILTER BUTTON */}
            <button
              onClick={() => setFilterOpen(true)}
              className="p-2 rounded-md bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white hover:bg-gray-200 dark:hover:bg-[#0b1f41] transition"
            >
              <FaFilter />
            </button>

            {/* VIEW ALL BUTTON */}
            <Link
              href="../admin/transaction"
              className="text-sm px-4 py-2 rounded-md bg-[#06163A] text-white dark:bg-white dark:text-[#06163A] hover:opacity-90 transition"
            >
              View All
            </Link>
          </div>
        </div>

        {/* TABLE */}
        <div className="overflow-x-auto">
          <table className="min-w-[800px] w-full text-sm text-left border-collapse">
            <thead className="bg-gray-100 dark:bg-[#112244] text-gray-600 dark:text-white">
              <tr>
                <th className="py-2 px-3">Shipment ID</th>
                <th className="py-2 px-3">Shipper</th>
                <th className="py-2 px-3">Carrier</th>
                <th className="py-2 px-3">Amount</th>
                {/* <th className="py-2 px-3">Status</th>
                <th
                  className="py-2 px-3 cursor-pointer hover:text-[#D62D30]"
                  onClick={() => setSortAsc(!sortAsc)}
                >
                  Date {sortAsc ? "↑" : "↓"}
                </th>
                <th className="py-2 px-3" onClick={() => setFilter("All")}>
                  Location
                </th>
                <th className="py-2 px-3">Price</th> */}
                <th className="py-2 px-3">Status</th>
              </tr>
            </thead>

            <tbody className="text-gray-700 dark:text-gray-200">
              {filteredContracts?.map((contract) => (
                <tr
                  key={contract.id}
                  onClick={() => handleRowClick(contract.id)}
                  className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-[#0b1f41] cursor-pointer"
                >
                  <td className="py-3 px-3">{contract.id}</td>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <Image
                        src={contract.load}
                        alt="Load"
                        width={40}
                        height={40}
                        className="rounded"
                      />
                      <span>{contract.title}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3">{contract.shipper}</td>
                  <td className="py-3 px-3">{contract.carrier}</td>
                  <td className="py-3 px-3">
                    <Image
                      src={contract.truck}
                      alt="Truck"
                      width={40}
                      height={40}
                      className="rounded"
                    />
                  </td>
                  <td className="py-3 px-3">
                    {new Date(contract.date).toDateString()}
                  </td>
                  <td className="py-3 px-3 flex items-center gap-1">
                    <FaMapMarkerAlt className="text-[#D62D30]" />
                    <span>{contract.location}</span>
                  </td>
                  <td className="py-3 px-3">{contract.price}</td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        contract.status === "Pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : contract.status === "Completed"
                          ? "bg-green-100 text-green-800"
                          : "bg-blue-100 text-blue-800"
                      }`}
                    >
                      {contract.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredContracts.length === 0 && (
            <div className="text-center text-sm text-gray-500 mt-4">
              No contracts found yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
