import SignInForm from "@/components/users/signupComponent";
// import Image from "next/image";

export default function Joinus() {
  return (
    <div className="min-h-screen grid ">
      <div className="flex items-center justify-center p-6 bg-[#10429a3d] dark:bg-gray-950">
        <SignInForm />
      </div>
      {/* <div className="hidden md:block relative">
        <Image
          src="/assets/img/sign/1si.jpg" // place this image inside /public/images/
          alt="Login banner"
          fill
          className="object-cover"
        />
      </div> */}
    </div>
  );
}
