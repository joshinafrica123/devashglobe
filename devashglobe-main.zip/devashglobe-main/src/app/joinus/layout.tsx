import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";

import Header from "../includes/header";
// import Footer from "../includes/footer";

import "../globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AshGlobe Logistics",
  description: "Smart Logistics on smart contracts",
};

export default function RootLayout( {children,}: Readonly<{children: React.ReactNode;}> ) {
  
  return (

      <html lang="en">
        <body
          className={`${geistSans.variable} ${geistMono.variable} antialiased`}
        >
          <Header isHome={false}/>
          {children}
        </body>
      </html>
  );
}
