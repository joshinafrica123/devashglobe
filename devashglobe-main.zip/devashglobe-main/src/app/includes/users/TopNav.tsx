"use client";

import { getCookie } from "@/app/datatype/frontEndCookiee";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { FaBell, FaCheckCircle } from "react-icons/fa";

    export const  colorLog = (letter: string) => {
      console.log("Letter:", letter);
      let color = "";
      if(letter === "a") color = "bg-[#f00]";
      else if(letter === "b") color = "bg-[#0f0]";
      else if(letter === "c") color = "bg-[#00f]";
      else if(letter === "d") color = "bg-[#ff0]";
      else if(letter === "e") color = "bg-[#0ff]";
      else if(letter === "f") color = "bg-[#f0f]";
      else if(letter === "g") color = "bg-[#f80]";
      else if(letter === "h") color = "bg-[#8f0]";
      else if(letter === "i") color = "bg-[#0f8]";
      else if(letter === "j") color = "bg-[#f08]";
      else if(letter === "k") color = "bg-[#8f8]";
      else if(letter === "l") color = "bg-[#88f]";
      else if(letter === "m") color = "bg-[#f88]";
      else if(letter === "n") color = "bg-[#a8f]";
      else if(letter === "o") color = "bg-[#ff8]";
      else if(letter === "p") color = "bg-[#f8f]";
      else if(letter === "q") color = "bg-[#f0f]";
      else if(letter === "r") color = "bg-[#0ff]";
      else if(letter === "s") color = "bg-[#ff0]";
      else if(letter === "t") color = "bg-[#0f0]";
      else if(letter === "u") color = "bg-[#00f]";
      else if(letter === "v") color = "bg-[#f00]";
      else if(letter === "w") color = "bg-[#f80]";
      else if(letter === "x") color = "bg-[#8f0]";
      else if(letter === "y") color = "bg-[#0f8]";
      else if(letter === "z") color = "bg-[#f08]";
      else if(letter === "@") color = "bg-[#ccc]";
      return color;

    }

export default function TopNav () {

    const pathname = usePathname(); // ✅ Hook at top level
    const [userType, setUserType] = useState("");
    const [username, setUserName] = useState("@user_");
    const [photo, setUserPhoto] = useState("");
    const [isVerified, setUserIsVerified] = useState(false);


  
    useEffect(() => {
        console.log(pathname);
        const firstName = getCookie('userfirstname');
        const lastName = getCookie('userlastname');
        const verified = getCookie('isVerified');

        console.log(verified)
        console.log(userProfile)

        if(verified && verified != "" && (verified != undefined) && verified != "0"){
          setUserIsVerified(true);
        }

        setUserName(firstName && lastName ? `${firstName}`:'@user_');

      if (pathname) {
        if (pathname.split("/").includes("shipper")) {
          setUserType("shipper");
        } else if (pathname.split("/").includes("carrier")) {
          setUserType("carrier");
        } else if (pathname.split("/").includes("broker")) {
          setUserType("broker");
        }
      }

      
      const userPhoto = getCookie('photo') || '';

      if (userPhoto && userPhoto !== "null" && userPhoto !== "undefined") {
        console.log("User photo found:", userPhoto);
        setUserPhoto(userPhoto);
      } else {
        setUserPhoto("");
      }

    }, [pathname]); // ✅ added pathname as dependency
  

   const userProfile  = userType ? userType == "shipper" ?
   '/users/shipper/profile': userType == "carrier" ?
    '/users/carrier/profile' : userType == "broker" ? '/users/broker/profile' : '' :
   '';



  return (
    <div className="bg-[#030c21] shadow-md px-6 py-4 flex justify-between items-center">
        <h2 className="text-xl font-semibold"></h2>
        <div className="flex items-center space-x-6">
            <FaBell className="text-white text-xl cursor-pointer" />
            <div className="flex items-center space-x-2">
              {/* userProfile FIX THIS LATER */}
               <Link href={"#"} className="flex items-center space-x-2">
                  {photo !== "" ? (
                    <img
                      src={photo}
                      alt="User Photo"
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <div className={`w-8 h-8 rounded-full font-bold border-3 ${colorLog(username.charAt(0).toLowerCase())} flex items-center justify-center text-white`}>
                      {username.charAt(0).toUpperCase()}
                    </div>   
                  )}
                  <span className="font-medium capitalize text-white">{username}</span>
               </Link>
               {  isVerified && (
                 <FaCheckCircle size={18} color="#fff" />
               )}
            </div>
        </div>
    </div>
  );
};


// this is on the forked repo.