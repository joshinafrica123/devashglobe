
"use client";

import { usePathname } from 'next/navigation';
import Link from "next/link";
import { useEffect, useState } from "react";
import {  
  FaBars, FaBell, FaBox, FaBoxOpen,  FaExchangeAlt,  
  FaSignOutAlt, FaTachometerAlt, FaTimes, FaTruck, FaUndo, 
  FaWallet
} from "react-icons/fa";
import {  logout } from '@/app/core/auth';
import { useRouter } from 'next/navigation';
import { getCookie, isCookieValid } from '@/app/datatype/frontEndCookiee';

export default function Sidebar() {
  const pathname = usePathname(); // ✅ Hook at top level
  const [isOpen, setIsOpen] = useState(false);
  const [userType, setUserType] = useState("");
  const router = useRouter();
  const [logtext,setLogText] = useState("Log Out");
  

  useEffect(() => {
    if (pathname) {
      if (pathname.split("/").includes("shipper")) {
        setUserType("shipper");
      } else if (pathname.split("/").includes("carrier")) {
        setUserType("carrier");
      } else if (pathname.split("/").includes("broker")) {
        setUserType("broker");
      }
    }

    // check if the user is logged in
    const token = getCookie('token');

    if (!token || token === '' || 
      token === 'undefined' || token === 'null'  || !isCookieValid('token')) {
      router.push('/login');
    }

  }, [pathname]); // ✅ added pathname as dependency


  const userNavList = {
    "shipper": [
      { href: "/users/shipper", icon: <FaTachometerAlt />, label: "Dashboard" },
      { href: "/users/shipper/merchant", icon: <FaBell />, label: "Merchant call" },
      { href: "/users/shipper/history", icon: <FaExchangeAlt />, label: "Transaction History" },
      // { href: "/users/shipper/payment", icon: <FaMoneyBill />, label: "Payments" },
      { href: "/users/shipper/load", icon: <FaBox />, label: "Loads" },
      { href: "/users/shipper/wallet", icon: <FaWallet />, label: "Wallet" },
      { href: "/users/shipper/refund", icon: <FaUndo />, label: "Refunds" },
      // { href: "/", icon: <FaSignOutAlt />, label: "Logout", extraClass: "mt-6" },
      // { href: "/", icon: <FaHome />, label: "Home", extraClass: "mt-6" },
    ],
    "carrier": [
      { href: "/users/carrier", icon: <FaTachometerAlt />, label: "Dashboard" },
      { href: "/users/carrier/merchant", icon: <FaBell />, label: "Merchant call" },
      { href: "/users/carrier/history", icon: <FaExchangeAlt />, label: "Transaction History" },
      { href: "/users/carrier/truck", icon: <FaTruck />, label: "Trucks" },
      { href: "/users/carrier/wallet", icon: <FaWallet />, label: "Wallet" },
      { href: "/users/carrier/refund", icon: <FaUndo />, label: "Refunds" },
      // { href: "/", icon: <FaSignOutAlt />, label: "Logout", extraClass: "mt-6" },
      // { href: "/", icon: <FaHome />, label: "Home", extraClass: "mt-6" },
    ],
    "broker": [
      { href: "/users/broker", icon: <FaTachometerAlt />, label: "Dashboard", extraClass: "mt-6" },
      { href: "/users/broker/load", icon: <FaBoxOpen />, label: "Loads" },
      { href: "/users/broker/truck", icon: <FaTruck />, label: "Trucks" },
      { href: "/users/broker/settings", icon: <FaTruck />, label: "Settings" },
      // { href: "/", icon: <FaHome />, label: "Home", extraClass: "mt-6" },
    ],
  };

  const userNav = userType ? userType == "shipper" ?
   userNavList.shipper : userType == "carrier" ?
    userNavList.carrier : userType == "broker" ? userNavList.broker : [] :
   [];


  const handleLogOut = async ()=>{
      setLogText("Logging out...")
    const isDoneLog = await logout("user");

    if(isDoneLog){
      setLogText("Logged out")
    router.push('/login');
    }
  }

   

  return (
    <div className="flex">
      {/* Mobile Toggle Button */}
      <button 
        className="lg:hidden px-2 text-[#fff] fixed top-5 left-4 "
        onClick={() => setIsOpen(true)}
      >
        <FaBars size={25} color='#fff' />
      </button>

      {/* Sidebar */}
      <div
        className={`fixed lg:relative h-screen text-[#030c21] flex flex-col p-5 w-64 transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 lg:block z-40`}
      >
        {/* Close Button for Mobile */}
        <button
          className="absolute top-4 right-4 lg:hidden"
          onClick={() => setIsOpen(false)}
        >
          <FaTimes size={24} />
        </button>
        
        <nav className="space-y-4">
          {userNav.map(({ href, icon, label }) => (
            <Link
              key={href}
              href={href}
              className={`flex items-center space-x-3 p-3 rounded-md hover:bg-[#D62D30]`}
              onClick={() => setIsOpen(false)} // ✅ Closes sidebar when a link is clicked
            >
              {icon} <span>{label}</span>
            </Link>
          ))}
          <button className={`flex items-center space-x-3 p-3 rounded-md w-full ${logtext == "Logging out..." ? 'bg-[#d62d3055]':'bg-[#D62D30]'} cursor-pointer `} onClick={() => handleLogOut()}><FaSignOutAlt className='mr-3'/>  {logtext}</button>
        </nav>
      </div>

      {/* Background Overlay when Sidebar is Open (Mobile Only) */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-[#ffffff] bg-opacity-50 lg:hidden z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
    </div>
  );
}
