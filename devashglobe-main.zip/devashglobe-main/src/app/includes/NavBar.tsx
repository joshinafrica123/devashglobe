"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {  X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { getCookie } from "../datatype/frontEndCookiee";
// import Image from "next/image";

export default function Navbar() {
  // const [mounted, setMounted] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [photo, setUserPhoto] = useState("");

  useEffect(() => {
    // setMounted(true);

    const handleClickOutside = (event: MouseEvent) => {
      if (
        mobileMenuOpen &&
        mobileMenuRef.current &&
        !mobileMenuRef.current.contains(event.target as Node)
      ) {
        setMobileMenuOpen(false);
      }
    };

    const userPhoto = getCookie("photo") || "";
    const token = getCookie("token") || "";

    if (token != "null" && token != "undefined" && token != "") {
      setIsLoggedIn(true);

      if (userPhoto) {
        setUserPhoto(userPhoto);
      } else {
        setUserPhoto("");
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [mobileMenuOpen]);

  const isLogut = [
    // { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Services", path: "/services" },
    { name: "Loadboard", path: "/loadboard" },
    { name: "Contact", path: "/contact" },
    // { name: "User", path: "/users/" },
    { name: "Login", path: "/login" },
    { name: "JoinUs", path: "/joinus" },
  ];

  const islogIn = [
    // { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Services", path: "/services" },
    { name: "Loadboard", path: "/loadboard" },
    { name: "Contact", path: "/contact" },
    // { name: "User", path: "/users/" },
    { name: "Profile", path: "/users" },
  ];

  const navItems = isLoggedIn ? islogIn : isLogut;

  return (
    <>
      {/* <div className={`transition-all duration-300 ${scrolled ? "py-2" : "py-4"}`}>
        <div className="container mx-auto flex justify-between items-center px-4 md:px-8">
          {/* Logo 
          <Link href="/" className="flex-shrink-0">
            <Image
              src="/assets/img/ASHlogo.png"
              alt="Logo"
              width={scrolled ? 120 : 160}
              height={scrolled ? 60 : 80}
              className="transition-all duration-300"
            />
          </Link>

          {/* Desktop Menu 
          <div className="hidden md:flex space-x-6 items-center">
            {navItems.map((item, index) =>
              item.name === "JoinUs" ? (
                <Link
                  key={index}
                  href={item.path}
                  className="px-4 py-2 bg-[#D62D30] rounded-md text-sm hover:bg-[#d62d30d5] transition"
                >
                  {item.name}
                </Link>
              ) : item.name === "Profile" ? (
                <Link key={index} href={item.path} className="block">
                  <img
                    src={photo}
                    alt="User Photo"
                    className="w-8 h-8 rounded-full"
                  />
                </Link>
              ) : (
                <Link
                  key={index}
                  href={item.path}
                  className="text-sm hover:text-[#D62D30] transition"
                >
                  {item.name}
                </Link>
              )
            )}
          </div>

          {/* Mobile Menu Button 
          <button
            className="md:hidden ml-4 text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div> */}

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            ref={mobileMenuRef}
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.3 }}
            className="fixed top-0 right-0 w-2/3 h-full bg-[#06163A] text-white shadow-lg p-6 z-50"
          >
            <button className="mb-6" onClick={() => setMobileMenuOpen(false)}>
              <X size={28} />
            </button>
            <nav className="space-y-4">
              {navItems.map((item, index) =>
                item.name === "JoinUs" ? (
                  <Link
                    key={index}
                    href={item.path}
                    className="block px-4 py-2 bg-[#D62D30] rounded-md text-lg hover:bg-[#d62d30d5] transition"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                ) : item.name === "Profile" ? (
                  <Link
                    key={index}
                    href={item.path}
                    className="block"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <img
                      src={photo}
                      alt="User Photo"
                      className="w-10 h-10 rounded-full"
                    />
                  </Link>
                ) : (
                  <Link
                    key={index}
                    href={item.path}
                    className="block text-lg hover:text-[#D62D30] transition"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                )
              )}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
