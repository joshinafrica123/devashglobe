"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  FiX,
  FiHome,
  FiTruck,
  FiDollarSign,
  FiSettings,
  FiChevronUp,
  FiChevronDown,
} from "react-icons/fi";
import {
  FaEnvelope,
  FaQuestionCircle,
  FaSignOutAlt,
  FaUsers,
} from "react-icons/fa";
import { usePathname, useRouter } from "next/navigation";
import { logout } from "@/app/core/auth";
import Image from "next/image";

export default function Sidebar({
  isOpen,
  toggleSidebar,
}: {
  isOpen: boolean;
  toggleSidebar: () => void;
}) {
  const sidebarRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const [logtext, setLogText] = useState("Log Out");
  const [loadboardOpen, setLoadboardOpen] = useState(false);
  const pathname = usePathname();

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        sidebarRef.current &&
        !sidebarRef.current.contains(event.target as Node) &&
        isOpen
      ) {
        toggleSidebar();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isOpen, toggleSidebar]);

  const handleLogOut = async () => {
    setLogText("Logging out...");
    console.log("log me out");
    const isDoneLog = await logout("admin");

    if (isDoneLog) {
      setLogText("Logged out");
      router.push("/admin");
    }
  };

  const isActive = (href: string) =>
    pathname === href ? "bg-[#01245A] text-white" : "text-[#404040]";

  return (
    <aside
      ref={sidebarRef}
      className={`fixed inset-y-0 left-0 z-50 bg-[#ECECEC] border-r-4 dark:bg-gray-950 w-64 p-4 transform ${
        isOpen ? "translate-x-0" : "-translate-x-64"
      } transition-transform lg:relative lg:translate-x-0 lg:z-auto`}
    >
      {/* Logo + Close Btn */}
      <div className="flex justify-between items-center pl-5 pr-5 mb-8">
        <Image
          src="/assets/img/ASHlogo.png"
          alt="Ashglobe Logo"
          width={170}
          height={170}
          className="rounded-full"
        />

        {/* Close (Mobile) */}
        <button className="lg:hidden text-[#404040]" onClick={toggleSidebar}>
          <FiX size={24} />
        </button>
      </div>

      {/* NAVIGATION */}
      <nav>
        <ul className="space-y-1 text-sm">
          {/* Dashboard */}
          <li>
            <Link
              href="../admin/dashboard"
              className={`flex items-center gap-3 p-3 rounded-md ${isActive(
                "../admin/dashboard"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <FiHome /> Dashboard
            </Link>
          </li>

          {/* User Management */}
          <li>
            <Link
              href="../admin/user"
              className={`flex items-center gap-3 p-3 rounded-md ${isActive(
                "../admin/user"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <FaUsers /> User Management
            </Link>
          </li>

          {/* Shipments */}
          <li>
            <Link
              href="../admin/shipments"
              className={`flex items-center gap-3 p-3 rounded-md ${isActive(
                "../admin/shipments"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <FiTruck /> Shipments Management
            </Link>
          </li>

          {/* Loadboard DROPDOWN */}
          <li>
            <button
              className={`flex justify-between w-full items-center p-3 rounded-md ${isActive(
                "../admin/transaction"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={() => setLoadboardOpen(!loadboardOpen)}
            >
              <span className="flex items-center gap-3">
                <FiDollarSign /> Loadboard
              </span>

              {loadboardOpen ? <FiChevronUp /> : <FiChevronDown />}
            </button>

            {/* DROPDOWN LINKS */}
            {loadboardOpen && (
              <ul className="pl-10 py-2 space-y-2 text-[#404040]">
                <li>
                  <Link
                    href="../admin/loadboard"
                    className={`block p-2 rounded-md ${isActive(
                      "../admin/loadboard"
                    )} hover:bg-gray-300`}
                    onClick={toggleSidebar}
                  >
                    All Loads
                  </Link>
                </li>

                <li>
                  <Link
                    href="../admin/offers/"
                    className="block p-2 rounded-md hover:bg-gray-300"
                    onClick={toggleSidebar}
                  >
                    Merchant Offers
                  </Link>
                </li>

                <li>
                  <Link
                    href="../admin/offers"
                    className="block p-2 rounded-md hover:bg-gray-300"
                    onClick={toggleSidebar}
                  >
                    Shippers Offers
                  </Link>
                </li>

                <li>
                  <Link
                    href="../admin/offers/"
                    className="block p-2 rounded-md hover:bg-gray-300"
                    onClick={toggleSidebar}
                  >
                    Carriers Offers
                  </Link>
                </li>

                <li>
                  <Link
                    href="../admin/offers"
                    className="block p-2 rounded-md hover:bg-gray-300"
                    onClick={toggleSidebar}
                  >
                    Matched Loads
                  </Link>
                </li>

                <li>
                  <Link
                    href="../admin/offers"
                    className="block p-2 rounded-md hover:bg-gray-300"
                    onClick={toggleSidebar}
                  >
                    Pending Bids
                  </Link>
                </li>
              </ul>
            )}
          </li>

          {/* Escrow */}
          <li>
            <Link
              href="../admin/escrow"
              className={`flex items-center gap-3 p-3 rounded-md ${isActive(
                "../admin/escrow"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <FaQuestionCircle /> Escrow Management
            </Link>
          </li>

          {/* Finance */}
          <li>
            <Link
              href="../admin/finance"
              className={`flex items-center gap-3 p-3 rounded-md ${isActive(
                "../admin/finance"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <FiDollarSign /> Finance
            </Link>
          </li>

          {/* Invoice */}
          <li>
            <Link
              href="../admin/invoice"
              className={`flex items-center gap-3 p-3 rounded-md ${isActive(
                "../admin/invoice"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <FaEnvelope /> Invoice
            </Link>
          </li>

          {/* HR BEFORE COMPLIANCE */}
          <hr className="my-2 border-gray-400 opacity-40" />

          {/* Compliance WITH BADGE */}
          <li>
            <Link
              href="../admin/contact"
              className={`flex items-center justify-between p-3 rounded-md ${isActive(
                "../admin/contact"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <span className="flex items-center gap-3">
                <FaEnvelope /> Compliance
              </span>

              <span className="text-xs bg-red-600 text-white px-2 py-1 rounded-full">
                4
              </span>
            </Link>
          </li>

          {/* Dispute Center WITH BADGE */}
          <li>
            <Link
              href="../admin/dispute"
              className={`flex items-center justify-between p-3 rounded-md ${isActive(
                "../admin/dispute"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <span className="flex items-center gap-3">
                <FaEnvelope /> Dispute Center
              </span>

              <span className="text-xs bg-blue-600 text-white px-2 py-1 rounded-full">
                2
              </span>
            </Link>
          </li>

          {/* HR BEFORE SETTINGS */}
          <hr className="my-2 border-gray-400 opacity-40" />

          {/* Settings */}
          <li>
            <Link
              href="../admin/settings"
              className={`flex items-center gap-3 p-3 rounded-md ${isActive(
                "../admin/settings"
              )} hover:bg-[#01245A] hover:text-white`}
              onClick={toggleSidebar}
            >
              <FiSettings /> Settings
            </Link>
          </li>

          {/* Logout */}
          <button
            className="flex items-center gap-3 p-3 w-full text-left rounded-md hover:bg-red-600 hover:text-white"
            onClick={handleLogOut}
          >
            <FaSignOutAlt /> {logtext}
          </button>
        </ul>
      </nav>
    </aside>
  );
}
