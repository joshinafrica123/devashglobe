"use client";

import { FiBell, FiChevronDown, FiCreditCard, FiMenu } from "react-icons/fi";
import React, { useState, useRef, useEffect } from "react";
// import { FaUser, FaCog, FaHome, FaSignOutAlt } from 'react-icons/fa';
// import Link from "next/link";
import Image from "next/image";
import { FileSearch } from "lucide-react";

export default function Navbar({
  toggleSidebar,
}: {
  toggleSidebar: () => void;
}) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [languageOpen, setLanguageOpen] = useState(false);
  // const languageRef = useRef<HTMLDivElement>(null); 

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header className="bg-[#ECECEC99] border-2 border-[#ECECEC99] shadow-[#00000005] dark:bg-gray-900 p-3 flex items-center justify-between gap-4">
      {/* Sidebar Toggle (Mobile) */}
      <button className="lg:hidden" onClick={toggleSidebar}>
        <FiMenu size={24} className="text-gray-800 dark:text-white" />
      </button>

      {/* LEFT: Search Bar */}
      <div className="flex-1 hidden md:flex">
        <div className="relative w-full max-w-md">
          <FileSearch
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500"
            size={18}
          />
          <input
            type="text"
            placeholder="Search by shipping ID..."
            className="w-full pl-10 pr-4 py-2 rounded-md border border-gray-300 bg-white dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-[#01245A] outline-none"
          />
        </div>
      </div>

      {/* RIGHT SIDE ITEMS */}
      <div className="flex items-center gap-3 lg:gap-5">
        {/* Language Dropdown */}
        <div className="relative">
          <button
            onClick={() => setLanguageOpen(!languageOpen)}
            className="flex items-center gap-2  dark:bg-gray-800  border-gray-300 dark:border-gray-700 px-3 py-1.5"
          >
            <Image
              src="/assets/img/flags/us.png"
              width={25}
              height={25}
              alt="flag"
            />
            <span className="text-sm font-semibold text-gray-700 dark:text-gray-200">
              English (US)
            </span>
            <FiChevronDown
              size={16}
              className="text-gray-600 dark:text-gray-300"
            />
          </button>

          {languageOpen && (
            <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-gray-800 rounded-lg shadow-lg z-50 border border-gray-200 dark:border-gray-700">
              <button className="flex w-full px-3 py-2 items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700 text-sm">
                <Image
                  src="/assets/img/flags/us.png"
                  width={20}
                  height={20}
                  alt="US"
                />{" "}
                English (US)
              </button>
              <button className="flex w-full px-3 py-2 items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700 text-sm">
                <Image
                  src="/assets/img/flags/de.png"
                  width={20}
                  height={20}
                  alt="DE"
                />{" "}
                French (Fr)
              </button>
              <button className="flex w-full px-3 py-2 items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700 text-sm">
                <Image
                  src="/assets/img/flags/gh.png"
                  width={20}
                  height={20}
                  alt="GH"
                />{" "}
                Germany (Deu)
              </button>
            </div>
          )}
        </div>

        {/* Notifications */}
        <div className="relative bg-[#D62D2D0D] dark:bg-gray-800 border border-[#D9D9D94D] dark:border-gray-600 px-3 py-2 rounded-md">
          <FiBell size={20} className="text-gray-700 dark:text-gray-200" />
          <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs rounded-full px-1.5">
            15
          </span>
        </div>

        {/* Wallet Box */}
        <div className="flex items-center gap-2 bg-[#F2ECEC] dark:bg-gray-800 border border-[#D9D9D94D] dark:border-gray-700 px-3 py-2 rounded-md">
          <FiCreditCard
            size={20}
            className="text-gray-700 dark:text-gray-200"
          />
          <div className="text-left leading-tight flex row gap-1">
            <p className="text-sm text-[#D62D2DD6] dark:text-white font-semibold">
              $520.00
            </p>
            <p className="text-sm text-[#49AE5F] font-bold dark:text-gray-300">
              : 12.5%
            </p>
          </div>
        </div>

        {/* PROFILE DROPDOWN (Your Original Code) */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-3"
          >
            <Image
              src="/assets/img/users/2.jpg"
              alt="User Avatar"
              width={20}
              height={20}
              className="w-9 h-9 rounded-full object-cover border-2 border-[#D62D30]"
            />
            <div className="text-left hidden md:block">
              <p className="text-sm font-semibold text-gray-800 dark:text-white mb-0">
                Ash  Johansson
              </p>
              <p className="text-xs text-[#D80027] dark:text-gray-300 mb-0">
                supadmin@xc.com
              </p>
            </div>
          </button>

          {dropdownOpen && (
            <ul className="absolute right-0 mt-2 w-56 bg-white dark:bg-gray-800 shadow-lg rounded-lg z-50">
              {/* your dropdown items */}
            </ul>
          )}
        </div>
      </div>
    </header>
  );
}
