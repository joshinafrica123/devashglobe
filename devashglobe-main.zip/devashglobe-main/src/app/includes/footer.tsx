import Image from "next/image";

export default function Footer() {
  
  return (
    <footer className="bg-cover bg-center text-[#06163A] py-12 bg-[#eceaea8e]" >
      {/* Newsletter Section */}
      {/* <div className="bg-[#89a8f070] py-6 px-4 md:px-12">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
          <h2 className="text-xl md:text-2xl font-semibold mb-4 md:mb-0">Sign up for alerts, news & insights from Ashglobe.</h2>
          <form className="flex w-full md:w-auto">
            <input type="email" placeholder="Email" className="p-2 rounded-l-md border-1 border-[#fff] text-black" />
            <button type="submit" className="bg-[#D62D30] px-4 py-2 rounded-r-md">Subscribe Now</button>
          </form>
        </div>
      </div> */}

      {/* Footer Widgets Address */}
      <div className="container mx-auto px-4 md:px-12 grid md:grid-cols-4 gap-8 py-12">
        {/* Logo & Address */}
        <div>
          <Image src="/assets/img/ASHlogo.png" alt="Logo" width={150} height={50} />

        </div>

        {/* Services */}
        <div>
          <div className="mt-4 space-y-2 text-sm">
            <h3>Address: United Kingdom
            21st Floor, City Tower, Manchester M1 4BT, United Kingdom</h3>
            <p>Company Registration Number
            (England Headquarters): 14519117</p>
            <p>Website: ashglobe.uk.com</p>
            <p>Email: info@ashglobe.uk.com</p>
            <p>Phone: +44 7719 262478</p>
          </div>
        </div>

        {/* Industry Sectors */}
        <div>
          <div className="mt-4 space-y-2 text-sm">
              <h3>Address: United State
              5 West Mendenhall Street, Bozeman, MT, 59715</h3>
              <p>Company Registration Number: </p>
              <p>Website: ashglobe.us.com</p>
              <p>Email: info@ashglobe.uk.com</p>
              <p>2023-001323847</p>
            </div>
        </div>

        
        {/* Quick Links */}
        <div>
            <div className="mt-4 space-y-2 text-sm">
                <h3>Address:Ghana
                  31 Kasoa New Market Rd GA105
                  Central Region Ghana</h3>
                <p>Company Registration Number
                (Ghana): CS149701023</p>

              </div>
        </div>
      </div>

      {/* Footer Widgets */}
      <div className="container mx-auto px-4 md:px-12 grid md:grid-cols-4 gap-8 py-12">
    
        {/* services */}
        <div>   
          <h3 className="text-lg font-semibold mb-4">Our Services</h3>
          <ul className="space-y-2 text-sm">
            <li><a href="/services" className="hover:underline"> Freight Shipping</a></li>
            <li><a href="/services" className="hover:underline">Logistics Management</a></li>
            <li><a href="/services" className="hover:underline">Warehousing</a></li>
            <li><a href="/services" className="hover:underline">Express Delivery</a></li>
            <li><a href="/services" className="hover:underline">Tracking solution</a></li>
          </ul>
        </div>

        {/* Industry Sectors */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Industry Sectors</h3>
          <ul className="space-y-2 text-sm">
            <li><a href="/services" className="hover:underline">Electronics Industry</a></li>
            <li><a href="/services" className="hover:underline">Industrial & Manufacturing</a></li>
            <li><a href="/services" className="hover:underline">Semicon & Solar</a></li>
            <li><a href="/services" className="hover:underline">Oil & Gas Cargo</a></li>
            <li><a href="/services" className="hover:underline">Energy & Chemicals</a></li>
          </ul>
        </div>

        
        {/* Quick Links */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
          <ul className="space-y-2 text-sm">
            <li><a href="/howitworks" className="hover:underline">How it Works</a></li>
            <li><a href="/contact" className="hover:underline">Help Link</a></li>
            <li><a href="/terms" className="hover:underline">Terms & Conditions</a></li>
            <li><a href="/contact" className="hover:underline">Contact Us</a></li>
            <li><a href="/privacy" className="hover:underline">Privacy Policy</a></li>
          </ul>
        </div>
      </div>

      {/* Copyright Section */}
      <div className="bg-[#e6ebf670] text-center py-4">
        <p className="text-sm">&copy; 2025 AshLogistics. All Rights Reserved.</p>
      </div>
    </footer>
  );
}
