"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { FaPhoneAlt, FaEnvelope } from "react-icons/fa";
import { Menu, X } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { getCookie, postWhatCookie } from "../datatype/frontEndCookiee";

const isLogut = [
  // { name: "Home", path: "/" },
  { name: "About", path: "/about" },
  { name: "Shipper", path: "/services" },
  { name: "Carrier", path: "/services" },
  { name: "Features", path: "/services" },
  { name: "Contact", path: "/contact" },
  { name: "Pricing", path: "/pricing" },
  // { name: "User", path: "/users/" },
  { name: "Login", path: "/login" },
  { name: "JoinUs", path: "/joinus" },
];

const islogIn = [
  // { name: "Home", path: "/" },
  { name: "About", path: "/about" },
  { name: "Shipper", path: "/services" },
  { name: "Carrier", path: "/services" },
  { name: "Features", path: "/services" },
  { name: "Contact", path: "/contact" },
  { name: "Pricing", path: "/pricing" },
  // { name: "User", path: "/users/" },
  { name: "Profile", path: "/users" },
];

export default function Header(isHome: { isHome: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const mobileMenuRef = useRef(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [featuresOpen, setFeaturesOpen] = useState(false);
  const [shipperOpen, setShipperOpen] = useState(false);
  const [carrierOpen, setCarrierOpen] = useState(false);
  const [photo, setUserPhoto] = useState("");
  const shipperRef = useRef<HTMLLIElement>(null);
  const carrierRef = useRef<HTMLLIElement>(null);
  const featuresRef = useRef<HTMLLIElement>(null);

  const navItems = isLoggedIn ? islogIn : isLogut;

  useEffect(() => {
    const userPhoto = getCookie("photo") || "";
    const token = getCookie("token") || "";

    if (token != "null" && token != "undefined" && token != "") {
      setIsLoggedIn(true);

      if (userPhoto) {
        setUserPhoto(userPhoto);
      } else {
        setUserPhoto("");
      }
    }
    console.log(isHome.isHome);
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        shipperRef.current &&
        !shipperRef.current.contains(e.target as Node)
      ) {
        setShipperOpen(false);
      }
      if (
        carrierRef.current &&
        !carrierRef.current.contains(e.target as Node)
      ) {
        setCarrierOpen(false);
      }
      if (
        featuresRef.current &&
        !featuresRef.current.contains(e.target as Node)
      ) {
        setFeaturesOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleMobile = (i: boolean) => {
    setMobileMenuOpen(i);
    setFeaturesOpen(false);
    setShipperOpen(false);
    setCarrierOpen(false);
  };

  const handleSwitches = (i: boolean, type: string) => {
    if (type == "features") {
      setFeaturesOpen(i);
      setCarrierOpen(false);
      setShipperOpen(false);
    } else if (type == "shippers") {
      setShipperOpen(i);
      setCarrierOpen(false);
      setFeaturesOpen(false);
    } else if (type == "carriers") {
      setCarrierOpen(i);
      setShipperOpen(false);
      setFeaturesOpen(false);
    }
  };

  // For mobile, handle independently
  const toggleDropdown = (type: string) => {
    if (type === "shippers") {
      setShipperOpen((prev) => !prev);
    } else if (type === "carriers") {
      setCarrierOpen((prev) => !prev);
    } else if (type === "features") {
      setFeaturesOpen((prev) => !prev);
    }
  };

  const handlePostWhatCookie = (text:string) => {
    postWhatCookie(text);
  }

  return (
    <header
      className={`fixed w-full top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-gradient-to-r from-[#6C7990] to-[#06163A] shadow-md"
          : `${
              isHome.isHome
                ? "bg-transparent"
                : "bg-gradient-to-r from-[#6C7990] to-[#06163A] shadow-md"
            }`
      }`}
    >
      {/* Top contact bar (desktop only) */}
      <nav
        className={`hidden md:flex w-full text-white text-xs px-6 py-2 ${
          scrolled
            ? "bg-opacity-90"
            : `${isHome.isHome ? "bg-transparent" : "bg-opacity-90"}`
        }`}
      >
        <div className="max-w-7xl w-full mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <FaPhoneAlt size={14} /> +44 7719 262478
            </div>
            <div className="flex items-center gap-2">
              <FaEnvelope size={14} /> info@ashglobe.uk.com
            </div>
          </div>
        </div>
      </nav>

      {/* Main Nav */}
      <div
        className={`transition-all duration-300 ${scrolled ? "py-2" : "py-4"}`}
      >
        <div className="container mx-auto flex justify-between items-center px-4 md:px-8">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0">
            <Image
              src="/assets/img/ASHlogo.png"
              alt="Logo"
              width={scrolled ? 120 : 160}
              height={scrolled ? 60 : 80}
              className="transition-all duration-300"
            />
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-6 items-center">
            {navItems.map((item, index) => {
              if (item.name === "JoinUs") {
                return (
                  <li key={index} className="block">
                    <Link
                      href={item.path}
                      className="group px-4 py-2 bg-[#D62D30] rounded-md text-sm text-[#fff] hover:bg-[#d62d30d5] transition"
                    >
                      {item.name}
                    </Link>
                  </li>
                );
              } else if (item.name === "Profile") {
                return (
                  <li key={index} className="block">
                    <Link href={item.path} className="block">
                      <img
                        src={photo}
                        alt="User"
                        className="w-8 h-8 rounded-full"
                      />
                    </Link>
                  </li>
                );
              } else if (item.name === "Shipper") {
                return (
                  <li
                    key={index}
                    ref={shipperRef}
                    className="relative block cursor-pointer"
                  >
                    <button
                      className="text-sm text-white hover:text-[#D62D30] flex items-center gap-1 cursor-pointer"
                      onClick={() => handleSwitches(!shipperOpen, "shippers")}
                    >
                      {item.name} ▾
                    </button>
                    {shipperOpen && (
                      <ul className="absolute left-0 mt-2 w-48 bg-white text-gray-800 rounded-lg shadow-lg">
                        <li onClick={() => handlePostWhatCookie("post load clicked")}>
                          <Link
                            href="/users"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            Post Load
                          </Link>
                        </li>
                        <li>
                          <Link
                            href="/loadboard"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            Search for Truck
                          </Link>
                        </li>
                        <li>
                          <Link
                            href="/loadboard"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            Spot bidding
                          </Link>
                        </li>
                      </ul>
                    )}
                  </li>
                );
              } else if (item.name === "Carrier") {
                return (
                  <li
                    key={index}
                    ref={carrierRef}
                    className="relative block cursor-pointer"
                  >
                    <button
                      className="text-sm text-white hover:text-[#D62D30] flex items-center gap-1 cursor-pointer"
                      onClick={() => handleSwitches(!carrierOpen, "carriers")}
                    >
                      {item.name} ▾
                    </button>
                    {/* Submenu */}
                    {carrierOpen && (
                      <ul className="absolute left-0 mt-2 w-48 bg-white text-gray-800 rounded-lg shadow-lg">
                        <li onClick={() => handlePostWhatCookie("post truck clicked")}>
                          <Link
                            href="/users"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            Post Truck
                          </Link>
                        </li>
                        <li>
                          <Link
                            href="/loadboard"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            Search for Load
                          </Link>
                        </li>
                        {/* <li>
                        <Link
                          href="/features/security"
                          className="block px-4 py-2 hover:bg-gray-100"
                        >
                          Security
                        </Link>
                      </li> */}
                      </ul>
                    )}
                  </li>
                );
              } else if (item.name === "Features") {
                return (
                  <li
                    key={index}
                    ref={featuresRef}
                    className="relative block cursor-pointer"
                  >
                    <button
                      className="text-sm text-white hover:text-[#D62D30] flex items-center gap-1 cursor-pointer"
                      onClick={() => handleSwitches(!featuresOpen, "features")}
                    >
                      {item.name} ▾
                    </button>
                    {/* Submenu */}
                    {featuresOpen && (
                      <ul className="absolute left-0 mt-2 w-48 bg-white text-gray-800 rounded-lg shadow-lg">
                        <li>
                          <Link
                            href="/loadboard"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            Loadboard
                          </Link>
                        </li>
                        <li>
                          <Link
                            href="/"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            On-chain Management
                          </Link>
                        </li>
                        <li>
                          <Link
                            href="/tracking"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            Tracking
                          </Link>
                        </li>
                        <li>
                          <Link
                            href="/"
                            className="block px-4 py-2 hover:bg-gray-100"
                          >
                            Invoicing
                          </Link>
                        </li>
                      </ul>
                    )}
                  </li>
                );
              } else {
                return (
                  <li key={index} className="block">
                    <Link
                      href={item.path}
                      className="text-sm text-white hover:text-[#D62D30] transition-colors duration-200"
                    >
                      {item.name}
                    </Link>
                  </li>
                );
              }
            })}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden ml-4 text-white"
            onClick={() => handleMobile(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>
      {/* another commit */}
      {/* another commit */}

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            ref={mobileMenuRef}
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.3 }}
            className="fixed top-0 right-0  w-full h-full bg-[#06163af7] text-white shadow-lg p-6  z-50"
          >
            <button
              className="mb-6 p-2 absolute right-0"
              onClick={() => handleMobile(false)}
            >
              <X size={28} />
            </button>
            <nav>
              <ul className="space-y-4">
                {navItems.map((item, index) => {
                  if (item.name === "JoinUs") {
                    return (
                      <li key={index} className="block">
                        <Link
                          href={item.path}
                          className="block px-4 py-2 bg-[#D62D30] rounded-md text-lg text-[#fff] hover:bg-[#d62d30d5] transition"
                          onClick={() => handleMobile(false)}
                        >
                          {item.name}
                        </Link>
                      </li>
                    );
                  } else if (item.name === "Profile") {
                    return (
                      <li key={index} className="block">
                        <Link
                          href={item.path}
                          className="block"
                          onClick={() => handleMobile(false)}
                        >
                          <img
                            src={photo}
                            alt="User"
                            className="w-10 h-10 rounded-full"
                          />
                        </Link>
                      </li>
                    );
                  } else if (item.name === "Shipper") {
                    return (
                      <li key={index} ref={shipperRef} className="block">
                        <button
                          className="w-full flex justify-between items-center text-lg text-white hover:text-[#D62D30] transition"
                          onClick={() => toggleDropdown("shippers")}
                        >
                          {item.name} {shipperOpen ? "▴" : "▾"}
                        </button>
                        {shipperOpen && (
                          <ul className="pl-4 mt-2 space-y-2 text-gray-200">
                            <li className="block">
                              <Link
                                href="/users"
                                onClick={() => handleMobile(false)}
                              >
                                Post Load
                              </Link>
                            </li>
                            <li className="block">
                              <Link
                                href="/loadboard"
                                onClick={() => handleMobile(false)}
                              >
                                Search for truck
                              </Link>
                            </li>
                            <li className="block">
                              <Link
                                href="/loadboard"
                                onClick={() => handleMobile(false)}
                              >
                                Spot bidding
                              </Link>
                            </li>
                          </ul>
                        )}
                      </li>
                    );
                  } else if (item.name === "Carrier") {
                    return (
                      <li
                        key={index}
                        className="block cursor-pointer"
                        ref={carrierRef}
                      >
                        <button
                          className="w-full flex justify-between items-center text-lg text-white hover:text-[#D62D30] transition"
                          onClick={() => toggleDropdown("carriers")}
                        >
                          {item.name} {carrierOpen ? "▴" : "▾"}
                        </button>
                        {carrierOpen && (
                          <ul className="pl-4 mt-2 space-y-2 text-gray-200">
                            <li className="block">
                              <Link
                                href="/users"
                                onClick={() => handleMobile(false)}
                              >
                                Post tuck
                              </Link>
                            </li>
                            <li className="block">
                              <Link
                                href="/loadboard"
                                onClick={() => handleMobile(false)}
                              >
                                Search for load
                              </Link>
                            </li>
                          </ul>
                        )}
                      </li>
                    );
                  } else if (item.name === "Features") {
                    return (
                      <li key={index} className="block" ref={featuresRef}>
                        <button
                          className="w-full flex justify-between items-center text-lg text-white hover:text-[#D62D30] transition"
                          onClick={() => toggleDropdown("features")}
                        >
                          {item.name} {featuresOpen ? "▴" : "▾"}
                        </button>
                        {featuresOpen && (
                          <ul className="pl-4 mt-2 space-y-2 text-gray-200">
                            <li className="block">
                              <Link
                                href="/loadboard"
                                onClick={() => handleMobile(false)}
                              >
                                Loadbaord
                              </Link>
                            </li>
                            <li className="block">
                              <Link
                                href="/"
                                onClick={() => handleMobile(false)}
                              >
                                On-chain Management
                              </Link>
                            </li>
                            <li className="block">
                              <Link
                                href="/tracking"
                                onClick={() => handleMobile(false)}
                              >
                                Tracking
                              </Link>
                            </li>
                            <li className="block">
                              <Link
                                href="/"
                                onClick={() => handleMobile(false)}
                              >
                                Invoicing
                              </Link>
                            </li>
                          </ul>
                        )}
                      </li>
                    );
                  } else {
                    return (
                      <li key={index} className="block">
                        <Link
                          href={item.path}
                          className="block text-lg text-white hover:text-[#D62D30] transition"
                          onClick={() => handleMobile(false)}
                        >
                          {item.name}
                        </Link>
                      </li>
                    );
                  }
                })}
              </ul>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
