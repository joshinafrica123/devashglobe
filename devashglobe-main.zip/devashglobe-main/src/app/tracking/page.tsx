"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

interface result {
  code: string;
  carrier: string;
  status: string;
  date: string;
  origin: string;
  destination: string;
  service: string;
  etd: string;
  eta: string;
  weight: string;
}

export default function TrackingPage() {
  const [trackingId, setTrackingId] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<result | null>();

  useEffect(() => {
    // check if there's a trackingId in the URL
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");
    if (id) {
      setTrackingId(id);

      setLoading(true);
      setResult(null);
      // optionally, trigger tracking automatically
      // handleTrack(new Event('submit') as unknown as React.FormEvent);
      // Simulate API call (replace with real backend)
      setTimeout(() => {
        setResult({
          code: id,
          carrier: "DHL Express",
          status: "Delivered",
          date: "Friday, 29 August 2025 at 11:44 am (UTC)",
          origin: "East Windsor - New Jersey - USA",
          destination: "Accra - Ghana",
          service: "Express Worldwide",
          etd: "2025-08-25",
          eta: "2025-08-29",
          weight: "5.2 kg",
        });
        setLoading(false);
      }, 1500);
    }
  }, []);

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackingId) return;

    setLoading(true);
    setResult(null);

    // Simulate API call (replace with real backend)
    setTimeout(() => {
      setResult({
        code: trackingId,
        carrier: "DHL Express",
        status: "Delivered",
        date: "Friday, 29 August 2025 at 11:44 am (UTC)",
        origin: "East Windsor - New Jersey - USA",
        destination: "Accra - Ghana",
        service: "Express Worldwide",
        etd: "2025-08-25",
        eta: "2025-08-29",
        weight: "5.2 kg",
      });
      setLoading(false);
    }, 1500);
  };

  return (
    <div>
      <section
        className="relative  py-15 bg-transparent"
        // style={{ backgroundImage: `url(/assets/img/banner/ash-slider.jpg)` }}
      >
        <span className="absolute inset-0 bg-transparent] opacity-50"></span>
        <div className="container mx-auto relative z-10 text-center"></div>
        <div className="absolute bottom-18.5  left-0 w-50 h-50"></div>
      </section>

      <div className="min-h-screen bg-gray-50 py-12 px-6">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <h1 className="text-3xl font-bold text-center mb-8">
            Track Your Shipment
          </h1>

          {/* Input Form */}
          <form
            onSubmit={handleTrack}
            className="flex items-center gap-3 bg-white shadow-lg rounded-2xl p-4"
          >
            <input
              type="text"
              placeholder="Enter your tracking number"
              value={trackingId}
              onChange={(e) => setTrackingId(e.target.value)}
              className="flex-1 p-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 outline-none"
            />
            <button
              type="submit"
              className="p-3 bg-[#D62D30] text-white rounded-xl "
            >
              Track
            </button>
          </form>

          {/* Loader */}
          {loading && (
            <div className="mt-6 animate-pulse">
              <div className="h-20 bg-gray-200 rounded-xl"></div>
            </div>
          )}

          {/* Results */}
          {result && (
            <div className="mt-8 shadow-xl rounded-2xl">
              <div className="p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold">
                    Tracking Code: {result.code}
                  </h2>
                  <span className="px-3 py-1 text-sm rounded-full bg-green-100 text-green-700">
                    {result.status}
                  </span>
                </div>

                <p className="text-gray-600">
                  Carrier: <span className="font-medium">{result.carrier}</span>
                </p>
                <p className="text-gray-600">{result.date}</p>

                {/* Status Bar */}
                <div className="flex items-center gap-2 mt-4">
                  <div className="flex-1 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1 h-2 bg-green-500 rounded-full"></div>
                </div>
                <div className="flex justify-between text-sm text-gray-500 mt-2">
                  <span>Origin</span>
                  <span>In Transit</span>
                  <span>Delivered</span>
                </div>

                {/* Shipment Info */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
                  <div>
                    <p className="font-semibold">Origin</p>
                    <p className="text-gray-600">{result.origin}</p>
                  </div>
                  <div>
                    <p className="font-semibold">Destination</p>
                    <p className="text-gray-600">{result.destination}</p>
                  </div>
                  <div>
                    <p className="font-semibold">Service</p>
                    <p className="text-gray-600">{result.service}</p>
                  </div>
                  <div>
                    <p className="font-semibold">Weight</p>
                    <p className="text-gray-600">{result.weight}</p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 mt-6">
                  <Link
                    href="/users"
                    className="m-4 p-2 rounded-xl bg-[#06163A] text-sm text-white text-center"
                  >
                    Get Proof of Delivery
                  </Link>
                  <Link
                    href="/users"
                    className="m-4 p-2 rounded-xl bg-[#06163A] text-sm text-white text-center"
                  >
                    KYC Upload
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
