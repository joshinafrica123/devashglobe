"use client";

import { Check } from "lucide-react";
import Link from "next/link";

const plans = [
  {
    name: "Starter",
    price: "$29",
    description: "For small businesses starting their logistics journey.",
    features: [
      "Basic load board access",
      "Post up to 10 loads/month",
      "Track shipments in real-time",
      "Email support",
    ],
    button: "Get Started",
    highlighted: false,
  },
  {
    name: "Pro",
    price: "$99",
    description: "For growing companies needing advanced logistics tools.",
    features: [
      "Unlimited load posting",
      "Carrier matching & bidding",
      "Route optimization",
      "Priority support",
      "Analytics dashboard",
    ],
    button: "Start Free Trial",
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "Tailored solutions for large-scale logistics operations.",
    features: [
      "Dedicated account manager",
      "API integration",
      "Advanced analytics",
      "Custom SLA",
      "24/7 support",
    ],
    button: "Contact Sales",
    highlighted: false,
  },
];

export default function WorldExchangeRates() {
  return (
    <div>
      <section
        className="relative  py-15 bg-transparent"
        // style={{ backgroundImage: `url(/assets/img/banner/ash-slider.jpg)` }}
      >
        <span className="absolute inset-0 bg-transparent] opacity-50"></span>
        <div className="container mx-auto relative z-10 text-center"></div>
        <div className="absolute bottom-18.5  left-0 w-50 h-50"></div>
      </section>

      <div className="bg-gray-50 dark:bg-gray-900 min-h-screen">
        {/* Hero Section */}
        <section className="text-center max-w-3xl mx-auto px-6 py-20">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">
            Simple, Transparent Pricing
          </h1>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Choose the plan that best fits your logistics needs.
          </p>
        </section>

        {/* Pricing Plans */}
        <section className="max-w-6xl mx-auto px-6 pb-24 grid md:grid-cols-3 gap-8">
          {plans.map((plan, idx) => (
            <div
              key={idx}
              className={`rounded-2xl shadow-lg p-8 flex flex-col border ${
                plan.highlighted
                  ? "bg-white dark:bg-gray-800 border-[#D62D30] scale-105"
                  : "bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
              }`}
            >
              <h3 className="text-2xl font-semibold text-gray-900 dark:text-white">
                {plan.name}
              </h3>
              <p className="mt-2 text-gray-600 dark:text-gray-400">
                {plan.description}
              </p>
              <div className="mt-6 text-4xl font-bold text-[#D62D30]">
                {plan.price}
              </div>

              <ul className="mt-6 space-y-3 flex-1">
                {plan.features.map((feature, i) => (
                  <li
                    key={i}
                    className="flex items-center gap-2 text-gray-700 dark:text-gray-300"
                  >
                    <Check className="w-5 h-5 text-green-500" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                className={`mt-8 py-3 px-6 rounded-xl font-medium transition ${
                  plan.highlighted
                    ? "bg-[#D62D30] text-white hover:bg-[#b92124]"
                    : "bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-600"
                }`}
              >
                {plan.button}
              </button>
            </div>
          ))}
        </section>

        {/* CTA Section */}
        <section className="bg-[#D62D30] py-16 text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold">
            Ready to optimize your logistics?
          </h2>
          <p className="mt-3 mb-5 text-lg">
            Join thousands of companies using our platform.
          </p>
          <Link href={"/joinus"} className="mt-12 bg-white text-[#D62D30] font-semibold px-8 py-3 rounded-xl hover:bg-gray-100 transition ">
            Get Started Today
          </Link>
        </section>
      </div>
    </div>
  );
}
