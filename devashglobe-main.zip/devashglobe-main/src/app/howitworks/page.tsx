"use client";

import { Truck, Package, Search, CheckCircle, Users } from "lucide-react";
import { useRouter } from "next/navigation";

export default function HowItWorks() {
    const router = useRouter();
  const steps = [
    {
      id: 1,
      title: "Post a Shipment",
      description:
        "Shippers create a shipment request by providing pickup location, drop-off destination, type of goods, and timeline.",
      icon: Package,
    },
    {
      id: 2,
      title: "Match with a Carrier",
      description:
        "Our system instantly connects shipments with trusted carriers who are available and qualified.",
      icon: Search,
    },
    {
      id: 3,
      title: "Carrier Picks Up",
      description:
        "The assigned carrier arrives at the pickup location, collects the goods securely, and begins transport.",
      icon: Truck,
    },
    {
      id: 4,
      title: "Real-Time Tracking",
      description:
        "Shippers and merchants can track the shipment in real-time and get delivery updates.",
      icon: Users,
    },
    {
      id: 5,
      title: "Delivery & Confirmation",
      description:
        "The carrier delivers the shipment to its destination. Shipper and merchant confirm completion.",
      icon: CheckCircle,
    },
  ];

  return (
    <div className="bg-gray-50 text-gray-800 px-6 md:px-16 lg:px-32 py-16">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-[#06163A] mb-4">
            How It Works
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our logistics platform creates a smooth process from{" "}
            <span className="font-medium">Shippers</span> to{" "}
            <span className="font-medium">Carriers</span> to{" "}
            <span className="font-medium">Merchants</span> — efficient,
            transparent, and reliable.
          </p>
        </div>

        {/* Vertical Timeline */}
        <div className="relative border-l-4 border-[#D62D30] pl-8 space-y-12">
          {steps.map((step) => (
            <div key={step.id} className="relative">
              {/* Icon marker */}
              <div className="absolute -left-11 flex items-center justify-center w-10 h-10 rounded-full bg-white border-4 border-[#D62D30] shadow-md">
                <step.icon className="w-5 h-5 text-[#D62D30]" />
              </div>

              {/* Step content */}
              <h3 className="text-xl font-semibold text-[#06163A] mb-2">
                {step.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>

        {/* Shipper/Carrier/Merchant Info */}
        <div className="mt-20 space-y-12">
          <div>
            <h2 className="text-2xl font-bold text-[#06163A] mb-4">For Shippers</h2>
            <p className="text-gray-600 leading-relaxed">
              Create shipment requests quickly, compare carriers, and track every
              step of your delivery. Our platform ensures reliability and
              transparency for all your shipping needs.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-[#06163A] mb-4">For Carriers</h2>
            <p className="text-gray-600 leading-relaxed">
              Find available loads, optimize your routes, and keep your trucks
              moving. Carriers can maximize efficiency and revenue by staying
              connected to new opportunities.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-[#06163A] mb-4">For Merchants</h2>
            <p className="text-gray-600 leading-relaxed">
              Ensure timely deliveries to your customers. Merchants can monitor
              shipments, confirm arrivals, and provide reliable service to end
              buyers.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-[#06163A] mb-4">
            Start Your Journey With Us
          </h2>
          <p className="text-gray-600 mb-6">
            Join thousands of shippers, carriers, and merchants who trust our
            platform every day.
          </p>
          <button onClick={()=>router.push("/joinus")} className="px-6 py-3 bg-[#D62D30] text-white rounded-xl shadow-md cursor-pointer hover:bg-[#b72224] transition">
            Get Started
          </button>
        </div>
      </div>
    </div>
  );
}
