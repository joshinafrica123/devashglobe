import AboutComponent from "@/components/aboutComponent";
import WhyUsComponent from "@/components/whyChooseUs";
import CertComponent from "@/components/certComponent";
import BannerHeroComponent from "@/components/bannerHeroComponent";
import AchievementComponent from "@/components/achievementsComponent";
import Header from "./includes/header";
import Footer from "./includes/footer";
import Link from "next/link";
import FaqComponent from "@/components/faqComponent";
import ShortLinks from "@/components/rateandfuel";
import HomeLoadTrckSearch from "@/components/loadtruckhomesearchComponent";
// import Image from "next/image";

export default function Home() {
  return (
    <>
      <Header isHome={true} />

      <div className="bg-white text-gray-900 dark:bg-gray-900 dark:text-white">
        {/* Hero Section */}
        <BannerHeroComponent />
        {/* from-[#06163A] to-[#0B234F] */}
        <section className="py-10 bg-gradient-to-r  text-white">
          <HomeLoadTrckSearch />
        </section>

        {/* About us section  */}
        <AboutComponent isAbout={false} />

        {/* Why choose us and load baord */}
        <div className="mt-12 px-10 ">
          {/* <h2 className="text-2xl font-bold text-center text-[#06163A] dark:text-[#D62D30]">FAQ & Why Choose Us</h2> */}

          <div className="grid md:grid-cols-2 gap-6 mt-24">
            <WhyUsComponent />
            <div className="relative pb-5 flex flex-col justify-center text-white space-y-6">
              <FaqComponent />
            </div>
          </div>
        </div>

        {/* Achievement Counters */}
        <AchievementComponent />
        <div className="relative w-full ">
          {/* Background image */}
          <div className="w-full bg-[url('/assets/img/banner/g.jpg')] bg-cover bg-center grid md:grid-cols-2 gap-6 py-16 px-10 relative">
            {/* Overlay */}
            <div className="absolute inset-0 bg-black/40"></div>

            {/* Content */}
            <div className="relative z-10 flex flex-col justify-center text-white space-y-6">
              <h1 className="text-3xl md:text-5xl font-bold leading-tight">
                Fast & Reliable Logistics
              </h1>
              <p className="text-lg md:text-xl max-w-lg">
                We connect shippers, carriers, and forwarders with smart
                logistics solutions that save you time and cost.
              </p>
              <div>
                <Link
                  href={"/joinus"}
                  className="bg-[#D62D30] hover:bg-red-700 transition px-6 py-3 rounded-2xl font-semibold"
                >
                  Get Started
                </Link>
              </div>
            </div>
          </div>
        </div>
        <ShortLinks />

        {/* CERTIFICATE SETIION */}
        <CertComponent />
      </div>

      <Footer />
    </>
  );
}
