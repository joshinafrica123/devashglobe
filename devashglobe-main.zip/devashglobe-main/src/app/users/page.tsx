"use client";

import {  useEffect, useMemo, useState } from "react";
import responce from "../datatype/response";
import { useRouter } from "next/navigation";
import { getCookie, setCookie } from "../datatype/frontEndCookiee";
import CountyCodeComphone from "@/components/users/countryCodeComponents";
import { Country, COUNTRY_CODES, formatInternationalPhoneNumber } from "../datatype/countryCode";
import { BASE_URL } from "../core/api";

const STORAGE_KEY = "emailVerifyDeadline";

function formatMMSS(msLeft: number) {
  const total = Math.max(0, Math.floor(msLeft / 1000));
  const m = Math.floor(total / 60).toString().padStart(2, "0");
  const s = (total % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}


export default function User () {

  // verification code state
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
    const [email, setEmail] = useState("");


  // kcy form state
  const [usertype,setUsertype] = useState('');
  const [businessType,setBusinessType] = useState('');
  const [step, setStep] = useState(2);
  const [userType, setUserType] = useState("visitor");
  const [kycType, setKycType] = useState('');
  const [firstname, setFirstName] = useState('');
  const [lastname, setLastName] = useState('');
  const [role, setRole] = useState('users');
  const [phoneNumber, setPhoneNumber] = useState<string>('');  
  const [addressone, setAddressOne] = useState('');  
  const [addresstwo, setAddressTwo] = useState('');
  const [photo, setPhoto] = useState<File | null>(null);
  const [meansid, setMeanId] = useState<File | null>(null);
  const [businesscert, setBusinessCert] = useState<File | null>(null);  
  const [listofboard, setBoardMember] = useState(''); 
  const [licenses, setLicenses] = useState<File | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [selectedCountry,setSelectedCountry] = useState<Country>(COUNTRY_CODES[25]);
  const [usertisEmailVerified, setUsertisEmailVerified] = useState(false);
  const [succesMsg,setSuccessMsg] = useState<string[]>([]);


    const initialDeadline = useMemo(() => {
    // Reuse existing deadline if present; otherwise set a new one
    const stored = typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null;
    const now = Date.now();
    const d = stored ? Number(stored) : now + 5 * 60_000;
    if (!stored && typeof window !== "undefined") localStorage.setItem(STORAGE_KEY, String(d));
    return d;
  }, []);



  const [deadline,setDeadline] = useState<number>(initialDeadline);
  const [now, setNow] = useState<number>(Date.now());
  const msLeft = deadline - now;
  const isOver = msLeft <= 0;

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 250); // smooth countdown, low cost
    return () => clearInterval(id);
  }, []);





  useEffect(() => {

  const bussinessCookiee = getCookie('businesstype') || '';
  const usertypeCookiee = getCookie('usertype') || '';
  console.log(`usertypeCookiee :: ${getCookie('isEmailVerified')}`);
  const usertisEmailVerifiedCookiee = getCookie('isEmailVerified') == "0"? false: true || false;
  const userEmail = getCookie('email') || '';

  
    
  const businessType = bussinessCookiee === '1' ? 'individual': 'co-operations' ;

  setBusinessType(businessType);
  setUsertype(usertypeCookiee);
  setKycType(bussinessCookiee);
  setUsertisEmailVerified(usertisEmailVerifiedCookiee);
  setEmail(userEmail);


  console.log(usertypeCookiee)
  console.log(bussinessCookiee)
  console.log(usertisEmailVerifiedCookiee)
    
  }, []);

  

  const router = useRouter();
  



  const nextStep = () => setStep((prev) => prev + 1);
  const prevStep = () => setStep((prev) => prev - 1);


  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const errologs :string [] = []; 
    setErrors([]);
    setLoading(true);

  if(kycType === '1'){
    

    if (!firstname || 
        !lastname ||
        !phoneNumber ||
        !addressone ||
        !addresstwo ||
        !photo ||
        !meansid 
    ) {
      errologs.push("invalid field please provide valid input ");
    }  else if (
        firstname == "" || 
        lastname == "" ||
        phoneNumber == "" ||
        addressone == "" ||
        addresstwo == "" 
    ) {
        errologs.push(" Field can't be empty! ");
      }


  }else{
    
    

    if (!firstname || 
        !lastname ||
        !phoneNumber ||
        !addressone ||
        !addresstwo ||
        !photo ||
        !meansid ||
        !businesscert || 
        !listofboard ||
        !licenses 
    ) {
      errologs.push("invalid field please provide valid input ");
    }  else if (
        firstname == "" || 
        lastname == "" ||
        role == "" ||
        phoneNumber == "" ||
        addressone == "" ||
        addresstwo == "" ||
        listofboard == "" 
    ) {
        errologs.push(" Field can't be empty! ");
      }




  }

 

    if (errologs.length > 0) {
      setErrors(errologs);
    } else {
      setErrors([]);
      // setLoading(true)
      console.log("save kyc :", firstname );
    
      // Submit your API call here
      saveKyc();
    }
  };

 const onVerify = async (code: string,token:string) => {
    
    try {
      const formData = new globalThis.FormData();
      formData.append('otp', code);

      const response = await fetch(`${BASE_URL}/otp/verification`, {
      method: 'POST',
      headers:{
         'Authorization': `Bearer ${token}`, 
      },
      body: formData, // Assuming the API expects a JSON body
    });

       if (!response.ok) {
      throw new Error(`Failed to verify: ${response.status}`);
    }

    return response.json();

    } catch (error) {
      console.error("Verification error:", error);
      throw error; // Re-throw the error to be caught in the handleVerificationSubmit function
    }
  }

const handleVerificationSubmit  = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors([]);
    try {
      // // Check if the code is provided
      if (!code) {
        setErrors(["Verification code is required."]);
        throw new Error("Verification code is required.");
      }

      // Read cookie 
      const token = getCookie('token');
      console.log(`token :: ${token}`);

      // Call the verification function passed as a prop
      // Assuming onVerify is a function that takes the code and returns a promise
      const isVerified =  await onVerify(code,token||"");

      // Check if the verification was successful
      if (!isVerified) {
        setErrors(["Verification failed. Please check your code."]);
        throw new Error("Verification failed. Please check your code.");
      }


    const dataTypeed = (isVerified as responce);

    if(dataTypeed.error){
      setErrors([dataTypeed.error]);
    }else{
      console.log("Verification successful:", dataTypeed);
      // Set the user as verified
      setUsertisEmailVerified(true);
      setSuccess(true);
      
      // If verification is successful, you can redirect or show a success message
      console.log("Verification successful");
      setSuccessMsg(["Email verified successfully"])
      setSuccess(true);

      //clear the code input after successful verification
      setCode("");
    }

    } catch (error ) {
      console.error("Verification error:", error);
      setErrors(["Verification failed. Please try again."]);
    } finally {
      setLoading(false);
    }
  };


const handleResendOtp  = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors([]);

    try {

      

     // Check if the code is provided
      if (!code) {
        setErrors(["Verification code is required."]);
        throw new Error("Verification code is required.");
      }

      const formData = new globalThis.FormData();
      formData.append('email', email);

      // Read cookie 
      const token = getCookie('token');
      console.log(`token :: ${token}`);

      if (!token) {
        throw new Error("Token is required for verification.");
      }

      // Call the new otp api
      const response = await fetch(`${BASE_URL}/otp/newotp`, {
      method: 'POST',
      headers:{
        'Authorization': `Bearer ${token}`, 
      },
      body: formData, // Assuming the API expects a JSON body
    });

      // Check if the response is ok
      if (!response.ok) {
      throw new Error(`Failed to verify: ${response.status}`);
    }


    const data = await response.json();

    const dataTypeed = (data as responce);

    if(dataTypeed.error){
      setErrors([dataTypeed.error]);
    }else{
      console.log("Verification successful:", dataTypeed);
      // If newopt generation  is successful show success message
      console.log("new opt sent successful");
      setSuccessMsg(["new opt sent!"])
      setSuccess(true)

      const newDeadline = Date.now() + 5 * 60_000;
      localStorage.setItem(STORAGE_KEY, String(newDeadline));
      setDeadline(newDeadline)
    }

    } catch (error ) {
      console.error("new otp error:", error);
      setErrors(["new opt failed. Please try again."]);
    
    } finally {
      setLoading(false);
    }
  };

async function saveKyc(): Promise<void> {

  try {

    const formData = new globalThis.FormData();
    formData.append('first_name', firstname);
    formData.append('last_name', lastname);
    formData.append('roles', role);
    formData.append('phone_number', formatInternationalPhoneNumber(phoneNumber,selectedCountry.code));
    formData.append('address_one', addressone);
    formData.append('address_two',addresstwo);

    if(photo){
    formData.append('photo',photo);
    }
    if(meansid){
      formData.append('Means_ID',meansid);
    } 

    formData.append('category_business',usertype+"");

    if(businesscert){
    formData.append('Business_cert', businesscert);
    }
    formData.append('list_share_holder',listofboard);
    if(licenses){
    formData.append('licenses',licenses);
    }

    
  
// Read cookie 
  const token = getCookie('token');
  console.log(`token :: ${token}`);


    const response = await fetch(`${BASE_URL}/kyc`, {
      method: 'POST',
      headers:{
         'Authorization': `Bearer ${token}`, 
      },
      body: formData, // FormData handles content-type automatically
    });

    if (!response.ok) {
      throw new Error(`Failed to save kyc: ${response.status}`);
    }

    const data = await response.json();
    
    const dataTypeed = (data as responce);

    if(dataTypeed.error){
      const errList : string[] = [dataTypeed.error]
      setErrors(errList);
    }else{
    console.log('kyc user:', data);
    //set user details 
    setCookie({}as responce,'kyc',firstname,lastname,"");

    setLoading(false);

    // Redirect to users page
    router.push(`/users/${usertype}`);
    setRole("");
    }


  } catch (error) {
    console.error('kyc error:', error);
    const dataTypeed = (error as responce);
    if(dataTypeed.error){
      const errList : string[] = [dataTypeed.error]
      setErrors(errList);
    }


  }
}

//  const validatePhone = (phone: string): string[] => {
//     const errorList: string[] = [];
//     const phoneRegex = /^[0-9]{10}$/; // Adjust regex as per your phone number format
//     if (!phoneRegex.test(phone)) {
//       errorList.push("Invalid phone number format. Please enter a 10-digit number.");
//     }
//     return errorList;
//   };


  
  return (
    <div>
    {
    usertisEmailVerified ? (
      <form onSubmit={handleSubmit} >
        <div className="max-w-lg my-30 mx-auto p-6 bg-white dark:bg-gray-800 shadow-md rounded-lg  ">
          {step === 1 && (
            <div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">User Type</h2>
              <label className="block text-gray-700 dark:text-gray-300 mb-2">Select User Type:</label>
              <select id="mySelect"
                className="w-full p-2 border rounded-md"
                value={userType}
                required
                onChange={(e) => setUserType(e.target.value)}
              >
                <option value="visitor">Visitor</option>
                <option value="shipper">Shipper</option>
                <option value="carrier">Carrier</option>
                <option value="broker">Broker</option>
              </select>
                {
                  userType === "visitor" ? (
                        <button className="bg-green-500 text-white px-4 py-2 my-3 rounded">Done</button>
                  ) : (         
                      <button  onClick={nextStep} className="mt-4 bg-red-500 text-white px-4 py-2 rounded cursor-pointer">Next</button>)
                }            

            </div>
          )}

          {step === 2 && (
            
            <div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">KYC - Know Your Client</h2>
              
              {/* Display Errors */}
            {errors.length > 0 && (
              <div className="text-sm text-red-600 dark:text-red-400 space-y-1">
            {errors.map((err, index) => (
              <p key={index}>• {err}</p>
            ))}
            
              </div>
            )}


            {/*  <label className="block text-gray-700 dark:text-gray-300 mb-2">Select Type:</label>*/}
              <div className="flex gap-4 mb-4">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="kycType"
                    value={kycType+''}
                    checked={kycType === kycType}
                    onChange={() => setKycType(kycType)}
                  />
                  {businessType}
                </label>
                { /*<label className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="kycType"
                        value="cooperation"
                        onChange={() => setKycType("cooperation")}
                      />
                      Co-operations
                    </label>*/}
              </div>
              <label className="block mb-1">First Name:</label>
              <input className="w-full p-2 border rounded-md mb-2" value={firstname} onChange={(e) => setFirstName(e.target.value) } placeholder="First Name" required/>

              <label className="block mb-1">Last Name:</label>
              <input className="w-full p-2 border rounded-md mb-2" value={lastname} onChange={(e) => setLastName(e.target.value) } placeholder="Last Name" required/>

                
          <div className="w-full space-y-1">
            <label className="block text-sm font-medium text-gray-700">
              Phone Number
            </label>
            <CountyCodeComphone 
              onCountryChange={(country) => setSelectedCountry(country)}
              onPhoneChange={(eg) => setPhoneNumber(eg)}
            />
              {/* <input className="flex-1/3 p-2 border rounded-md mb-2" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="Phone Number" required /> */}

          </div>



              {/* <label className="block mb-1">Phone Number:</label> */}
              {/* <input className="w-full p-2 border rounded-md mb-2" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="Phone Number" required /> */}

              <label className="block mb-1">Address:</label>
              <input className="w-full p-2 border rounded-md mb-2" value={addressone} onChange={(e) => setAddressOne(e.target.value)} placeholder="Address One" required />

              <label className="block mb-1" >Adress two: </label>
              <input className="w-full p-2 border rounded-md mb-2" value={addresstwo} onChange={(e) => setAddressTwo(e.target.value)} placeholder="Address two " required />

              <label className="block mb-1">Photo: A good passport photograph of you less 7mb</label>
              <input type="file" className="w-full p-2 border rounded-md mb-2" name="photo" onChange={(e) => setPhoto(e.target.files?.[0] || null)}  accept="image/*" required/>

              <label className="block mb-1">Means of Identification:</label> <span> name your file with means of Id eg: passport.jpg</span>
              <input type="file" className="w-full p-2 border rounded-md mb-2" accept="image/*" onChange={(e)=> setMeanId(e.target.files?.[0] || null)} required  />

              <div className="flex justify-between mt-4">
                {/* <button onClick={prevStep} className="bg-gray-500 text-white px-4 py-2 rounded">Back</button> */}
                {kycType === "1" ? (
                  <button className="bg-green-500 text-white px-4 py-2 rounded cursor-pointer">
                    {
                      loading ? "Sending..":"Submit"
                    }
                    </button>
                ) : (
                  <button onClick={nextStep} className="bg-red-500 text-white px-4 py-2 rounded cursor-pointer">Next</button>
                )}
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Company Information</h2>
              <label className="block mb-1">License :</label>
              <input type="file" accept="image/*" className="w-full p-2 border rounded-md mb-2" onChange={(e) => setLicenses(e.target.files?.[0] || null)} placeholder="License" required/>

              {/*<label className="block mb-1">Category of Business:</label>
              <input className="w-full p-2 border rounded-md mb-2" onChange={(e)=> setBusinessCart(e.target.value)} placeholder="Category of Business" required/>*/}

              <label className="block mb-1">Business Certificate:</label>
              <input type="file" className="w-full p-2 border rounded-md mb-2" onChange={(e) => setBusinessCert(e.target.files?.[0] || null)}   placeholder="Certificates" required />

              <label className="block mb-1">List of Shareholders:</label> <span>seperated by comma eg: john_martins-ceo,smith_rock-cfo</span>
              <textarea className="w-full p-2 border rounded-md mb-2" onChange={(e)=>setBoardMember(e.target.value) } placeholder="List of Shareholders" required></textarea>

              <div className="flex justify-between mt-4">
                <button onClick={prevStep} className="bg-gray-500 text-white px-4 py-2 rounded cursor-pointer">Back</button>
                <button className="bg-green-500 text-white px-4 py-2 rounded cursor-pointer">
                    {
                      loading ? "Sending..":"Submit"
                    }
                  </button>
              </div>
            </div>
          )}
        </div>
      </form>
      ):(
      <div className="flex items-center justify-center min-h-screen">
        <div className="max-w-md w-full p-6 bg-white rounded shadow">
          <h2 className="text-xl font-bold mb-4">Verify Your Email</h2>
          <p className="mb-2">A verification code has been sent to <span className="font-semibold">{email}</span>.</p>
          <form onSubmit={handleVerificationSubmit} className="space-y-4">
            {/* 6 separate inputs for verification code */}
            <div className="flex gap-2 justify-center">
              {[0,1,2,3,4,5].map((idx) => (
                <input
                  key={idx}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  className="w-10 h-12 text-center border px-3 py-2 rounded text-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={code[idx] || ""}
                  onChange={e => {
                    const val = e.target.value.replace(/[^0-9a-zA-Z]/g,"").slice(0,1);
                    const newCode = code.split("");
                    newCode[idx] = val;
                    const joined = newCode.join("");
                    setCode(joined);
                    // Auto-focus next input if value entered
                    if (val && idx < 5) {
                      const next = document.getElementById(`code-input-${idx+1}`);
                      if (next) next.focus();
                    }
                  }}
                  id={`code-input-${idx}`}
                  required
                />
              ))}
            </div>
            <button
              type="submit"
              className="w-full bg-[#06163A] text-white py-2 rounded hover:bg-[#06163A] transition cursor-pointer"
              disabled={loading}
            >
              {loading ? "Verifying..." : "Verify"}
            </button>
            {(errors.length > 0 || isOver) && 
            (
            <>
              <button className="text-[#ff5100] border-2 rounded p-2 " onClick={handleResendOtp}>resend</button>
            </>
            )}

             {errors.map((err, index) => (
              <p key={index}>• {err}</p>
            ))
            }

              {(errors.length < 0) && 
            (
              // <span className="font-semibold">Expires in 5 mins... </span>
               <span className="rounded-md bg-gray-100 px-2 py-1 text-sm font-medium">
                {isOver ? "00:00" : formatMMSS(msLeft)}
              </span>
            )}
                
            {success && 
            (succesMsg.map((e,i) => (
                  <div key={i} className="text-green-600">{e}</div>
                  
            ))
          
            )
            
            
            }
          </form>
        </div>
      </div>
      )
    }
  </div>
  );
};



