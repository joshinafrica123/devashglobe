"use client";


import React, { useState, useEffect } from "react";
import { getCookie, postWhatCookie } from "@/app/datatype/frontEndCookiee";
import user from "@/app/datatype/user";
import { BASE_URL, GetLoadBorad, getLoadLoadBoard } from "@/app/core/api";
import { loadboard } from "@/app/datatype/loadboards";
import { x_loadBoard } from "@/app/datatype/data";
import NoSearchFound from "@/components/notfound";
import {
  dashboardDetails,
} from "@/app/core/util";
import { useRouter } from "next/navigation";
import AlertMessage from "@/components/alertmessage";
import { FaCheckCircle } from "react-icons/fa";

export default function ShipperDashboard() {
  // const router = useRouter();
  const [user, setUser] = useState({ name: "" });
  const [load, setLoads] = useState<loadboard[]>(x_loadBoard);
  const [showAlert, setShowAlert] = useState(false);

  const router = useRouter();

  useEffect(() => {
    // Simulate fetching user data
    /**setTimeout(() => {
      setUser({ name: "Cristina" });
    }, 1000);**/
    handleLoadLoadBoard();

    const user = {
      name: getCookie("userfirstname"),
      last_name: getCookie("userlastname"),
      isVerified: getCookie("isVerified") === "false" ? false : true || false,
    };

    const postWhat = getCookie("postwhat") || "";

    console.log(`postWhat :: ${postWhat}`);

    //check if user is not verified and is trying to access post load or post truck page
    if (postWhat === "post truck clicked") {
      setShowAlert(true);
    } else if (postWhat === "post load clicked") {
      postWhatCookie("");
      router.push("/users/shipper/load");
    }

    setTimeout(() => {
      if (postWhat !== "") {
        postWhatCookie("");
        setShowAlert(false);
      }
    }, 3000);

    setUser(user as user);
  }, []);

  async function handleLoadLoadBoard(): Promise<void> {
    // get logged in user token
    const token = getCookie("token");
    console.log(`token :: ${token}`);

    const loadLoadBoard = await getLoadLoadBoard(
      token + "",
      `${BASE_URL}/loadboards/user/loadboard?q=load`
    );

    //confirm if loading was successful
    if ((loadLoadBoard as GetLoadBorad).status) {
      setLoads((loadLoadBoard as GetLoadBorad).body as loadboard[]);
      // setStatData(handleSetTructStat(loadLoadBoard as GetLoadBorad, "load"));
    } else {
      //   setErrors((loadLoadBoard as GetLoadBorad).body as string [])
    }
  }

  return (
    <div className="w-full">
        <AlertMessage show={showAlert} onSetShow={setShowAlert} type="warning" message=" 🚨 Note: you need a carrier account to complete this action." />
      {/* Dashboard Header */}
      <div className="bg-white shadow rounded-lg p-4 mb-4 flex items-center justify-between">
        {/* Left side: Text */}
        <div className="bg-white  rounded-lg p-4 mb-4">
          {/* Top section */}
          <div>
            <h5 className="text-2xl font-bold capitalize">
              {user?.name || "Guest"}
            </h5>
            <h6 className="text-gray-500">Welcome back!</h6>
          </div>

          {/* Divider line (optional) */}
          <div className="my-3 border-t border-gray-200"></div>

          {/* Bottom section */}
          <div className="flex items-center justify-between">
            <span className="text-lg text-gray-700 font-bold ">
              {"Shiper"}
            </span>

            {/* Verified badge */}
            <div className="flex items-center gap-1 text-green-600 font-medium">
              <FaCheckCircle size={24} color="grey" />
            </div>
          </div>
        </div>

        {/* Right side: GIF */}
        {/* <img
          src="/assets/img/welcome.gif"
          alt="Welcome"
          className="w-50 h-50 object-contain"
        /> */}
      </div>

      {/* Dashboard Stats */}
  {/* Dashboard Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-2 mb-4">
        <div className="bg-white p-4 shadow rounded-lg flex items-center justify-between">
          {/* Left side */}
          <div className="flex flex-col justify-between">
            {/* Top text */}
            <div className="mb-6">
              <h6 className="text-gray-500 text-sm">Total Transactions</h6>
                <p className="text-2xl font-bold text-gray-800">
                ${dashboardDetails.transaction}
              </p>
            </div>

            {/* Bottom text */}
            <div>
               <h6 className="text-gray-500 text-sm">status</h6>
              <p className="text-green-500 text-sm">+5.4% since last month</p>
            </div>
          </div>

          {/* Right side (image or icon) */}
          <div>
            <img
              src="/assets/img/transaction.gif"
              alt="Transactions"
              className="w-30 h-30 object-contain"
            />
          </div>
        </div>
        <div className="bg-white p-4 shadow rounded-lg flex items-center justify-between">
          {/* Left side */}
          <div className="flex flex-col justify-between">
            {/* Top text */}
            <div className="mb-6">
              <h6 className="text-gray-500 text-sm">Active Loads</h6>
                <p className="text-2xl font-bold text-gray-800">
                ${load.length}
              </p>
            </div>

            {/* Bottom text */}
            <div>
               <h6 className="text-gray-500 text-sm">status</h6>
              <p className="text-green-500 text-sm">+5.4% since last month</p>
            </div>
          </div>

          {/* Right side (image or icon) */}
          <div>
            <img
              src="/assets/img/truck.gif"
              alt="Transactions"
              className="w-30 h-30 object-contain"
            />
          </div>
        </div>

        {/* <div className="bg-white p-4 shadow rounded-lg">
          <h6 className="text-gray-500">Pending Payments</h6>
          <p className="text-2xl font-bold">${dashboardDetails.pending}</p>
        </div> */}
    
      </div>



      {/* Recent Transactions Table */}
      <div className="bg-white p-4 shadow rounded-lg mt-8 max-h-80 overflow-hidden">
        <h6 className="text-xl font-bold mb-4">Recent Transactions</h6>
        <table className="w-full border-collapse border border-gray-200">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-2 text-left">ID</th>
              <th className="border p-2 text-left">Amount</th>
              <th className="border p-2 text-left">Status</th>
              <th className="border p-2 text-left">Date</th>
            </tr>
          </thead>
          {/* <tbody>
            <tr>
            <td className="border p-2">#12345</td>
            <td className="border p-2">$500</td>
            <td className="border p-2 text-green-500">Completed</td>
            <td className="border p-2">Mar 31, 2025</td>
            </tr>
            <tr>
            <td className="border p-2">#12346</td>
            <td className="border p-2">$750</td>
            <td className="border p-2 text-yellow-500">Pending</td>
            <td className="border p-2">Mar 30, 2025</td>
            </tr>
        </tbody> */}
        </table>
        <NoSearchFound title="No Transactions yet!" />
      </div>
    </div>
  );
}
