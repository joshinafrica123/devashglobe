"use client";

import NoSearchFound from "@/components/notfound";
import { useEffect, useState } from "react";

export default function  TransactionsPage ()  {

  const data: { id: number, date: string, amount: string, status: string } []= [
  ];

  const [transactions, setTransactions] = useState(data);

  
    useEffect(() => {

      data.forEach((x) => {
        console.log(x)
        data.pop()
      })
      setTransactions(data);
    }, []);
  

  
  return (
    <div className="w-full m-10 dark:bg-gray-900 ">
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">Transactions</h2>
      <table className="w-full border-collapse border border-gray-300 dark:border-gray-700">
        <thead>
          <tr className="bg-gray-100 dark:bg-gray-800">
            <th className="border p-3">ID</th>
            <th className="border p-3">Date</th>
            <th className="border p-3">Amount</th>
            <th className="border p-3">Status</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((txn) => (
            <tr key={txn.id} className="text-center">
              <td className="border p-3">{txn.id}</td>
              <td className="border p-3">{txn.date}</td>
              <td className="border p-3">{txn.amount}</td>
              <td className={`border p-3 ${txn.status === "Completed" ? "text-green-500" : txn.status === "Pending" ? "text-yellow-500" : "text-red-500"}`}>
                {txn.status}
              </td>
            </tr>
          ))}
        </tbody>
      
      </table>
        {
                        transactions.length < 1 && (
                        <NoSearchFound title="No Transactions yet!" />
                        )}
    </div>
  );
};

