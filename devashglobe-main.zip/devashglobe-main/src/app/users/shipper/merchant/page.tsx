"use client";

import { apiCall, BASE_URL } from "@/app/core/api";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import responce from "@/app/datatype/response";
import Contract from "@/app/datatype/contract";
import { useEffect, useState } from "react";
import { FaMoneyBill } from "react-icons/fa";
import NoSearchFound from "@/components/notfound";
import PaymentCheckoutModal from "@/components/mockPayment";


const x : Contract [] =[ {
  id: 0,
  object_id:0,
  account_id:0,
    shippers_id:0,
   contract_type:"", 
   carrier_id:0 ,
   truck_id:"",
   load_id:"",
   description:"",
   delivery_time:"",
   shippers_status:"",
   carrier_status:"",
   payment:"",
   payment_status:"",
   mode_of_payment:9,
    status: "",
    date: "",
    deleted: 0,
    updated_at: ""

}];


export default function  TransactionsPage ()  {

  // const data = [
  //   { id: 1, date: "2025-04-01", amount: "$200", status: "Completed" },
  //   { id: 2, date: "2025-04-02", amount: "$500", status: "Pending" },
  //   { id: 3, date: "2025-04-03", amount: "$100", status: "Failed" },
  // ];


  const [merchant, setMerchant] = useState<Contract[]>(x);
 const [loading,setLoading] =useState(false);
  // const [token,setToken] =useState("");
  const [errors,setErrors] = useState<string[]>([]);
  // const [message,setMessages] =useState<string[]>([]);
  // const [message,setMessages] =useState<loadboard[]>(x);
    const [open, setOpen] = useState(false);
    const [amount, setAmount] = useState(0);
  
    useEffect(() => {
      handleGetMerchant();
    }, []);
  
const handleView = (x:Contract) =>{
console.log(x)
const y: number = parseInt(x.payment.split('-')[0]);
setAmount(y)
setOpen(true)
}
      async function handleGetMerchant() {
          console.log(" actions ")
            setLoading(true)
            setErrors([]);
    
            try {
              const token = getCookie("token");
    
              // TODO MODIFY THIS END POINT 
              // TODO  FIX API TO RETURN BASED ON USER LOGIN
              const response = await apiCall(token + "", `${BASE_URL}/merchant/shipper`, "GET", null);
            
              if (!response.ok) {
                throw new Error(`Failed to get : ${response.status}`);
              }
              const data = await response.json();
              const dataTypeed = data as responce;

              if (dataTypeed.error) {
                setErrors([dataTypeed.error]);         
                setLoading(false);
              } else {
                  console.log(dataTypeed.contracts + "hii ")
                  setMerchant(dataTypeed.contracts)
                  setLoading(false);
    
              }
            } catch (error) {
              setLoading(false);
              console.error("faq error:", error);
              console.error("faq error:", errors);
            }
      }
    
  
  return (
    <div className="w-full m-10 dark:bg-gray-900 ">
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">Merchant Calls</h2>
              <table className="w-full border-collapse text-sm text-gray-700 dark:text-gray-200">
                <thead>
                  <tr className="bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300">
                    <th className="p-3 text-left">ID</th>
                    <th className="p-3 text-left">Date</th>
                    <th className="p-3 text-left">Amount</th>
                    <th className="p-3 text-left">Status</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="p-5 text-center text-gray-500">
                        Searching...
                      </td>
                    </tr>
                  ) : (
                    merchant?.map((txn, idx) => (
                      <tr
                        key={txn.id}
                        className={`text-center transition hover:bg-gray-50 dark:hover:bg-gray-700 ${
                          idx % 2 === 0 ? "bg-white dark:bg-gray-900" : "bg-gray-50 dark:bg-gray-800"
                        }`}
                      >
                        <td className="p-3 font-medium">{idx+1}</td>
                        <td className="p-3">{txn.date}</td>
                        <td className="p-3 font-semibold">${txn.payment}</td>
                        <td
                          className={`p-3 font-semibold ${
                            txn.status === "Completed"
                              ? "text-green-500"
                              : txn.status === "Pending"
                              ? "text-yellow-500"
                              : "text-red-500"
                          }`}
                        >
                          {txn.status === "0" ? "New" : txn.status}
                        </td>
                        <td className="p-3">
                          <button
                            onClick={() => handleView(txn)}
                            className="cursor-pointer  inline-flex items-center gap-2 rounded-xl bg-green-500 px-4 py-2 text-white shadow hover:bg-green-600 focus:ring-2 focus:ring-green-400 focus:outline-none transition"
                          >
                            {
                              !loading ? (
                                <><FaMoneyBill className="text-sm" /> {`Make payment`}
                                </> ):(
                              <>
                                seeding...
                              </>
                            )
                              }
                          </button>
                        </td>
                      </tr>
                    ))
                   
                  )}

                   
                </tbody>
              </table>
                      {
                      merchant.length < 1 && (
                      <NoSearchFound title="No Merchant call yet!" />
                    )}

      <PaymentCheckoutModal
        open={open}
        onClose={() => setOpen(false)}
        amount={amount}
        merchant="AshPay"
        reference={`REF-${Date.now()}`}
        onPay={async (payload) => {
          // TODO: call  Paystack initialization/verify here
          console.log(payload)
          // await fetch('/api/paystack/verify?...')
          await new Promise((r) => setTimeout(r, 1200)); // simulate
        }}
      />
              
    </div>
  );
};

