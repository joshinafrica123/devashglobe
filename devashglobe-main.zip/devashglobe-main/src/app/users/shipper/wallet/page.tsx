"use client";
import { useState } from "react";
import Image from "next/image";
import NoSearchFound from "@/components/notfound";
import Transaction from "@/app/datatype/transaction";

export default function WalletPage() {
  const [hidden, setHidden] = useState(true);
  const [modalType, setModalType] = useState<string | null>(null);

  const balance = "$1,200.00";
  const toggleBalance = () => setHidden(!hidden);

  const openModal = (type: string) => setModalType(type);
  const closeModal = () => setModalType(null);

  

  const transactions : Transaction []  = [
    // { id:type: "credit", label: "Payment for Load #ASH134", amount: "+ $350" },
    // { type: "credit", label: "Payment for Load #VCU135", amount: "+ $1000" },
    // { type: "credit", label: "Payment for Load #ASH136", amount: "+ $670" },
    // { type: "debit", label: "Refund Request #VCU119", amount: "- $120" },
    // { type: "debit", label: "Carrier Payment", amount: "- $200" },
    { id: "1", date: "2024-06-01", type: "credit", amount: 350, description: "Payment for Load #ASH134" },
  ];
    //bg-gradient-to-br from-[#0E234F] via-[#1B376F] to-[#D62D30]
    // JSX Return
  return (
    <div className="w-full flex  justify-center text-black ">
      <div className="w-full bg-[#e5e7eb18] backdrop-blur-2xl  p-6 ">
        {/* Header */}
        <div className="text-left mb-8 animate-fadeIn">
          <h2 className="text-2xl font-semibold">My Wallet</h2>
          <p className="text-sm mt-2 opacity-90">
            Manage your logistics transactions with ease
          </p>
        </div>

        {/* Balance */}
        <div className="relative bg-white/20 rounded-2xl p-4 mb-6 text-center">
          <Image
            src={
              hidden
                ? "/assets/img/visible.png"
                : "/assets/img/invisible.png"
            }
            alt="toggle balance"
            width={28}
            height={28}
            onClick={toggleBalance}
            className="absolute top-3 right-3 cursor-pointer transition hover:scale-110"
          />
          <strong className=" text-left ">Available Balance:</strong>
          <div
            className={`mt-2 text-2xl font-semibold tracking-wider transition-all ${
              hidden ? "text-transparent drop-shadow-[0_0_6px_rgba(255,255,255,0.6)]" : ""
            }`}
          >
            {hidden ? "******" : balance}
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-3 mb-6 animate-fadeIn justify-center">
          <button
            onClick={() => openModal("Top Up")}
            className="flex-1 min-w-[100px] bg-[#D62D30] hover:bg-[#b92123] transition rounded-xl py-2 font-medium"
          >
            Top Up
          </button>
          <button
            onClick={() => openModal("Send")}
            className="flex-1 min-w-[100px] bg-[#D62D30] hover:bg-[#b92123] transition rounded-xl py-2 font-medium"
          >
            Send
          </button>
          <button
            onClick={() => openModal("Withdraw")}
            className="flex-1 min-w-[100px] border-2  border-black text-black hover:bg-white/10 transition rounded-xl py-2 font-medium"
          >
            Withdraw
          </button>
        </div>

        {/* Transactions */}
        <div className="bg-white/10 rounded-2xl p-4 max-h-64 overflow-y-auto">
          <h3 className="text-center text-lg font-medium border-b border-white/30 pb-2 mb-3">
            Recent Transactions
          </h3>
          {transactions.map((tx, i) => (
            <div
              key={i}
              className="flex justify-between items-center border-b border-dashed border-white/20 py-2 text-sm flex-wrap"
            >
              <span className="flex items-center gap-2">
                {tx.type === "credit" ? (
                  <span className="text-green-400 font-bold">✔</span>
                ) : (
                  <span className="text-red-400 font-bold">✖</span>
                )}
                {tx.type === "credit" ? tx.description : tx.description}
              </span>
              <span
                className={`font-medium ${
                  tx.type === "credit" ? "text-green-400" : "text-red-400"
                }`}
              >
                {tx.amount}
              </span>
            </div>
          ))
          }
          {
            transactions?.length < 1 && (
                      <NoSearchFound title="No Recent Transactions !" />
                    )}
        
        </div>
      </div>

      {/* Modal */}
      {modalType && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white/10 backdrop-blur-2xl rounded-2xl p-6 text-center max-w-sm w-full">
            <h3 className="text-xl font-semibold mb-2">{modalType}</h3>
            <p className="text-sm mb-4">Enter the amount to proceed.</p>
            <input
              type="number"
              placeholder="$0.00"
              className="w-4/5 p-2 rounded-md border-none text-center bg-white/20 text-white placeholder:text-white/50"
            />
            <button
              onClick={closeModal}
              className="mt-4 bg-[#D62D30] hover:bg-[#b92123] transition rounded-lg px-5 py-2 text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
