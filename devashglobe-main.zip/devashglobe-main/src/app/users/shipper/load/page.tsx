"use client";

import { apiCall, BASE_URL, GetLoadBorad, getLoadLoadBoard } from "@/app/core/api";
import { validLongLat } from "@/app/core/util";
import { x_loadBoard } from "@/app/datatype/data";
import { equipment } from "@/app/datatype/equipment";
import { getCookie } from "@/app/datatype/frontEndCookiee";
import { loadboard } from "@/app/datatype/loadboards";
import responce from "@/app/datatype/response";
import NoSearchFound from "@/components/notfound";
import { Suspense, useEffect, useState } from "react";

export default function LoadsPage() {
    const [loads, setLoads] = useState<loadboard[]>(x_loadBoard);
    const [errors, setErrors] = useState<string[]>([]);
    const [equipment, setEquipments ] = useState<equipment[]>([]);
    const today = new Date().toISOString().split("T")[0]; // YYYY-MM-D

  const [showModal, setShowModal] = useState(false);
  const [newLoad, setNewLoad] = useState({
    equipments: "",
    start_date: "",
    end_date: "",
    from_state: "",
    to_state: "",
    from_city: "",
    to_city: "",
    load_title: "",
    type_load: "",
    size: "",
    longitude_latitude: "",
    highest_price: "",
    best_price: "",
    lowest_price: "",
    load_image: null,
  });
  const [load_image, setLoadImage] = useState<File | null>(null);



  useEffect(()=>{
    handleLoadLoadBoard();

    //get equipment 
    handleGetEquipment();
  },[]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewLoad((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errologs :string [] = []; 

    //save, send to loadboard endpoint
    saveToLoadBoard(errologs);

    // setLoads((prev) => [...prev, { id: prev.length + 1, description: newLoad.load_title, status: "Pending" }]);
    // setShowModal(false);
  };


  

async function handleGetEquipment() {
  try {
      // get logged in user token
      const token = getCookie('token');

       const response = await apiCall(token+"",`${BASE_URL}/equipments`,'GET', null );

              if (!response.ok) {
                  throw new Error(`Failed to get : ${response.status}`);
              }

              const data = await response.json();
              console.log(data);

              const dataTypeed = (data as responce);

              
                if(dataTypeed.error){
                      const errList : string[] = [dataTypeed.error]
                      setErrors(errList);
                    }else{
                      console.log(dataTypeed.equipments);

                    setEquipments(dataTypeed.equipments);
                    
                      }
                  
                  

  } catch (error) {
      console.error('equipment error:', error);
  }
}  


  
  async function  handleLoadLoadBoard () :Promise<void> {

            // get logged in user token
              const token = getCookie('token');
              console.log(`token :: ${token}`);

              const loadLoadBoard = await getLoadLoadBoard(token+"",`${BASE_URL}/loadboards/user/loadboard?q=load`);

              //confirm if loading was successful
              if((loadLoadBoard as GetLoadBorad).status){
                  setLoads((loadLoadBoard as GetLoadBorad).body as loadboard [])
              } else{
                  setErrors((loadLoadBoard as GetLoadBorad).body as string [])
              }

  }


async function saveToLoadBoard  (errologs:string []) :Promise<void>  {


    try {

      if(!newLoad){
                errologs.push("invalid field please provide valid input ");
      }else{
        if(newLoad.best_price == "" || 
          newLoad.end_date === "" ||
          newLoad.equipments === "" ||
          newLoad.from_city === "" ||
          newLoad.from_state === "" ||
          newLoad.highest_price === "" ||
          newLoad.load_title === "" ||
          newLoad.longitude_latitude === "" ||
          newLoad.lowest_price === "" ||
          newLoad.size === "" ||
          newLoad.start_date === "" ||
          newLoad.to_city === "" ||
          newLoad.to_state === "" ||
          newLoad.type_load === "" 
         ){
              errologs.push("invalid fields can not be empty! ");
        }else{
           if(load_image === null){
              errologs.push("invalid fields, kindly attach a picture!");
           }
              if(!validLongLat(newLoad.longitude_latitude)){
                errologs.push("invalid longitude and  latitude, Latitude must be >= -90,Latitude must be >= -90 ");
              }
        }
      }


      if(errologs.length > 0){
          //display errors if any
            setErrors(errologs);
      }else{
          const formData = new globalThis.FormData();
            formData.append('type', "load");
            formData.append('equipment_id', newLoad.equipments);
            formData.append('date_upper_range', newLoad.end_date);
            formData.append('date_lower_range', newLoad.start_date);
            formData.append('from_state', newLoad.from_state);
            formData.append('to_state', newLoad.to_state);
            formData.append('from_city', newLoad.from_city);
            formData.append('to_city', newLoad.to_city);
            formData.append('title', newLoad.load_title);
            formData.append('type_load', newLoad.type_load);
            formData.append('size', newLoad.size);
            formData.append('long_lat', newLoad.longitude_latitude);
            formData.append('price_upper_range', newLoad.highest_price);
            formData.append('price_best_range', newLoad.best_price);
            formData.append('price_low_range', newLoad.lowest_price);

            if(load_image){
                  formData.append('image', load_image);
            }


            // get logged in user token
              const token = getCookie('token');
              console.log(`token :: ${token}`);

            // save truck; send to api
                const response = await apiCall(token+"",`${BASE_URL}/loadboards`,'POST', formData );

              if (!response.ok) {
                  throw new Error(`Failed to save loadboards truck: ${response.status}`);
              }

              const data = await response.json();

              console.log(data);
    
              const dataTypeed = (data as responce);

                if(dataTypeed.error){
                      const errList : string[] = [dataTypeed.error]
                      setErrors(errList);
                    }else{
                      console.log(dataTypeed);
                      setLoads((prev) => [...prev,    {
                            id:dataTypeed.insertId,
                            account_id:12,
                            type:"truck", 
                            equipment_id:parseInt(newLoad.equipments), 
                            date_upper_range:newLoad.end_date, 
                            date_lower_range:newLoad.start_date,
                            from_state:newLoad.from_state,
                            to_state:newLoad.to_state,
                            from_city:newLoad.from_city,
                            to_city:newLoad.to_city,
                            title:newLoad.load_title,
                            type_load:newLoad.type_load,
                            size:parseInt(newLoad.size),
                            long_lat:newLoad.longitude_latitude,
                            price_upper_range:newLoad.highest_price,
                            price_best_range:newLoad.best_price,
                            price_low_range:newLoad.lowest_price,
                            image:load_image?.name+"",
                            track_id: "load_23455667899",
                            status:"0" ,
                            date:"1/34/67",
                            deleted: 0,
                            updated_at: "45/7/567",
                        },]);
                      setShowModal(false);
                    }
                  
                  
                  }


    } catch (error) {
      console.error('loadboards error:', error);
      const dataTypeed = (error as responce);
      if(dataTypeed.error){
        const errList : string[] = [dataTypeed.error]
        setErrors(errList);
      }
    }



} 





  
  return (
    <div className="w-full m-10 dark:bg-gray-900 ">
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">Loads</h2>
      <button onClick={() => setShowModal(true)} className="mb-4 bg-red-500 text-white px-4 py-2 rounded">
        + Add Load
      </button>

      {/* TODO fix the suspense */}
      <Suspense> 
      <ul className="space-y-3">
        {loads.length > 0 ?( loads.map((load) => (
          <li
            key={load.id}
            className="p-4 border rounded-md shadow-md flex justify-between bg-gray-100 dark:bg-gray-800"
          >
            <span><b>{load.title}</b></span>
            
            <span
              className={`font-semibold ${
                load.status === "Delivered"
                  ? "text-green-500"
                  : load.status === "In Transit"
                  ? "text-yellow-500"
                  : "text-green-500"
              }`}
            >
              {load.track_id}
            </span>
          </li>
        ))):(
          
            <NoSearchFound title="No Loads yet!" />
        )}
      </ul>
      </Suspense>

      {showModal && (
        <div
          className="fixed inset-0 flex items-center justify-center bg-[#06163ad4] bg-opacity-10 z-50"
          onClick={() => setShowModal(false)}
        >
          <div
            className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg max-w-3xl w-full overflow-y-auto max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Add New Load</h2>

            
	         {errors.length > 0 && (
             <div className="text-sm text-red-600 dark:text-red-400 space-y-1">
          {errors.map((err, index) => (
            <p key={index}>• {err}</p>
          ))} 
          </div>
           )}
          
            

            <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">


              {/* Left Column */}
              <div>
                <label className="block text-gray-700 dark:text-gray-300">Equipments:</label>
                
                <select name="equipments" onChange={handleInputChange} className="w-full p-2 border rounded-md">
                  <option value="">Select Type</option>
                {equipment.length > 0 && (
                   equipment.map((item) => (
                        <option key={item.id} value={item.id}> {item.title}</option>
                  ))
                )}
                  <option value="others">Others</option>
                </select>


                <label className="block">Date Range (Start Date):</label>
                <input type="date" name="start_date" min={today} onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">End Date:</label>
                <input type="date" name="end_date" min={today} onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">From State:</label>
                <input type="text" name="from_state" onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">To State:</label>
                <input type="text" name="to_state" onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">From City:</label>
                <input type="text" name="from_city" onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">To City:</label>
                <input type="text" name="to_city" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
              </div>

              {/* Right Column */}
              <div>
                <label className="block">Load Title:</label>
                <input type="text" name="load_title" onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">Type of Load:</label>
                <select name="type_load" onChange={handleInputChange} className="w-full p-2 border rounded-md">
                  <option value="">Select Type</option>
                  <option value="solid">Solid</option>
                  <option value="liquid">Liquid</option>
                  <option value="gas">Gas</option>
                </select>

                <label className="block">Size:</label>
                <input type="text" name="size" onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">Longitude & Latitude:</label>
                <input type="text" name="longitude_latitude" onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">Highest Price:</label>
                <input type="number" name="highest_price" onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">Best Price:</label>
                <input type="number" name="best_price" onChange={handleInputChange} className="w-full p-2 border rounded-md" />

                <label className="block">Lowest Price:</label>
                <input type="number" name="lowest_price" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
              </div>

              {/* Load Image (Full Width) */}
              <div className="col-span-2">
                <label className="block">Load Image:</label>
                <input type="file" name="load_image" accept="image/*" onChange={(e) => setLoadImage(e.target.files?.[0] || null)} className="w-full p-2 border rounded-md" />
              </div>

              {/* Buttons (Full Width) */}
              <div className="col-span-2 flex justify-between mt-4">
                <button type="button" onClick={() => setShowModal(false)} className="bg-gray-500 text-white px-4 py-2 rounded">
                  Cancel
                </button>
                <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded">
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}


// {showModal && (
//     <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
//       <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg w-full max-w-4xl overflow-y-auto max-h-[90vh]">
//         <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Add New Load</h2>
//         <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
//           {/* Inputs divided into two columns */}
//           <div>
//             <label className="block text-gray-700 dark:text-gray-300">Equipments:</label>
//             <input type="text" name="equipments" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
            
//             <label className="block">Start Date:</label>
//             <input type="date" name="start_date" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
  
//             <label className="block">End Date:</label>
//             <input type="date" name="end_date" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
  
//             <label className="block">From State:</label>
//             <input type="text" name="from_state" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
  
//             <label className="block">To State:</label>
//             <input type="text" name="to_state" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
//           </div>
  
//           <div>
//             <label className="block">Load Title:</label>
//             <input type="text" name="load_title" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
  
//             <label className="block">Type of Load:</label>
//             <select name="type_load" onChange={handleInputChange} className="w-full p-2 border rounded-md">
//               <option value="">Select Type</option>
//               <option value="solid">Solid</option>
//               <option value="liquid">Liquid</option>
//               <option value="gas">Gas</option>
//             </select>
  
//             <label className="block">Highest Price:</label>
//             <input type="number" name="highest_price" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
  
//             <label className="block">Best Price:</label>
//             <input type="number" name="best_price" onChange={handleInputChange} className="w-full p-2 border rounded-md" />
  
//             <label className="block">Load Image:</label>
//             <input type="file" name="load_image" className="w-full p-2 border rounded-md" />
//           </div>
  
//           {/* Buttons */}
//           <div className="col-span-2 flex justify-between mt-4">
//             <button type="button" onClick={() => setShowModal(false)} className="bg-gray-500 text-white px-4 py-2 rounded">
//               Cancel
//             </button>
//             <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded">
//               Submit
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   )}
  