"use client";

import NoSearchFound from "@/components/notfound";
import { useEffect, useState } from "react";

export default function   RefundsPage () {

  const data = [
    { id: 1, amount: "$50", reason: "Damaged Product", status: "Processed" },
    { id: 2, amount: "$120", reason: "Wrong Item", status: "Pending" },
    { id: 3, amount: "$80", reason: "Late Delivery", status: "Rejected" },
  ];

  const [refunds, setRefunds] = useState(data);

    useEffect(() => {
      data.forEach(() =>{
        data.pop()
      })
      setRefunds(data);
    }, []);
  

  
  return (
    <div className="w-full m-10 dark:bg-gray-900 ">
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">Refunds</h2>
      <table className="w-full border-collapse border border-gray-300 dark:border-gray-700">
        <thead>
          <tr className="bg-gray-100 dark:bg-gray-800">
            <th className="border p-3">ID</th>
            <th className="border p-3">Amount</th>
            <th className="border p-3">Reason</th>
            <th className="border p-3">Status</th>
          </tr>
        </thead>
        <tbody>
          {refunds.map((refund) => (
            <tr key={refund.id} className="text-center">
              <td className="border p-3">{refund.id}</td>
              <td className="border p-3">{refund.amount}</td>
              <td className="border p-3">{refund.reason}</td>
              <td className={`border p-3 ${refund.status === "Processed" ? "text-green-500" : refund.status === "Pending" ? "text-yellow-500" : "text-red-500"}`}>
                {refund.status}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
       {
                      refunds.length < 1 && (
                      <NoSearchFound title="No Refund Requested yet!" />
                    )}
    </div>
  );
};

