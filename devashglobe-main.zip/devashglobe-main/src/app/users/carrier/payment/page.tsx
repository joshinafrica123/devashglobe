"use client";

import { useState } from "react";
// import { loadStripe } from "@stripe/stripe-js";

// const stripePromise = loadStripe("your_stripe_public_key_here");

const PaymentsPage = () => {
  const [amount, setAmount] = useState("");

  // const handlePayment = async () => {
  //   // const stripe = await stripePromise;

  //   // const response = await fetch("/api/checkout-session", {
  //   //   method: "POST",
  //   //   headers: { "Content-Type": "application/json" },
  //   //   body: JSON.stringify({ amount }),
  //   // });

  //   // const session = await response.json();

  //   // if (stripe) {
  //   //   stripe.redirectToCheckout({ sessionId: session.id });
  //   // }
  // };

  return (
    <div className="p-6 bg-white dark:bg-gray-900 shadow-md rounded-lg">
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">Payments</h2>
      <label className="block mb-2">Enter Amount ($):</label>
      <input
        type="number"
        className="w-full p-2 border rounded-md mb-4"
        placeholder="Enter amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <button  className="bg-green-500 text-white px-4 py-2 rounded">
        Pay with Stripe
      </button>
    </div>
  );
};

export default PaymentsPage;
