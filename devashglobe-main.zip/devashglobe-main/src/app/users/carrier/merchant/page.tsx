"use client";

import { apiCall, BASE_URL } from "@/app/core/api";
import { getCookie, isCookieValid } from "@/app/datatype/frontEndCookiee";
import { loadboard } from "@/app/datatype/loadboards";
import responce from "@/app/datatype/response";
import NoSearchFound from "@/components/notfound";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {  FaHeart } from "react-icons/fa";

export default function  TransactionsPage ()  {

const x : loadboard = {
  id: 0,
  account_id:0,
    type:"", 
    equipment_id:1, 
    date_upper_range:"", 
    date_lower_range:"",
    from_state:"",
    to_state:"",
    from_city:"",
    to_city:"",
    title:"",
    type_load:"",
    size:0,
    long_lat:"",
    price_upper_range:"",
    price_best_range:"",
    price_low_range:"",
    image:"",
    track_id: "",
    status: "",
    date: "",
    deleted: 0,
    updated_at: ""

};

   const [loadboards, setLoadboards] = useState<loadboard[]>([]);
  const [selectedLoad, setSelectedLoad] = useState<loadboard>(x);
  const [loading,setLoading] =useState(false);
  const [token,setToken] =useState("");
  const [errors,setErrors] = useState<string[]>([]);
  const [message,setMessages] =useState<string[]>([]);

  const router = useRouter();

    useEffect(() => {
      handleGetMerchant();

        const istoken = getCookie("token");

        if(istoken && istoken != "" && istoken != undefined){
          setToken(istoken+"")
        }else{
          router.push("/login")
        }

    }, []);
  

  const handleView = (load: loadboard) => {
          setSelectedLoad(load);
          console.log(selectedLoad);
          // setViewModalOpen(true);
          handleRequestAndAccept(token,load);
    };

  const handleRequestAndAccept = async (token:string,selectedLoadboard : loadboard)  => {

    if (!selectedLoadboard) return;

    console.log(token)

    setErrors([]);

    try {

      //check if the user is logged in
      if (!token || token === '' || token === 'undefined' || token == 'null'
        || !isCookieValid('token')) {
        console.error("User is not logged in or token is invalid.");
        router.push('/login');
        return;
      }

      // Check if the selected loadboard is valid
      if (!selectedLoadboard.id) {  
        console.error("Selected loadboard is invalid.");
        return;
      }

      if(errors.length == 0){

          const formData = new globalThis.FormData();
          formData.append('account_id', selectedLoadboard.account_id+"");
          formData.append('contract_type', selectedLoadboard.type);
          formData.append('object_id', selectedLoadboard.id+"");
          formData.append('description', `${selectedLoadboard.from_state} - ${selectedLoadboard.to_state} `);
          formData.append('delivery_time', `${selectedLoadboard.date_lower_range} - ${selectedLoadboard.date_upper_range} `);
          formData.append('payment',`${selectedLoadboard.price_upper_range} - ${selectedLoadboard.price_low_range} `);


          // Make the API call to request or accept the loadboard
          const response =  await apiCall(token + "", `${BASE_URL}/contracts`, "POST", formData);

          if (!response.ok) {
            throw new Error(`Failed to request: ${response.status}`);
          }
          const data = await response.json();
          const dataTypeed = data as responce;
          if (dataTypeed.error) {
            console.error("Error in response:", dataTypeed.error);
            setErrors([dataTypeed.error]);
          } else {
            console.log("Request successful:", dataTypeed);
            setMessages(["Request successful!"]);
            setTimeout(() => (
               setMessages([])
            ), 3000);

          }
      }


    } catch (error) {
      console.error("Request error:", error);
    }
  };

    async function handleGetMerchant() {
        setLoading(true)
        setErrors([]);

        try {
          const token = getCookie("token");

          // TODO MODIFY THIS END POINT 
          const response = await apiCall(token + "", `${BASE_URL}/merchant`, "GET", null);
        
          if (!response.ok) {
            throw new Error(`Failed to get : ${response.status}`);
          }
          const data = await response.json();
          const dataTypeed = data as responce;
          if (dataTypeed.error) {
            setErrors([dataTypeed.error]);         
            setLoading(false);
          } else {
              setLoadboards(dataTypeed.loadboard);
              setLoading(false);

          }
        } catch (error) {
          setLoading(false);
          console.error("faq error:", error);
          console.error("faq error:", errors);
        }
  }


  
  return (
    <div className="w-full m-10 dark:bg-gray-900 ">
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">Merchant Calls</h2>
      
      {
      message.length > 0 ? ( 
      <p className="absolute bg-[#0edb67f5] p-3 m-3 text-sm font-bold text-white rounded-sm border-2 border-[#16d50c]">
        {message.map((e) => (e) )}
          
      </p>
      ):(
        <></>
      )
}


   {/* Display Errors */}
            {errors.length > 0 && (
              <div className="text-sm text-red-600 dark:text-red-400 space-y-1">
            {errors.map((err, index) => (
              <p key={index}>• {err}</p>
            ))}
</div>)}


      <div className="overflow-x-auto rounded-2xl shadow-md border border-gray-200 dark:border-gray-700">
        <table className="w-full border-collapse text-sm text-gray-700 dark:text-gray-200">
          <thead>
            <tr className="bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300">
              <th className="p-3 text-left">ID</th>
              <th className="p-3 text-left">Date</th>
              <th className="p-3 text-left">Amount</th>
              <th className="p-3 text-left">Status</th>
              <th className="p-3 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={5} className="p-5 text-center text-gray-500">
                  Searching...
                </td>
              </tr>
            ) : (
              loadboards?.map((txn, idx) => (
                <tr
                  key={txn.id}
                  className={`text-center transition hover:bg-gray-50 dark:hover:bg-gray-700 ${
                    idx % 2 === 0 ? "bg-white dark:bg-gray-900" : "bg-gray-50 dark:bg-gray-800"
                  }`}
                >
                  <td className="p-3 font-medium">{txn.id}</td>
                  <td className="p-3">{txn.date}</td>
                  <td className="p-3 font-semibold">${txn.price_best_range}</td>
                  <td
                    className={`p-3 font-semibold ${
                      txn.status === "Completed"
                        ? "text-green-500"
                        : txn.status === "Pending"
                        ? "text-yellow-500"
                        : "text-red-500"
                    }`}
                  >
                    {txn.status === "0" ? "New" : txn.status}
                  </td>
                  <td className="p-3">
                    <button
                      onClick={() => handleView(txn)}
                      className="cursor-pointer  inline-flex items-center gap-2 rounded-xl bg-green-500 px-4 py-2 text-white shadow hover:bg-green-600 focus:ring-2 focus:ring-green-400 focus:outline-none transition"
                    >
                      {
                        !loading ? (
                          <><FaHeart className="text-sm" /> {`Accept`}
                          </> ):(
                        <>
                          seeding...
                        </>
                      )
                        }
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
          {
                              loadboards?.length < 1 && (
                              <NoSearchFound title="No Merchant call yet!" />
                            )}
      </div>

    </div>
  );
};

