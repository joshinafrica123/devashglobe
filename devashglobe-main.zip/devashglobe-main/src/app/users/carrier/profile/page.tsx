import Image from 'next/image'

export default function  ProfileCard () {

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Profile Info Card */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="flex flex-col items-center text-center">
          <Image
            src="/assets/img/users/2.jpg"
            alt="Admin"
            width={110}
            height={110}
            className="rounded-full p-1 border-4 border-[#D62D30]"
          />
          <div className="mt-4">
            <h4 className="text-xl font-semibold text-gray-900 dark:text-white">Ash Admin</h4>
            <p className="text-gray-600 dark:text-gray-300">Supper Admin</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Bay Area, San Francisco, CA</p>
            <div className="flex gap-2 mt-3 content-center">
              <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-1 rounded">Edit +</button>
              <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-1 rounded">close page</button>
            </div>
          </div>
        </div>

        <hr className="my-6 border-gray-300 dark:border-gray-700" />

        <ul className="space-y-4">
          {[
            { label: 'Website', value: '#' },
            { label: 'Github', value: 'codervent' },
            { label: 'Twitter', value: '@codervent' },
            { label: 'Instagram', value: 'codervent' },
            { label: 'Facebook', value: 'codervent' },
          ].map((item, idx) => (
            <li key={idx} className="flex justify-between items-center text-gray-700 dark:text-gray-300">
              <h6 className="font-semibold">{item.label}</h6>
              <span className="text-sm text-gray-600 dark:text-white">{item.value}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Settings Form */}
      <div className="lg:col-span-2 space-y-4">
        <form action="../admin/settings">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            {[
                { label: 'Full Name', value: 'John Doe' },
                { label: 'Email', value: 'john@example.com' },
                { label: 'Phone', value: '(239) 816-9029' },
                { label: 'Mobile', value: '(320) 380-4539' },
                { label: 'Address', value: 'Bay Area, San Francisco, CA' },
            ].map((field, idx) => (
                <div className="flex flex-col md:flex-row mb-4" key={idx}>
                <div className="w-full md:w-1/3 mb-1 md:mb-0">
                    <label className="text-gray-700 dark:text-gray-300 font-medium">{field.label}</label>
                </div>
                <div className="w-full md:w-2/3">
                    <input
                    type="text"
                    defaultValue={field.value}
                    disabled
                    className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                </div>
                </div>
            ))}

            <div className="flex justify-end">
                <button className="bg-[#D62D30] text-white px-6 py-2 rounded hover:bg-[#b92125] transition"> Update Info</button>
            </div>
            </div>
        </form>
        {/* Progress Section */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h5 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Project Status</h5>
          {[
            { label: 'Web Design', value: 80 },
            { label: 'Website Markup', value: 72 },
            { label: 'One Page', value: 89 },
            { label: 'Mobile Template', value: 55 },
            { label: 'Backend API', value: 66 },
          ].map((task, idx) => (
            <div key={idx} className="mb-4">
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-1">{task.label}</p>
              <div className="w-full bg-gray-200 rounded h-2">
                <div
                  className="h-2 rounded"
                  style={{ width: `${task.value}%`, backgroundColor: '#06163A' }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}


