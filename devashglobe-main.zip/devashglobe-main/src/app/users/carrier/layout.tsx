import Sidebar from "../../includes/users/Sidebar";
import TopNav from "../../includes/users/TopNav";

export default function UserLayout( {children,}: Readonly<{children: React.ReactNode;}> ) {
  
  return ( 
    <div className="flex h-screen bg-gray-100 ">
      {/* flex h-screen bg-gray-100 */}
    {/*  */}

    <div className="flex-1 flex flex-col overflow-hidden">
    {/* flex flex-col flex-1 */}
      <TopNav />
      <main className="flex gap-1 overflow-x-hidden overflow-y-auto ">
        <Sidebar />
        {children}
               
      </main>

    </div>

  </div>
        
  );
}