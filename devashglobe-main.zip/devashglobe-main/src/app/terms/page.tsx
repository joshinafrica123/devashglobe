"use client";

import Link from "next/link";

export default function TermsAndConditions() {
  return (
    <div>
      <section
        className="relative  py-15 bg-transparent"
        // style={{ backgroundImage: `url(/assets/img/banner/ash-slider.jpg)` }}
      >
        <span className="absolute inset-0 bg-transparent] opacity-50"></span>
        <div className="container mx-auto relative z-10 text-center"></div>
        <div className="absolute bottom-18.5  left-0 w-50 h-50"></div>
      </section>

      <div className="bg-gray-50 text-gray-800 px-6 md:px-16 lg:px-32 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <h1 className="text-3xl md:text-4xl font-bold text-[#06163A] mb-6">
            Terms & Conditions
          </h1>
          <p className="text-gray-600 mb-10">Effective Date: January 1, 2025</p>

          {/* Intro */}
          <p className="mb-6 leading-relaxed">
            Welcome to <span className="font-semibold"> Ash globe </span>. These
            Terms and Conditions govern your access to and use of our logistics
            web application, services, and features. By using our platform, you
            agree to comply with and be bound by these Terms. If you do not
            agree, you must not use our services.
          </p>

          {/* Section 1 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            1. Eligibility
          </h2>
          <p className="mb-6">
            By accessing our platform, you confirm that you are at least 18
            years old and have the legal authority to enter into these Terms. If
            you are using the platform on behalf of a company, you represent
            that you have the authority to bind that company to these Terms.
          </p>

          {/* Section 2 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            2. Account Registration
          </h2>
          <p className="mb-4">To access certain features, you must:</p>
          <ul className="list-disc list-inside mb-6 space-y-2">
            <li>Provide accurate and complete registration information.</li>
            <li>Maintain the confidentiality of your login credentials.</li>
            <li>
              Accept responsibility for all activities under your account,
              whether authorized by you or not.
            </li>
            <li>
              Notify us immediately if you suspect unauthorized access to your
              account.
            </li>
          </ul>

          {/* Section 3 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            3. Use of Services
          </h2>
          <p className="mb-4">
            You agree to use our platform only for lawful purposes. You must
            not:
          </p>
          <ul className="list-disc list-inside mb-6 space-y-2">
            <li>Violate any applicable laws or regulations.</li>
            <li>
              Post false, misleading, or fraudulent load or truck information.
            </li>
            <li>
              Interfere with the operation, security, or integrity of our
              platform.
            </li>
            <li>Attempt to access restricted areas without authorization.</li>
            <li>
              Resell, sublicense, or exploit our services for unauthorized
              purposes.
            </li>
          </ul>

          {/* Section 4 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            4. Payments & Transactions
          </h2>
          <p className="mb-6">
            Certain services may require payment. By making a payment, you agree
            to provide accurate billing information and authorize us or our
            third-party payment processors to charge your account. All fees are
            non-refundable unless otherwise stated.
          </p>

          {/* Section 5 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            5. Content & Intellectual Property
          </h2>
          <p className="mb-6">
            All materials on our platform, including software, design, logos,
            and trademarks, are owned or licensed by{" "}
            <span className="font-semibold"> Ash globe ]</span>. You are granted
            a limited, non-exclusive, non-transferable license to use our
            services for your business needs. Unauthorized reproduction or
            distribution is strictly prohibited.
          </p>

          {/* Section 6 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            6. Third-Party Services
          </h2>
          <p className="mb-6">
            Our platform may integrate with third-party services. We are not
            responsible for the availability, content, or practices of such
            services. Your use of third-party services is subject to their own
            terms and policies.
          </p>

          {/* Section 7 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            7. Disclaimer of Warranties
          </h2>
          <p className="mb-6">
            Our services are provided on an “as-is” and “as-available” basis
            without warranties of any kind, whether express or implied. We do
            not guarantee uninterrupted, secure, or error-free service, nor do
            we guarantee the accuracy of information provided by users of the
            platform.
          </p>

          {/* Section 8 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            8. Limitation of Liability
          </h2>
          <p className="mb-6">
            To the maximum extent permitted by law,{" "}
            <span className="font-semibold"> Ash globe ]</span> shall not be
            liable for any indirect, incidental, special, or consequential
            damages arising from your use of our services, including but not
            limited to loss of profits, data, or business opportunities.
          </p>

          {/* Section 9 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            9. Termination
          </h2>
          <p className="mb-6">
            We reserve the right to suspend or terminate your access to our
            platform at our discretion, without notice, if you violate these
            Terms, misuse our services, or engage in harmful activities.
          </p>

          {/* Section 10 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            10. Governing Law
          </h2>
          <p className="mb-6">
            These Terms shall be governed by and construed under the laws of the
            jurisdiction in which{" "}
            <span className="font-semibold">[Your Company Name]</span> operates,
            without regard to its conflict of law principles. Any disputes shall
            be resolved exclusively in the courts of that jurisdiction.
          </p>

          {/* Section 11 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            11. Changes to These Terms
          </h2>
          <p className="mb-6">
            We may revise these Terms from time to time. Updated versions will
            be posted on this page with the revised “Effective Date.” Continued
            use of our platform after changes means you accept the updated
            Terms.
          </p>

          {/* Section 12 */}
          <h2 className="text-xl md:text-2xl font-semibold text-[#06163A] mb-4">
            12. Contact Us
          </h2>
          <p className="mb-6">
            If you have questions about these Terms & Conditions, please contact
            us at:
          </p>
          <p className="mb-2">
            <span className="font-medium">Email:</span> info@ashglobe.uk.com
          </p>
          <p className="mb-10">
            <span className="font-medium">Address:</span> United State 5 West
            Mendenhall Street, Bozeman, MT, 59715
          </p>

          {/* Back Link */}
          <Link
            href="/"
            className="text-[#D62D30] font-semibold hover:underline"
          >
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
