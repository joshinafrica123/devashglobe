import type { Metadata } from "next";

import Footer from "../includes/footer";

import "../globals.css";
import Header from "../includes/header";


export const metadata: Metadata = {
  title: "AshGlobe Logistics",
  description: "Smart Logistics on smart contracts",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
        <>
        <Header isHome={false}/>
        {children}
        <Footer />
    </>
  );
}
