import SignInForm from "@/components/users/signinComponent";
// import Image from "next/image";

export default function Login() {
  return (
    <div className="min-h-screen grid bg-[#10429a3d]">
      <div className="flex items-center justify-center p-6  dark:bg-gray-950">
        <SignInForm />
      </div>
      {/* <div className="hidden md:block relative">
        <Image
          src="/assets/img/sign/1si.jpg" // place this image inside /public/images/
          alt="Login banner"
          fill
          className="object-cover"
        />
      </div> */}
    </div>
  );
}
