"use client";
import {
  BadgeCheck,
  ChevronDown,
  Clock,
  CreditCard,
  // Crown,
  // Search,
  // ShieldCheck,
  // Truck,
} from "lucide-react";
import Image from "next/image";
import { useState } from "react";
import Vendor from "../datatype/vendor";
import VendorModal from "@/components/loadboardModal";

interface MerchantCardProps {
  name: string;
  badge?: string;
  status: "online" | "offline" | string;
  transactions: number;
  completion: number;
  time: string;
  price: string;
  available: string;
  orderLimit: string;
  payments: string[];
  action?: "Request" | "Accept";
  owned: string;
  setOpen: (x: boolean) => void;
  setOpenModal: (x: boolean) => void;
}

const sortOptions = [
  { label: "Sort by", value: "" },
  { label: "Price: Low to High", value: "price-asc" },
  { label: "Price: High to Low", value: "price-desc" },
  { label: "Total Completed", value: "completed" },
];

const tokens = [
  { name: "BTC", icon: "/assets/img/toberemoved/btc.webp" },
  { name: "ETH", icon: "/assets/img/toberemoved/eth.webp" },
  { name: "USDC", icon: "/assets/img/toberemoved/usds.webp" },
  { name: "USDT", icon: "/assets/img/toberemoved/1.png" },
];

const countries = [
  { code: "GHS", name: "Ghana Cedi", flag: "/assets/img/toberemoved/2.png" },
  {
    code: "NGN",
    name: "Nigeria Naira",
    flag: "/assets/img/toberemoved/ng.png",
  },
  {
    code: "KES",
    name: "Kenya Shilling",
    flag: "/assets/img/toberemoved/ke.png",
  },
  {
    code: "ZAR",
    name: "South Africa Rand",
    flag: "/assets/img/toberemoved/sa.png",
  },
  { code: "XOF", name: "USA Dollar", flag: "/assets/img/toberemoved/us.png" },
  { code: "EUR", name: "China Yen", flag: "/assets/img/toberemoved/chi.svg" },
  {
    code: "GBP",
    name: "British Pound",
    flag: "/assets/img/toberemoved/uk.png",
  },
];

const MerchantCard = ({
  name,
  badge,
  status,
  transactions,
  completion,
  time,
  price,
  available,
  orderLimit,
  payments,
  action = "Accept",
  owned,
  setOpenModal = (x: boolean) => {
    setOpenModal(!x);
  },
}: MerchantCardProps) => {
  return (
    <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800 transition flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
      {/* Left section (Name + Badge + Status) */}
      <div
        className="flex items-center justify-between sm:justify-start gap-2 sm:w-1/6 cursor-pointer"
        onClick={() => setOpenModal(true)}
      >
        <h3 className="text-sm font-semibold">
          {name} <span className="text-xs text-[#D62D30] text">{owned}</span>
        </h3>
        {badge && <BadgeCheck className="w-4 h-4 text-yellow-500" />}
        <span
          className={`text-xs px-2 py-1 rounded-full ${
            status === "online"
              ? "bg-green-100 text-green-700"
              : "bg-gray-200 text-gray-600"
          }`}
        >
          {status}
        </span>
      </div>

      {/* Price (prominent on mobile, aligned on desktop) */}
      <div
        className="text-sm font-bold text-[#D62D30] sm:w-1/12 cursor-pointer"
        onClick={() => setOpenModal(true)}
      >
        {price}
      </div>

      {/* Metrics */}
      <div
        className="flex flex-col text-xs text-gray-600 dark:text-gray-300 sm:w-2/12 cursor-pointer"
        onClick={() => setOpenModal(true)}
      >
        <span>{transactions} txns</span>
        <span>{completion}% complete</span>
        <span className="flex items-center gap-1">
          <Clock className="w-3 h-3" /> {time}
        </span>
      </div>

      {/* Availability */}
      <div className="text-xs sm:w-2/12">
        <span className="block">Available: {available}</span>
        <span className="block">Limit: {orderLimit}</span>
      </div>

      {/* Payment Methods */}
      <div className="flex flex-wrap gap-1 sm:w-2/12">
        {payments.map((method, idx) => (
          <span
            key={idx}
            className="flex items-center gap-1 text-xs bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded-md"
          >
            <CreditCard className="w-3 h-3" /> {method}
          </span>
        ))}
      </div>

      {/* Action Button (full width on mobile, right aligned on desktop) */}
      <div className="flex sm:w-1/12 sm:justify-end">
        <button className="w-full sm:w-auto bg-[#D62D30] text-white px-3 py-2 rounded-md text-xs hover:bg-[#b92124] transition">
          {action}
        </button>
      </div>
    </div>
  );
};

export default function Loadboard() {
  const [activeTab, setActiveTab] = useState("load");
  const [selected, setSelected] = useState(tokens[3]); // default USDT
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [selectedCounties, setSelectedCounties] = useState(countries[0]); // default GHS
  const [opencountries, setOpenCounties] = useState(false);
  const [sortSelected, setSortSelected] = useState(sortOptions[0]);
  const [sortOpen, setSortOpen] = useState(false);
  const [openModal, setOpenModal] = useState(false);

  const merchants: MerchantCardProps[] = [
    {
      name: "MAJESTY-ENT",
      badge: "Super Merchant",
      status: "online",
      transactions: 311,
      completion: 83.6,
      time: "15 min",
      price: "13.15 GHS",
      available: "180.5 USDT",
      orderLimit: "50 – 2,373.57 GHS",
      payments: ["Ash Wallet"],
      action: "Request",
      owned: "15 trucks",
      setOpen: (x: boolean) => {
        console.log(x);
      },
      setOpenModal: () => {
        setOpenModal((x) => !x);
      },
    },
    {
      name: "PAACLE",
      badge: "Super Merchant",
      status: "online",
      transactions: 307,
      completion: 96.23,
      time: "15 min",
      price: "13.15 GHS",
      available: "2,000 USDT",
      orderLimit: "500 – 26,300 GHS",
      payments: ["Ash Wallet", "Wire Transfer"],
      action: "Accept",
      owned: "6 load",
      setOpen: (x: boolean) => {
        console.log(x);
      },
      setOpenModal: () => {
        setOpenModal((x) => !x);
      },
    },
    {
      name: "Asasewura",
      badge: "Super Merchant",
      status: "online",
      transactions: 10449,
      completion: 97.21,
      time: "15 min",
      price: "13.15 GHS",
      available: "374.78 USDT",
      orderLimit: "100 – 4,928.35 GHS",
      payments: ["Ash Wallet"],
      action: "Request",
      owned: "12 truck",
      setOpen: (x: boolean) => {
        console.log(x);
      },
      setOpenModal: () => {
        setOpenModal((x) => !x);
      },
    },
  ];

  const vendor: Vendor = {
    name: "Swift Logistics Co.",
    verified: true,
    rating: 4.8,
    trucks: 12,
    loads: 250,
    successRate: 98,
    deliveryRate: 95,
    bio: "Specialists in nationwide freight delivery.",
    avatarUrl: "https://randomuser.me/api/portraits/men/40.jpg",
  };

  const prices = { min: 120, max: 200 };

  const handleBuy = (prices: number) => {
    alert(`Purchase started at $${prices}`);
  };

  // const features = [
  //   {
  //     icon: <ShieldCheck className="w-8 h-8 text-[#D62D30]" />,
  //     title: "Secure Loads",
  //     desc: "Verified shippers and carriers ensure safe transactions.",
  //   },
  //   {
  //     icon: <Truck className="w-8 h-8 text-[#D62D30]" />,
  //     title: "Fleet Ready",
  //     desc: "Easily manage multiple trucks and drivers in one place.",
  //   },
  //   {
  //     icon: <Search className="w-8 h-8 text-[#D62D30]" />,
  //     title: "Smart Search",
  //     desc: "Filter loads by origin, destination, and equipment type.",
  //   },
  //   {
  //     icon: <Crown className="w-8 h-8 text-[#D62D30]" />,
  //     title: "Premium Access",
  //     desc: "Get priority posting and unlimited searches with premium.",
  //   },
  // ];

  return (
    <>
      {/* banner component */}
      <section
        className="relative  py-15 bg-transparent"
        // style={{ backgroundImage: `url(/assets/img/banner/ash-slider.jpg)` }}
      >
        <span className="absolute inset-0 bg-transparent] opacity-50"></span>
        <div className="container mx-auto relative z-10 text-center"></div>
        <div className="absolute bottom-18.5  left-0 w-50 h-50"></div>
      </section>

      <section className="py-16 bg-gradient-to-r  text-[#06163A]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-left mb-5">P2p Load board</h2>
          <p className="mb-5">A safe space for all shippers and carriers </p>

          {/* Wrapper for scroll on mobile */}
          {/* <div className="flex gap-6 overflow-x-auto md:grid md:grid-cols-4 md:gap-8 scrollbar-hide">
            {features.map((item, index) => (
              <div
                key={index}
                className="min-w-[250px] md:min-w-0 bg-[#06163A] text-[#FFF] rounded-2xl shadow-lg p-6 flex flex-col items-center text-center hover:scale-105 transition-transform"
              >
                <div className="mb-4">{item.icon}</div>
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-sm text-[#FFF]">{item.desc}</p>
              </div>
            ))}
          </div> */}
        </div>
      </section>

      <section className="w-4/5 bg-white dark:bg-gray-900 rounded-2xl shadow-lg p-4 m-auto items-center">
        {/* Tabs + Create Ad */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex gap-3">
            <button
              onClick={() => setActiveTab("load")}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                activeTab === "load"
                  ? "bg-gradient-to-r from-[#D62D30] to-[#F76C6C] text-white shadow-md"
                  : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300"
              }`}
            >
              Load
            </button>
            <button
              onClick={() => setActiveTab("truck")}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                activeTab === "truck"
                  ? "bg-gradient-to-r from-[#D62D30] to-[#F76C6C] text-white shadow-md"
                  : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300"
              }`}
            >
              Truck
            </button>
          </div>

          {/* <button className="hidden lg:flex items-center gap-2 bg-gradient-to-r from-[#06163A] to-[#0B234F] text-white px-4 py-2 rounded-full font-medium shadow hover:opacity-90 transition">
            <Plus className="w-4 h-4" /> Create Ad
          </button> */}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 items-center justify-between">
          <div className="flex flex-wrap gap-4 items-center">
            {/* Select: Crypto */}
            <div className="relative">
              {/* Trigger */}
              <div
                onClick={() => setOpen(!open)}
                className="flex items-center gap-2 px-3 py-2 rounded-lg border bg-white dark:bg-gray-800 shadow-sm cursor-pointer"
              >
                <Image
                  src={selected.icon}
                  alt={selected.name}
                  width={20}
                  height={20}
                  className="rounded-full"
                />
                <span className="text-sm font-medium">{selected.name}</span>
                <ChevronDown
                  className={`w-4 h-4 ml-1 text-gray-400 transition-transform ${
                    open ? "rotate-180" : ""
                  }`}
                />
              </div>

              {/* Dropdown */}
              {open && (
                <div className="absolute mt-2 w-40 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-20">
                  {tokens.map((token) => (
                    <div
                      key={token.name}
                      onClick={() => {
                        setSelected(token);
                        setOpen(false);
                      }}
                      className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800"
                    >
                      <Image
                        src={token.icon}
                        alt={token.name}
                        width={20}
                        height={20}
                        className="rounded-full"
                      />
                      <span className="text-sm">{token.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Input with currency select */}
            <div className="relative flex items-center px-3 py-2 rounded-lg border bg-white dark:bg-gray-800 shadow-sm">
              {/* Input field */}
              <input
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="flex-1 bg-transparent outline-none text-sm text-gray-700 dark:text-gray-200"
              />

              {/* Dropdown trigger */}
              <div
                onClick={() => setOpenCounties(!opencountries)}
                className="flex items-center gap-1 ml-2 cursor-pointer"
              >
                <Image
                  src={selectedCounties.flag}
                  alt={selectedCounties.code}
                  width={20}
                  height={20}
                  className="rounded-full"
                />
                <span className="text-sm font-medium">
                  {selectedCounties.code}
                </span>
                <ChevronDown
                  className={`w-4 h-4 text-gray-400 transition-transform ${
                    opencountries ? "rotate-180" : ""
                  }`}
                />
              </div>

              {/* Dropdown list */}
              {opencountries && (
                <div className="absolute right-0 top-12 w-48 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-20">
                  {countries.map((c) => (
                    <div
                      key={c.code}
                      onClick={() => {
                        setSelectedCounties(c);
                        setOpenCounties(false);
                      }}
                      className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800"
                    >
                      <Image
                        src={c.flag}
                        alt={c.code}
                        width={20}
                        height={20}
                        className="rounded-full"
                      />
                      <span className="text-sm">
                        {c.name} ({c.code})
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Payment Method */}
          <div className="relative">
            {/* Trigger */}
            <div
              onClick={() => setSortOpen(!sortOpen)}
              className="flex items-center px-3 py-2 rounded-lg border bg-white dark:bg-gray-800 shadow-sm cursor-pointer"
            >
              <span className="text-sm text-gray-600 dark:text-gray-300">
                {sortSelected.label}
              </span>
              <ChevronDown
                className={`w-4 h-4 ml-2 text-gray-400 transition-transform ${
                  sortOpen ? "rotate-180" : ""
                }`}
              />
            </div>

            {/* Dropdown */}
            {sortOpen && (
              <div className="absolute mt-2 w-48 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-20">
                {sortOptions.map((option) => (
                  <div
                    key={option.value}
                    onClick={() => {
                      setSortSelected(option);
                      setSortOpen(false);
                    }}
                    className="px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800"
                  >
                    {option.label}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Timeout */}
          {/* <div className="hidden lg:flex items-center px-3 py-2 rounded-lg border bg-white dark:bg-gray-800 shadow-sm cursor-pointer">
            <span className="text-sm text-gray-600 dark:text-gray-300">
              Payment timeout
            </span>
            <ChevronDown className="w-4 h-4 ml-2 text-gray-400" />
          </div> */}

          {/* Filter Icon (mobile / desktop)
          <button className="flex items-center justify-center w-10 h-10 rounded-full border shadow-sm bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
            <Filter className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button> */}
        </div>
      </section>
      <main className="py-8 px-4 bg-gradient-to-b  min-h-screen">
        <section className="max-w-6xl mx-auto">
          <div className="flex flex-col divide-y divide-gray-200 dark:divide-gray-700">
            {merchants.map((merchant, idx) => (
              <MerchantCard key={idx} {...merchant} />
            ))}
          </div>

          {/* Vendor Modal */}
          <VendorModal
            isOpen={openModal}
            onClose={() => setOpenModal(false)}
            vendor={vendor}
            prices={prices}
            onBuy={handleBuy}
            theme="light"
          />
        </section>
      </main>
    </>
  );
}
