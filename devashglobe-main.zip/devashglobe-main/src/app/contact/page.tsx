"use client";


import { motion } from "framer-motion";
import BannerComponent from "@/components/bannerComponent";
import TestimonialComponent from "@/components/testimonialComponent";
import GoogleMap from "@/components/googleMap";
import FreightForm from "@/components/loadBoardNavComponent";

export default function Contact() {
  // const [darkMode, setDarkMode] = useState(true);

  // useEffect(() => {
  //   const savedTheme = localStorage.getItem("theme");
  //   if (savedTheme === "dark") setDarkMode(true);
  // }, []);

  // const toggleDarkMode = () => {
  //   setDarkMode((prev) => !prev);
  //   console.log(darkMode)
  //   localStorage.setItem("theme", darkMode ? "light" : "dark");
  // };

  return (
    <>
      {/* banner component */} 
      <BannerComponent backgroudImage = "/assets/img/banner/1.avif" pageTitle = "Contact us" bannerImage = "/assets/img/banner/pm-bg.png"/>   

      <div className="dark">
        <div className="py-24 bg-gray-100 dark:bg-[#06163A] ">
          <div className="container mx-auto px-4">
            {/* Dark Mode Toggle */}
            <div className="text-right mb-4">
              {/* <button
                onClick={toggleDarkMode}
                className="bg-[#D62D30] text-white px-4 py-2 rounded-md shadow-md hover:bg-red-700 transition"
              >
                {darkMode ? "Light Mode ☀️" : "Dark Mode 🌙"}
              </button>  */}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="grid md:grid-cols-2 bg-white dark:bg-gray-900 shadow-lg rounded-lg p-8 text-gray-900 dark:text-white"
            >
              {/* Contact Info Section */}
              <div className="flex flex-col justify-center items-center h-full space-y-8">
                <h2 className="text-3xl font-bold text-left">Contact Information</h2>

                {[ 
                  { title: "Address", icon: "📍", info: "United Kingdom 21st Floor, City Tower, Manchester M1 4BT, United Kingdom" },
                  { title: "Phone", icon: "📞", info: "+44 7719 262478" },
                  { title: "Email", icon: "📧", info: "info@ashglobe.uk.com" },
                  { title: "Working Hours", icon: "⏰", info: "Mon-Fri: 8am - 6pm (PST)" },
                  { title: "Support", icon: "🛠️", info: "Live Chat & 24/7 Email Support" },
                  { title: "Social Media", icon: "🌐", info: "Twitter: @ashglobe | LinkedIn: AshGlobe Inc." },
                  { title: "WhatsApp", icon: "💬", info: "+1 234 567 8901" },
                ].map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.15 }}
                    className="flex  space-x-4 w-full s"
                  >
                    <div className="text-[#D62D30] text-2xl">{item.icon}</div>
                    <div>
                      <h5 className="font-bold text-lg">{item.title}</h5>
                      <p className="text-gray-600 dark:text-gray-300">{item.info}</p>
                    </div>
                  </motion.div>
                ))}

                <div className="mt-6 text-center">
                  <h4 className="font-semibold text-[#D62D30]">{`We can't wait to hear from you!`}</h4>
                  <p className="text-gray-700 dark:text-gray-300">For partnership, business, or press inquiries, please email <span className="font-semibold">contact@ashglobe.com</span> or use the form.</p>
                </div>
              </div>

              {/* Contact Form */}
                <FreightForm />
            </motion.div>

            <GoogleMap />

            {/* Swiper Carousel for Testimonials */}
            <TestimonialComponent />

          </div>
        </div>
      </div>
    </>
  );
}