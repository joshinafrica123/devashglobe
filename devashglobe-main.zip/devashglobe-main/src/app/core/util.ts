import { loadboard } from "../datatype/loadboards";
import { GetLoadBorad } from "./api";

export const openMap = (lat_long: string) => {
  const url = `https://www.google.com/maps?q=${lat_long}`;
  window.open(url, "_blank"); // opens in new tab
};

export function filterLoadboardByType(
  loadboards: loadboard[],
  type: string
): loadboard[] {
  return loadboards.filter((lb) => lb.type === type);
}

export const validLongLat = (longlat: string) => {
  if (!longlat) return false;

  const parts = longlat.split(",").map((p) => p.trim());
  if (parts.length !== 2) return false;

  const lat = parseFloat(parts[0]);
  const lng = parseFloat(parts[1]);

  const isValidLat = lat >= -90 && lat <= 90;
  const isValidLng = lng >= -180 && lng <= 180;

  return isValidLat && isValidLng;
};

export interface dDetails {
  transaction: 0;
  pending: 0;
  refund: 0;
}

export const dashboardDetails: dDetails = {
  transaction: 0,
  pending: 0,
  refund: 0,
};

export interface PaymentPayload {
  holder: string;
  number: string;
  expiry: string;
  cvv: string;
  merchant: string;
  reference: string;
  amount: number;
}

export interface FormData {
  email: string;
  user_type: string;
  business_type: string;
  password: string;
  confirm_password: string;
}

export const validatePhone = (phone: string): string[] => {
  const errorList: string[] = [];
  const phoneRegex = /^(\+?\d{1,3}[- ]?)?(0\d{1,14}|\d{1,14})$/; // Adjust regex as per your phone number format
  if (!phoneRegex.test(phone)) {
    errorList.push(
      "Invalid phone number format. Please enter a 10-digit number."
    );
  }
  return errorList;
};

export const validateEmail = (email: string): string[] => {
  const errorList: string[] = [];
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Basic email validation regex
  if (!emailRegex.test(email)) {
    errorList.push("Invalid email format.");
  }
  return errorList;
};

export const validatePassword = (password: string): string[] => {
  const errorList: string[] = [];
  if (password.length < 8) errorList.push("Minimum 8 characters required.");
  if (!/[A-Z]/.test(password))
    errorList.push("At least one uppercase letter required.");
  if (!/[0-9]/.test(password)) errorList.push("At least one number required.");
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password))
    errorList.push("At least one special character required.");
  return errorList;
};

export const i: dataStat[] = [
  { month: "Jan", trucks: 0, loads: 0 },
  { month: "Feb", trucks: 0, loads: 0 },
  { month: "Mar", trucks: 0, loads: 0 },
  { month: "Apr", trucks: 0, loads: 0 },
  { month: "May", trucks: 0, loads: 0 },
  { month: "Jun", trucks: 0, loads: 0 },
  { month: "Jul", trucks: 0, loads: 0 },
  { month: "Aug", trucks: 0, loads: 0 },
  { month: "Sep", trucks: 0, loads: 0 },
  { month: "Oct", trucks: 0, loads: 0 },
  { month: "Nov", trucks: 0, loads: 0 },
  { month: "Dec", trucks: 0, loads: 0 },
];

export interface dataStat {
  month: string;
  trucks: number;
  loads: number;
}

export const handleSetTructStat = (
  loadboard: GetLoadBorad,
  type: string
): dataStat[] => {
  console.log(loadboard.body);

  const truckTrack: loadboard[] = loadboard.body as loadboard[];
  const x: string[] = [];

  console.log(truckTrack);

  truckTrack.forEach((e) => {
    const y = e.date.split("-")[1];
    console.log(y);

    //  for truck
    if (type == "truck") {
      if (!x.includes(y)) {
        x.push(y);
        switch (y) {
          case "01":
            i[0].trucks += 1;
            break;
          case "02":
            i[1].trucks += 1;
            break;
          case "03":
            i[2].trucks += 1;
            break;
          case "04":
            i[3].trucks += 1;
            break;
          case "05":
            i[4].trucks += 1;
            break;
          case "06":
            i[5].trucks += 1;
            break;
          case "07":
            i[6].trucks += 1;
            break;
          case "08":
            i[7].trucks += 1;
            break;
          case "09":
            i[8].trucks += 1;
            break;
          case "10":
            i[9].trucks += 1;
            break;
          case "11":
            i[10].trucks += 1;
            break;
          case "12":
            i[11].trucks += 1;
            break;

          default:
            break;
        }
      } else {
        switch (y) {
          case "01":
            i[0].trucks += 1;
            break;
          case "02":
            i[1].trucks += 1;
            break;
          case "03":
            i[2].trucks += 1;
            break;
          case "04":
            i[3].trucks += 1;
            break;
          case "05":
            i[4].trucks += 1;
            break;
          case "06":
            i[5].trucks += 1;
            break;
          case "07":
            i[6].trucks += 1;
            break;
          case "08":
            i[7].trucks += 1;
            break;
          case "09":
            i[8].trucks += 1;
            break;
          case "10":
            i[9].trucks += 1;
            break;
          case "11":
            i[10].trucks += 1;
            break;
          case "12":
            i[11].trucks += 1;
            break;

          default:
            break;
        }
      }
    }
    // for loads
    if (type == "load") {
      if (!x.includes(y)) {
        x.push(y);
        switch (y) {
          case "01":
            i[0].loads += 1;
            break;
          case "02":
            i[1].loads += 1;
            break;
          case "03":
            i[2].loads += 1;
            break;
          case "04":
            i[3].loads += 1;
            break;
          case "05":
            i[4].loads += 1;
            break;
          case "06":
            i[5].loads += 1;
            break;
          case "07":
            i[6].loads += 1;
            break;
          case "08":
            i[7].loads += 1;
            break;
          case "09":
            i[8].loads += 1;
            break;
          case "10":
            i[9].loads += 1;
            break;
          case "11":
            i[10].loads += 1;
            break;
          case "12":
            i[11].loads += 1;
            break;

          default:
            break;
        }
      } else {
        switch (y) {
          case "01":
            i[0].loads += 1;
            break;
          case "02":
            i[1].loads += 1;
            break;
          case "03":
            i[2].loads += 1;
            break;
          case "04":
            i[3].loads += 1;
            break;
          case "05":
            i[4].loads += 1;
            break;
          case "06":
            i[5].loads += 1;
            break;
          case "07":
            i[6].loads += 1;
            break;
          case "08":
            i[7].loads += 1;
            break;
          case "09":
            i[8].loads += 1;
            break;
          case "10":
            i[9].loads += 1;
            break;
          case "11":
            i[10].loads += 1;
            break;
          case "12":
            i[11].loads += 1;
            break;

          default:
            break;
        }
      }
    }
  });

  console.log(i);

  return i;
};
