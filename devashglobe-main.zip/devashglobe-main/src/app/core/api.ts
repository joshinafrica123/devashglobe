import { loadboard } from "../datatype/loadboards";
import responce from "../datatype/response";

export async function apiCall (token:string,url:string,method:string,formData: FormData | null) {
    
              if(method.toUpperCase() === 'GET'){
                                // get from api
                return await fetch(url, {
                  method: method.toUpperCase(),
                    headers:{
                  'Authorization': `Bearer ${token}`, 
                  }
                });
            }else{

                // save truck; send to api
                return await fetch(url, {
                  method: method.toUpperCase(),
                    headers:{
                  'Authorization': `Bearer ${token}`, 
                  },
                 body: formData, // FormData handles content-type automatically
                });


            }


}

export interface GetLoadBorad {
    status:boolean,
    body:loadboard[] | string[]
} 


export async  function getLoadLoadBoard  (token:string,url:string)  {
  
    try {

            // save truck; send to api
                const response = await apiCall(token+"",url,'GET',null);

              if (!response.ok) {
                  throw new Error(`Failed to load truck: ${response.status}`);
              }

              const data = await response.json();

              console.log(data);
    
              const dataTypeed = (data as responce);

                if(dataTypeed.error){
                      const errList : string[] = [dataTypeed.error]
                      const c : GetLoadBorad = {
                        status :false,
                        body:errList
                      }
                      return c;
                    }else{
                      console.log(dataTypeed.loadboard);
                      const d : loadboard[]= dataTypeed.loadboard ;
                    return {status:true,body:d} as GetLoadBorad
                    
                      
                    }
                  
                  


    } catch (error) {
      console.error('loadboards error:', error);
      const dataTypeed = (error as responce);
      if(dataTypeed.error){
         const errList : string[] = [dataTypeed.error]
        return {status:false, body:errList} as GetLoadBorad;
    
      }
    }



} 



// GET BASE API URL FROM .ENV
export const BASE_URL = process.env.NEXT_PUBLIC_BASE_API_URL;