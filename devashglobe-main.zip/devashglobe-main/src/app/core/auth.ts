"use server";
import { cookies } from "next/headers";


export async function setCookie(title:string,value:string) {
    (await cookies()).set(title,value,{httpOnly:true});
}
export async function logout(type:string) {
            
    if(type === "user"){
            (await cookies()).delete('token');
            (await cookies()).delete('usertype');
            (await cookies()).delete('businesstype');
            (await cookies()).delete('userfirstname');
            (await cookies()).delete('userlastname');
            (await cookies()).delete('isVerified');
            (await cookies()).delete('isEmailVerified');
            (await cookies()).delete('email');
            (await cookies()).delete('photo');
            return true;
    }
    if(type === "admin"){
            (await cookies()).delete('not_useremail');
            (await cookies()).delete('not_usertoken');
            return true;
    }
}




   