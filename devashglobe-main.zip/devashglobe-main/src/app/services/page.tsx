import ServicesComponent from "@/components/serivesComponent";
import TestimonialsComponent from "@/components/testimonialComponent";
import FaqComponent from "@/components/faqComponent";
import WhyUsComponent from "@/components/whyChooseUs";
import LoadBoardNavComponent from "@/components/loadBoardNavComponent"
import BannerComponent from "@/components/bannerComponent"
import Link from "next/link";


export default function Services() {
//   const [darkMode, setDarkMode] = useState(false);

  return (
    // dark:bg-gray-900 text-white
    <>
      {/* banner component */}
      <BannerComponent backgroudImage = "/assets/img/banner/header-32.jpg" pageTitle = "Services" bannerImage = "/assets/img/banner/pm-bg.png"/>   

      <div className="py-24 bg-white text-gray-900  ">  
        <div className="container mx-auto p-6">
          <div className="flex justify-between items-center mb-6">
            
          </div>

          <ServicesComponent/>

          <div className="mt-12 p-10">
              {/* <h2 className="text-2xl font-bold text-center text-[#06163A] dark:text-[#D62D30]">FAQ & Why Choose Us</h2> */}

              <div className="grid md:grid-cols-2 gap-6 mt-24">
                  <WhyUsComponent />
                  <LoadBoardNavComponent/>
              </div>
              
                                <div className="relative w-full mt-24">
                                  {/* Background image */}
                                  <div className="w-full bg-[url('/assets/img/banner/fq.jpg')] bg-cover bg-center grid md:grid-cols-2 gap-6 py-16 px-10 relative">
                                    {/* Overlay */}
                                    <div className="absolute inset-0 bg-black/40"></div>
              
                                    {/* Content */}
                                    <div className="relative z-10 flex flex-col justify-center text-white space-y-6">
                                      <h1 className="text-3xl md:text-5xl font-bold leading-tight">
                                        Fast & Reliable Logistics
                                      </h1>
                                      <p className="text-lg md:text-xl max-w-lg">
                                        We connect shippers, carriers, and forwarders with smart logistics solutions that save you time and cost.
                                      </p>
                                      <div>  
                                        <Link href={"/joinus"} className="bg-[#D62D30] hover:bg-red-700 transition px-6 py-3 rounded-2xl font-semibold">
                                          Get Started 
                                        </Link>
                                      </div>
                                    </div>
                                    <div className="relative z-10 flex flex-col justify-center text-white space-y-6">
                                       <FaqComponent />
                                    </div>
                                  </div>
                                </div>

          </div>

          <div className="mt-12 p-10 '">
               <TestimonialsComponent  />
          </div>


        </div>
      </div>
    </>
  );
}

