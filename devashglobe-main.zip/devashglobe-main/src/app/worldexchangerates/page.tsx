"use client";

import { Legend } from "@headlessui/react";
import Image from "next/image";
import { useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const data = [
  { month: "Sep", EUR: 4.9, USD: 4.5 },
  { month: "Oct", EUR: 5.0, USD: 4.6 },
  { month: "Nov", EUR: 5.1, USD: 4.55 },
  { month: "Dec", EUR: 5.05, USD: 4.52 },
  { month: "Jan", EUR: 5.07, USD: 4.48 },
  { month: "Feb", EUR: 5.08, USD: 4.5 },
  { month: "Mar", EUR: 5.1, USD: 4.55 },
  { month: "Apr", EUR: 5.12, USD: 4.6 },
  { month: "May", EUR: 5.15, USD: 4.65 },
  { month: "Jun", EUR: 5.18, USD: 4.7 },
  { month: "Jul", EUR: 5.2, USD: 4.72 },
  { month: "Aug", EUR: 5.22, USD: 4.75 },
];

export default function WorldExchangeRates() {
  const [date, setDate] = useState("08-09-2025");
  const [from, setFrom] = useState("EUR");
  const [to, setTo] = useState("RON");
  const [value, setValue] = useState(1);
  const [result, setResult] = useState("");

  const handleConvert = () => {
    // Placeholder: You can plug your API or logic here
    setResult((value * 5.08).toFixed(2)); // Example conversion
  };

  return (
    <div>
      <section
        className="relative  py-15 bg-transparent"
        // style={{ backgroundImage: `url(/assets/img/banner/ash-slider.jpg)` }}
      >
        <span className="absolute inset-0 bg-transparent] opacity-50"></span>
        <div className="container mx-auto relative z-10 text-center"></div>
        <div className="absolute bottom-18.5  left-0 w-50 h-50"></div>
      </section>
      <main className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* LEFT CONTENT */}
          <div>
            <section className="bg-white shadow rounded-xl p-6">
              {/* Title */}
              <h1 className="text-2xl md:text-3xl font-bold mb-4">
                Exchange rate and Currency converter
              </h1>
              <p className="text-center mb-4 text-gray-600">
                All conversions are based on the exchange rate of the National
                Bank of Romania valid on the selected day.
              </p>

              <h4 className="font-semibold mb-6">
                Exchange rate and Currency converter <br />
                VALID <span className="text-[#D62D30]">{date}</span>
              </h4>

              {/* Table */}
              <div className="overflow-x-auto mb-6">
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border px-3 py-2 text-left">Currency</th>
                      <th className="border px-3 py-2 text-right">RON</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { cur: "1 RON", val: "1.0000" },
                      { cur: "1 EUR", val: "5.0787" },
                      { cur: "1 USD", val: "4.3463" },
                      { cur: "1 GBP", val: "5.8571" },
                      { cur: "1 HUF", val: "0.0129" },
                      { cur: "1 MDL", val: "0.2607" },
                      { cur: "1 BGN", val: "2.5967" },
                      { cur: "1 CZK", val: "0.2078" },
                      { cur: "1 CHF", val: "5.4106" },
                      { cur: "1 PLN", val: "1.1943" },
                      { cur: "1 UAH", val: "0.1054" },
                      { cur: "1 TRY", val: "0.1053" },
                      { cur: "1 RSD", val: "0.0433" },
                    ].map((row, i) => (
                      <tr key={i} className={i % 2 === 0 ? "bg-gray-50" : ""}>
                        <td className="border px-3 py-2">{row.cur}</td>
                        <td className="border px-3 py-2 text-right">
                          {row.val}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Converter Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleConvert();
                }}
                className="space-y-4"
              >
                {/* Date */}
                <div>
                  <label className="block text-sm font-medium">Date</label>
                  <input
                    type="text"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    placeholder="dd-mm-yyyy"
                    className="mt-1 w-full border rounded-lg px-3 py-2"
                  />
                </div>

                {/* From/To */}
                <div className="grid grid-cols-12 gap-4">
                  <div className="col-span-5">
                    <label className="block text-sm font-medium">From</label>
                    <select
                      value={from}
                      onChange={(e) => setFrom(e.target.value)}
                      className="mt-1 w-full border rounded-lg px-3 py-2"
                    >
                      <option>RON</option>
                      <option>EUR</option>
                      <option>USD</option>
                      <option>GBP</option>
                      <option>HUF</option>
                      <option>MDL</option>
                      <option>BGN</option>
                      <option>CZK</option>
                      <option>CHF</option>
                      <option>PLN</option>
                      <option>UAH</option>
                      <option>TRY</option>
                      <option>RSD</option>
                    </select>
                  </div>

                  <div className="col-span-5">
                    <label className="block text-sm font-medium">In</label>
                    <select
                      value={to}
                      onChange={(e) => setTo(e.target.value)}
                      className="mt-1 w-full border rounded-lg px-3 py-2"
                    >
                      <option>RON</option>
                      <option>EUR</option>
                      <option>USD</option>
                      <option>GBP</option>
                      <option>HUF</option>
                      <option>MDL</option>
                      <option>BGN</option>
                      <option>CZK</option>
                      <option>CHF</option>
                      <option>PLN</option>
                      <option>UAH</option>
                      <option>TRY</option>
                      <option>RSD</option>
                    </select>
                  </div>

                  <div className="col-span-2 flex items-end">
                    <button
                      type="button"
                      onClick={() => {
                        setFrom(to);
                        setTo(from);
                      }}
                      className="w-full h-10 border rounded-lg text-white bg-[#D62D30] flex items-center justify-center"
                    >
                      ⇄
                    </button>
                  </div>
                </div>

                {/* Value / Result */}
                <div className="grid grid-cols-12 gap-4">
                  <div className="col-span-4">
                    <input
                      type="number"
                      value={value}
                      onChange={(e) => setValue(parseFloat(e.target.value))}
                      className="w-full border rounded-lg px-3 py-2 text-right"
                    />
                  </div>
                  <div className="col-span-8">
                    <input
                      type="text"
                      value={result}
                      readOnly
                      className="w-full border rounded-lg px-3 py-2 bg-gray-100"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#06163A] text-white py-2 rounded-lg"
                >
                  Convert
                </button>
              </form>

              <div className="mt-6 text-center text-gray-500">
                Last 12 months
              </div>

              {/* Chart placeholder */}
              <div className="mt-4 w-full h-56 bg-gray-100 rounded-lg flex items-center justify-center overflow-x-scroll">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data}>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      className="stroke-gray-200 dark:stroke-gray-700"
                    />
                    <XAxis dataKey="month" stroke="#888" />
                    <YAxis stroke="#888" />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="EUR"
                      stroke="#D62D30"
                      strokeWidth={2}
                    />
                    <Line
                      type="monotone"
                      dataKey="USD"
                      stroke="#2563eb"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </section>
          </div>

          {/* RIGHT IMAGE */}
          <div className="relative w-full h-[500px] rounded-xl overflow-hidden">
            <Image
              src="/assets/img/loads/fx.jpg"
              alt="Currency converter"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </main>
    </div>
  );
}
