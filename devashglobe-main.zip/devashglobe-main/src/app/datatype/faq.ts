export interface Faq{
    id:number,
    question:string,
    response_ans:string,
    date:string,
    staus:string,
    deleted:number
}