import { loadboard } from "./loadboards";
import users from "./users";

export interface DonutData {
    label: string,
    value: number,
    total: number,
    color: string, 
    count: string 
  } 

export interface Contracts {
    id: string,
    load: string,
    title: string,
    shipper: string,
    carrier: string,
    truck: string,
    date: string,
    location: string,
    price: string,
    status: string,
  
}

export const monthLoadData  = [ 
  { month: 'Jan', loads: 40 },
  { month: 'Feb', loads: 35 },
  { month: 'Mar', loads: 50 },
  { month: 'Apr', loads: 45 },
  { month: 'May', loads: 60 },
  { month: 'Jun', loads: 55 },
  { month: 'Jul', loads: 70 },
];

 export const weeklyData = [
      { name: 'Mon', visits: 320 },
      { name: 'Tue', visits: 450 },
      { name: 'Wed', visits: 390 },
      { name: 'Thu', visits: 512 },
      { name: 'Fri', visits: 478 },
      { name: 'Sat', visits: 365 },
      { name: 'Sun', visits: 420 },
    ];

    
  // export const donutData:{ label: string, value: number, total: number, color: string, count: string } = [];


  export const lineData = [
        { name: 'Mon', value: 65 },
        { name: 'Tue', value: 59 },
        { name: 'Wed', value: 80 },
        { name: 'Thu', value: 81 },
        { name: 'Fri', value: 56 },
        { name: 'Sat', value: 55 },
      ];

  export const pieData = [
        { name: 'Clothing', value: 558 },
        { name: 'Electronics', value: 204 },
        { name: 'Furniture', value: 108 },
      ];

export const COLORS = ['#06163A', '#D62D30', '#9CA3AF'];

// id: number, 
// name: string , 
// email: string,
// img: string, 
// status:string ,
// date:string,
// type:string,
// deleted:number,

export const f62 :users = [{id:1,name:'',email:'',first_name:'',last_name:'',
  business_type_id:1,user_type:'',password_hash:'',phone_number:'',
  roles:'',photo:'',address_one:'',address_two:'',Means_ID:'',
  category_business:'',Business_cert:'',list_share_holder:'',
  licenses:'',img:'',status:'',date:'',type:'',deleted:0,updated_at:'',
  isVerified:false,isEmailVerified:false
}];

export const users_ :users  = [
  { id: 23544, name: 'Emy Jackson', email: '_jac@xyz.com',
     first_name:'sample',
     last_name:'text',
     business_type_id:1,
     user_type:'indivifual',
     password_hash:'',
     phone_number:'+234556677665',
     roles:'user',
     photo:'1.jpg',
     address_one:'home 1',
     address_two:'home 2',
     Means_ID:'id.jpg',
     category_business :'carrier',
     Business_cert:'one,two',
     list_share_holder:'',
     licenses : '',img:'/assets/img/users/1.jpeg',
      status:'new' , date:"1st Jan 2025", type:"shipper", deleted:0,updated_at:'',
     isVerified:false,
     isEmailVerified:false},
  { id: 63544, name: 'Martin Hughes', email: 'martin.hug@xyz.com', 
     first_name:'sample',
     last_name:'text',
     business_type_id:1,
     user_type:'indivifual',
     password_hash:'',
     phone_number:'+234556677665',
     roles:'user',
     photo:'1.jpg',
     address_one:'home 1',
     address_two:'home 2',
     Means_ID:'id.jpg',
     category_business :'carrier',
     Business_cert:'one,two',
     list_share_holder:'',
     licenses : '',img: '/assets/img/users/2.jpeg',
      status:'new', date:"2nd Mar 2025" , type:"carrier", deleted:0,updated_at:'',
     isVerified:false,
     isEmailVerified:false},
  { id: 43544, name: 'A Madison', email: 'laura_01@xyz.com',
     first_name:'sample',
     last_name:'text',
     business_type_id:1,
     user_type:'indivifual',
     password_hash:'',
     phone_number:'+234556677665',
     roles:'user',
     photo:'1.jpg',
     address_one:'home 1',
     address_two:'home 2',
     Means_ID:'id.jpg',
     category_business :'carrier',
     Business_cert:'one,two',
     list_share_holder:'',
     licenses : '',img: '/assets/img/users/3.jpg',
       status:'long' , date:"2nd Mar 2024" ,
        type:"shipper", deleted:0,updated_at:'',
      isVerified:false,
      isEmailVerified:false},
  { id: 53544, name: 'Both Jackson', email: 'y_jac@xyz.com',
     first_name:'sample',
     last_name:'text',
     business_type_id:1,
     user_type:'indivifual',
     password_hash:'',
     phone_number:'+234556677665',
     roles:'user',
     photo:'1.jpg',
     address_one:'home 1',
     address_two:'home 2',
     Means_ID:'id.jpg',
     category_business :'carrier',
     Business_cert:'one,two',
     list_share_holder:'',
     licenses : '',img: '/assets/img/users/4.jpeg',
       status:'new' , date:"1st Jan 2025", type:"shipper", deleted:0,updated_at:'',
      isVerified:false,
      isEmailVerified:false},
  { id: 83544, name: 'Mar Hughes', email: 'mart.hug@xyz.com',
     first_name:'sample',
     last_name:'text',
     business_type_id:1,
     user_type:'indivifual',
     password_hash:'',
     phone_number:'+234556677665',
     roles:'user',
     photo:'1.jpg',
     address_one:'home 1',
     address_two:'home 2',
     Means_ID:'id.jpg',
     category_business :'carrier',
     Business_cert:'one,two',
     list_share_holder:'',
     licenses : '',
img: '/assets/img/users/5.jpg',
       status:'old', date:"2nd Mar 2025" , type:"carrier",
        deleted:0,updated_at:'',
      isVerified:false,
      isEmailVerified:false},
  { id: 93544, name: 'ra Madison', email: 'laura_04@xyz.com', 
     first_name:'sample',
     last_name:'text',
     business_type_id:1,
     user_type:'indivifual',
     password_hash:'',
     phone_number:'+234556677665',
     roles:'user',
     photo:'1.jpg',
     address_one:'home 1',
     address_two:'home 2',
     Means_ID:'id.jpg',
     category_business :'carrier',
     Business_cert:'one,two',
     list_share_holder:'',
     licenses : '',
img: '/assets/img/users/6.jpg',
      status:'long ago' , date:"2nd Mar 2024" ,
       type:"shipper", deleted:0,updated_at:'',
      isVerified:false,
      isEmailVerified:false},
]

export const loads = [
  { title: 'Load from LA to NY', stats: 'Pending', img: '/assets/img/loads/1.jpeg', value: '$2,400' },
  { title: 'Pallet Freight', stats: 'In Transit', img: '/assets/img/loads/2.avif', value: '$1,860' },
  { title: 'Container - 40ft', stats: 'Delivered', img: '/assets/img//loads/3.avif', value: '$3,200' },
]

export const trucks = [
  { title: 'Truck A45 - Volvo', status: 'Available', img: '/assets/img/trucks/1.jpeg' },
  { title: 'Truck M22 - Scania', status: 'In Use', img: '/assets/img/trucks/2.jpeg' },
  { title: 'Truck L09 - MAN', status: 'Maintenance', img: '/assets/img/trucks/3.jpeg' },
]



// export const contracts = [
//   {
//     id: '#897656',
//     load: '/assets/img/loads/1.jpeg',
//     title: '20ft Container',
//     shipper: 'Brooklyn Zeo',
//     carrier: 'Abc Llc',
//     truck: '/assets/img/trucks/1.jpeg',
//     date: '12 Jul 2020',
//     location: 'Lagos',
//     price: '$64.00',
//     status: 'Pending',
//   },
//   {
//     id: '#987549',
//     load: '/assets/img/loads/2.avif',
//     title: 'Pallet Freight',
//     shipper: 'Martin Hughes',
//     carrier: 'Pop up & co',
//     truck: '/assets/img/trucks/2.jpeg',
//     date: '14 Jul 2020',
//     location: 'Abuja',
//     price: '$45.00',
//     status: 'Dispatched',
//   },
//   {
//     id: '#685749',
//     load: '/assets/img/loads/3.avif',
//     title: 'Bulk Cement',
//     shipper: 'Shoan Stephen',
//     carrier: 'Coca cola & co',
//     truck: '/assets/img/trucks/3.jpeg',
//     date: '15 Jul 2020',
//     location: 'Enugu',
//     price: '$67.00',
//     status: 'Completed',
//   },
//   // Add more entries as needed
// ];


export const x_loadBoard : loadboard [] = [
    {
    id:4,
    account_id:12,
    type:"truck", 
    equipment_id:12, 
    date_upper_range:"1/12/2025", 
    date_lower_range:"23/8/2025",
    from_state:"accra",
    to_state:"lagos",
    from_city:"kasua",
    to_city:"oshodi",
    title:"Van truck",
    type_load:"",
    size:45,
    long_lat:"344567,4566778",
    price_upper_range:"4590000",
    price_best_range:"3457999",
    price_low_range:"2244555",
    image:"1.jpg",
    track_id: "23455667899",
    status:"0" ,
    date:"1/34/67",
    deleted: 0,
    updated_at: "45/7/567",
},

    {
    id:1,
    account_id:12,
    type:"truck", 
    equipment_id:12, 
    date_upper_range:"1/12/2025", 
    date_lower_range:"23/8/2025",
    from_state:"accra",
    to_state:"lagos",
    from_city:"kasua",
    to_city:"oshodi",
    title:"Van truck",
    type_load:"",
    size:45,
    long_lat:"344567,4566778",
    price_upper_range:"4590000",
    price_best_range:"3457999",
    price_low_range:"2244555",
    image:"1.jpg",
    track_id: "23455667899",
    status:"0" ,
    date:"1/34/67",
    deleted: 0,
    updated_at: "45/7/567",
},




];

// export default {monthLoadData,weeklyData,lineData,donutData,pieData,COLORS,users,loads,trucks,contracts} ;