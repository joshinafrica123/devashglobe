type registeredUser = {
    id: number, 
    email: string,
    user_type: string , 
    business_type_id: number, 
    password_hash:string,
    status:string ,
    date:string,
    deleted:number,
    updated_at:string,
    };

    export default registeredUser ;