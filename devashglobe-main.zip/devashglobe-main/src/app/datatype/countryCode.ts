// src/utils/countryCodes.js - Country codes and phone number utilities

export interface Country   {
    id:string;
    code:string;
    country:string;
    flag:string;
    maxLength:number;
}


export const COUNTRY_CODES : Country []= [
  { id: "us", code: "+1", country: "United States", flag: "🇺🇸", maxLength: 10 },
  { id: "ca", code: "+1", country: "Canada", flag: "🇨🇦", maxLength: 10 },
  { id: "gb", code: "+44", country: "United Kingdom", flag: "🇬🇧", maxLength: 10 },
  { id: "fr", code: "+33", country: "France", flag: "🇫🇷", maxLength: 9 },
  { id: "de", code: "+49", country: "Germany", flag: "🇩🇪", maxLength: 11 },
  { id: "it", code: "+39", country: "Italy", flag: "🇮🇹", maxLength: 10 },
  { id: "es", code: "+34", country: "Spain", flag: "🇪🇸", maxLength: 9 },
  { id: "nl", code: "+31", country: "Netherlands", flag: "🇳🇱", maxLength: 9 },
  { id: "be", code: "+32", country: "Belgium", flag: "🇧🇪", maxLength: 9 },
  { id: "ch", code: "+41", country: "Switzerland", flag: "🇨🇭", maxLength: 9 },
  { id: "at", code: "+43", country: "Austria", flag: "🇦🇹", maxLength: 11 },
  { id: "dk", code: "+45", country: "Denmark", flag: "🇩🇰", maxLength: 8 },
  { id: "se", code: "+46", country: "Sweden", flag: "🇸🇪", maxLength: 9 },
  { id: "no", code: "+47", country: "Norway", flag: "🇳🇴", maxLength: 8 },
  { id: "fi", code: "+358", country: "Finland", flag: "🇫🇮", maxLength: 9 },
  { id: "ru", code: "+7", country: "Russia", flag: "🇷🇺", maxLength: 10 },
  { id: "cn", code: "+86", country: "China", flag: "🇨🇳", maxLength: 11 },
  { id: "jp", code: "+81", country: "Japan", flag: "🇯🇵", maxLength: 11 },
  { id: "kr", code: "+82", country: "South Korea", flag: "🇰🇷", maxLength: 11 },
  { id: "in", code: "+91", country: "India", flag: "🇮🇳", maxLength: 10 },
  { id: "id", code: "+62", country: "Indonesia", flag: "🇮🇩", maxLength: 12 },
  { id: "my", code: "+60", country: "Malaysia", flag: "🇲🇾", maxLength: 10 },
  { id: "sg", code: "+65", country: "Singapore", flag: "🇸🇬", maxLength: 8 },
  { id: "th", code: "+66", country: "Thailand", flag: "🇹🇭", maxLength: 9 },
  { id: "vn", code: "+84", country: "Vietnam", flag: "🇻🇳", maxLength: 9 },
  { id: "ph", code: "+63", country: "Philippines", flag: "🇵🇭", maxLength: 10 },
  { id: "au", code: "+61", country: "Australia", flag: "🇦🇺", maxLength: 9 },
  { id: "nz", code: "+64", country: "New Zealand", flag: "🇳🇿", maxLength: 9 },
  { id: "za", code: "+27", country: "South Africa", flag: "🇿🇦", maxLength: 9 },
  { id: "ng", code: "+234", country: "Nigeria", flag: "🇳🇬", maxLength: 10 },
  { id: "ke", code: "+254", country: "Kenya", flag: "🇰🇪", maxLength: 9 },
  { id: "gh", code: "+233", country: "Ghana", flag: "🇬🇭", maxLength: 9 },
  { id: "ug", code: "+256", country: "Uganda", flag: "🇺🇬", maxLength: 9 },
  { id: "tz", code: "+255", country: "Tanzania", flag: "🇹🇿", maxLength: 9 },
  { id: "rw", code: "+250", country: "Rwanda", flag: "🇷🇼", maxLength: 9 },
  { id: "ma", code: "+212", country: "Morocco", flag: "🇲🇦", maxLength: 9 },
  { id: "eg", code: "+20", country: "Egypt", flag: "🇪🇬", maxLength: 10 },
  { id: "dz", code: "+213", country: "Algeria", flag: "🇩🇿", maxLength: 9 },
  { id: "tn", code: "+216", country: "Tunisia", flag: "🇹🇳", maxLength: 8 },
  { id: "ly", code: "+218", country: "Libya", flag: "🇱🇾", maxLength: 9 },
  { id: "mx", code: "+52", country: "Mexico", flag: "🇲🇽", maxLength: 10 },
  { id: "br", code: "+55", country: "Brazil", flag: "🇧🇷", maxLength: 11 },
  { id: "ar", code: "+54", country: "Argentina", flag: "🇦🇷", maxLength: 10 },
  { id: "cl", code: "+56", country: "Chile", flag: "🇨🇱", maxLength: 9 },
  { id: "co", code: "+57", country: "Colombia", flag: "🇨🇴", maxLength: 10 },
  { id: "pe", code: "+51", country: "Peru", flag: "🇵🇪", maxLength: 9 },
  { id: "ve", code: "+58", country: "Venezuela", flag: "🇻🇪", maxLength: 10 },
  { id: "ec", code: "+593", country: "Ecuador", flag: "🇪🇨", maxLength: 9 },
  { id: "uy", code: "+598", country: "Uruguay", flag: "🇺🇾", maxLength: 8 },
  { id: "py", code: "+595", country: "Paraguay", flag: "🇵🇾", maxLength: 9 },
  { id: "bo", code: "+591", country: "Bolivia", flag: "🇧🇴", maxLength: 8 },
  { id: "ae", code: "+971", country: "United Arab Emirates", flag: "🇦🇪", maxLength: 9 },
  { id: "sa", code: "+966", country: "Saudi Arabia", flag: "🇸🇦", maxLength: 9 },
  { id: "qa", code: "+974", country: "Qatar", flag: "🇶🇦", maxLength: 8 },
  { id: "kw", code: "+965", country: "Kuwait", flag: "🇰🇼", maxLength: 8 },
  { id: "bh", code: "+973", country: "Bahrain", flag: "🇧🇭", maxLength: 8 },
  { id: "om", code: "+968", country: "Oman", flag: "🇴🇲", maxLength: 8 },
  { id: "lb", code: "+961", country: "Lebanon", flag: "🇱🇧", maxLength: 8 },
  { id: "jo", code: "+962", country: "Jordan", flag: "🇯🇴", maxLength: 9 },
  { id: "il", code: "+972", country: "Israel", flag: "🇮🇱", maxLength: 9 },
  { id: "tr", code: "+90", country: "Turkey", flag: "🇹🇷", maxLength: 10 },
  { id: "ir", code: "+98", country: "Iran", flag: "🇮🇷", maxLength: 10 },
  { id: "pk", code: "+92", country: "Pakistan", flag: "🇵🇰", maxLength: 10 },
  { id: "bd", code: "+880", country: "Bangladesh", flag: "🇧🇩", maxLength: 10 },
  { id: "lk", code: "+94", country: "Sri Lanka", flag: "🇱🇰", maxLength: 9 },
  { id: "np", code: "+977", country: "Nepal", flag: "🇳🇵", maxLength: 10 },
  { id: "af", code: "+93", country: "Afghanistan", flag: "🇦🇫", maxLength: 9 },
];

// Default to Ghana
export const DEFAULT_COUNTRY = {
  id: "gh",
  code: "+233",
  country: "Ghana",
  flag: "🇬🇭",
  maxLength: 9,
};



// Format phone number with country code
export const formatInternationalPhoneNumber = (phoneNumber:string, countryCode:string) => {
  if (!phoneNumber || !countryCode) return "";

  // Remove all non-numeric characters
  const cleanPhone = phoneNumber.replace(/[^\d]/g, "");

  // If phone starts with 0, remove it (common for local numbers)
  const finalPhone = cleanPhone.startsWith("0")
    ? cleanPhone.slice(1)
    : cleanPhone;

  return `${countryCode}${finalPhone}`;
};

// Validate phone number for specific country
export const validatePhoneNumber = (phoneNumber:string, countryCode:string) => {
  const country = COUNTRY_CODES.find((c) => c.code === countryCode);
  if (!country) return false;

  // Remove all non-numeric characters
  const cleanPhone = phoneNumber.replace(/[^\d]/g, "");

  // Check if length matches expected length for the country
  const expectedLength = country.maxLength;
  return (
    cleanPhone.length === expectedLength ||
    cleanPhone.length === expectedLength + 1
  ); // Allow for some flexibility
};

// Parse international phone number to separate country code and number
export const parsePhoneNumber = (fullPhoneNumber:string) => {
  if (!fullPhoneNumber || !fullPhoneNumber.startsWith("+")) {
    return {
      countryCode: DEFAULT_COUNTRY.code,
      phoneNumber: fullPhoneNumber || "",
    };
  }

  // Find matching country code (longest match first)
  const sortedCodes = COUNTRY_CODES.sort(
    (a, b) => b.code.length - a.code.length
  );

  for (const country of sortedCodes) {
    if (fullPhoneNumber.startsWith(country.code)) {
      return {
        countryCode: country.code,
        phoneNumber: fullPhoneNumber.slice(country.code.length),
      };
    }
  }

  // If no match found, default to Ghana
  return {
    countryCode: DEFAULT_COUNTRY.code,
    phoneNumber: fullPhoneNumber.slice(1),
  };
};

// Get country info by code
export const getCountryByCode = (countryCode:string) => {
  return COUNTRY_CODES.find((c) => c.code === countryCode) || DEFAULT_COUNTRY;
};

// Search countries by name or code
export const searchCountries = (query:string) => {
  if (!query) return COUNTRY_CODES;

  const lowerQuery = query.toLowerCase();
  return COUNTRY_CODES.filter(
    (country) =>
      country.country.toLowerCase().includes(lowerQuery) ||
      country.code.includes(query)
  );
};
