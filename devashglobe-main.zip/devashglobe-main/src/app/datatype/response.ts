
import Admin from "./admin";
import contact from "./contact";
import Contract from "./contract";
import { equipment } from "./equipment";
import { Faq } from "./faq";
import { loadboard } from "./loadboards";
import user from "./user";
import users from "./users";

interface responce  {
    error : string,
    status: number,
    size:number
    token:string,
    message:string,
    insertId:number,
    user:user[],
    kyc:users,
    users:users,
    loadboard:loadboard [],
    equipments:equipment[],
    faq:Faq[],
    notuser:Admin[],
    contacts:contact[],
    contracts:Contract[]
    };

    export default responce  ;