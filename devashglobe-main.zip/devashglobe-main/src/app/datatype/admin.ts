interface Admin {
    id: number, 
    email: string,
    user_type: string , 
    level:string,
    business_type_id: number, 
    password_hash:string,
    first_name:string,
    last_name:string,
    password :string,
    confirm_password:string,
    roles:string,
    photo:string,
    address_one:string,
    address_two:string,
    Means_ID:string,
    category_business :string,
    Business_cert:string,
    list_share_holder:string,
    licenses : string,
    img: string
    status:string ,
    date:string,
    deleted:number,
    updated_at:string,
    };

    export default Admin ;