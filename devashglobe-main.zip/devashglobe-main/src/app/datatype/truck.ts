type truck = { 
    title: string,
    status: string,
    img: string 
};

    export default truck ;