type userType = {
    shipper: string, 
    carrier: string , 
    broker: string };

    export default userType ;