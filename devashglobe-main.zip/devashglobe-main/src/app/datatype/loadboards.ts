export interface loadboard {
    id:number;
    account_id:number;
    type:string; 
    equipment_id:number; 
    date_upper_range:string; 
    date_lower_range:string,
    from_state:string;
    to_state:string;
    from_city:string;
    to_city:string;
    title:string;
    type_load:string;
    size:number;
    long_lat:string;
    price_upper_range:string;
    price_best_range:string;
    price_low_range:string;
    image:string;
    track_id: string;
    status:string ;
    date:string;
    deleted: number; 
    updated_at: string;
};


