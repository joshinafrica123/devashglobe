type user = {
     id: number, 
     name: string , 
     email: string,
     first_name:string,
     last_name:string,
     business_type_id:number,
     user_type:string,
     password_hash:string,
     phone_number:string,
     roles:string,
     photo:string,
     address_one:string,
     address_two:string,
     Means_ID:string,
     category_business :string,
     Business_cert:string,
     list_share_holder:string,
     licenses : string,
     img: string, 
     status:string ,
     date:string,
     type:string,
     deleted:number,
     updated_at:string
     isVerified:boolean,
     isEmailVerified:boolean
     };

     export default user ;