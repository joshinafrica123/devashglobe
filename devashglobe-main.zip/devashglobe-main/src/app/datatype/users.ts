import user from "./user";

type users = user[];

    export default users ;