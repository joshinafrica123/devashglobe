type contract = {
  id: string,
  load: string,
  title: string,
  shipper: string,
  carrier: string,
  truck: string,
  date: string,
  location: string,
  price: string,
  status: string,
}

export default contract;