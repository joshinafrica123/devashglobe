type businessType = {
    id: number, 
    business_name: string,
    };

    export default businessType ;