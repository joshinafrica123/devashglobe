export default interface Contract {
   id:number;
   object_id:number;
   account_id:number;
   shippers_id:number;
   contract_type:string; 
   carrier_id:number; 
   truck_id:string; 
   load_id:string,
   description:string;
   delivery_time:string;
   shippers_status:string;
   carrier_status:string;
   payment:string;
   payment_status:string;
   mode_of_payment:number;
   status:string ;
   date:string;
   deleted: number; 
   updated_at: string;
};


