interface contact  {
    id: number, 
    type:string,
    email:string,
    name:string,
    phone:string,
    message:string,
    size:number,
    distance:number,
    companyName:string, 
    status: string,
    date: string,
    deleted: number,
    };

    export default contact ;