interface Vendor {
  name: string;
  avatarUrl?: string;   
    verified: boolean;
    rating?: number; // out of 5
    trucks?: number;
    loads?: number;
    successRate?: number; // percentage
    deliveryRate?: number; // percentage
    bio?: string;
    about?: string;
}


    export default Vendor ;