type load = { 
    title: string, 
    stats: string,
    img: string,
    value: string
 }

    export default load ; 
