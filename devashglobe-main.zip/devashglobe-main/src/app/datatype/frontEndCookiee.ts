"use client"

import responce from "./response";
import user from "./user";

interface Admin {
    id: number, 
    email: string,
    user_type: string , 
    level:number,
    password_hash:string,
    status:string ,
    date:string,
    deleted:number,
    updated_at:string,
    };


    interface i {
      message : string,
      token:string,
      Admin:Admin []
    }

export function getCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  return match ? match[2] : null;
}


export function setCookie (data : responce,type:string,usertype:string,businesstype:string | "", email:string | "") {
  console.log((data as responce).user)
  if(type ==='signup'){
    document.cookie = `token=${(data as responce).token}; path=/; max-age=86400`;
    document.cookie = `usertype=${usertype}; path=/; max-age=86400`;
    document.cookie = `businesstype=${businesstype}; path=/; max-age=86400`;
    document.cookie = `isVerified=${(data as responce).user[0].isVerified}; path=/; max-age=86400`;
    document.cookie = `isEmailVerified=${(data as responce).user[0].isEmailVerified}; path=/; max-age=86400`;
    document.cookie = `email=${email}; path=/; max-age=86400`;
    document.cookie = `photo=${(data as responce).user[0].photo}; path=/; max-age=86400`;
  }else if (type === 'signin'){
    document.cookie = `token=${(data as responce).token}; path=/; max-age=86400`;
    document.cookie = `usertype=${(((data as responce).user)[0] as user).user_type}; path=/; max-age=86400`;
    document.cookie = `businesstype=${(((data as responce).user)[0] as user).business_type_id}; path=/; max-age=86400`;
    document.cookie = `userfirstname=${(((data as responce).user)[0] as user).first_name}; path=/; max-age=86400`;
    document.cookie = `userlastname=${(((data as responce).user)[0] as user).last_name}; path=/; max-age=86400`;
     document.cookie = `isVerified=${(data as responce).user[0].isVerified}; path=/; max-age=86400`;
    document.cookie = `isEmailVerified=${(data as responce).user[0].isEmailVerified}; path=/; max-age=86400`;
    document.cookie = `email=${email}; path=/; max-age=86400`;
    document.cookie = `photo=${(data as responce).user[0].photo}; path=/; max-age=86400`;
  }else if (type === 'kyc'){
    // usertype and businesstype is used as first and last name here 
    document.cookie = `userfirstname=${usertype}; path=/; max-age=86400`;
    document.cookie = `userlastname=${businesstype}; path=/; max-age=86400`;
  }else if (type === "not_user") {
      document.cookie = `not_usertoken=${data.token}; path=/; max-age=86400`;
      document.cookie = `not_useremail=${email}; path=/; max-age=86400`;
  }
}

export function setCookies (data : i,type:string,usertype:string,businesstype:string | "", email:string | "") {
  console.log((data as i).Admin)
if (type === "not_user") {
      document.cookie = `not_usertoken=${data.token}; path=/; max-age=86400`;
      document.cookie = `not_useremail=${email}; path=/; max-age=86400`;
  }
}

export function postWhatCookie(postwhat: string) {
      document.cookie = `postwhat=${postwhat}; path=/; max-age=86400`;      
}






export function Cookie (data : responce,type:string,usertype:string,businesstype:string) {
  if(type ==='signup'){
    document.cookie = `token=${(data as responce).token}; path=/; max-age=86400`;
    document.cookie = `usertype=${usertype}; path=/; max-age=86400`;
    document.cookie = `businesstype=${businesstype}; path=/; max-age=86400`;
  }else if (type === 'signin'){
    document.cookie = `token=${(data as responce).token}; path=/; max-age=86400`;
    document.cookie = `usertype=${(((data as responce).user)[0] as user).user_type}; path=/; max-age=86400`;
    document.cookie = `businesstype=${(((data as responce).user)[0] as user).business_type_id}; path=/; max-age=86400`;
    document.cookie = `userfirstname=${(((data as responce).user)[0] as user).first_name}; path=/; max-age=86400`;
    document.cookie = `userlastname=${(((data as responce).user)[0] as user).last_name}; path=/; max-age=86400`;
  }else if (type === 'kyc'){
    // usertype and businesstype is used as first and last name here 
    document.cookie = `userfirstname=${usertype}; path=/; max-age=86400`;
    document.cookie = `userlastname=${businesstype}; path=/; max-age=86400`;
  }
}



export async function isCookieValid(name: string): Promise<boolean> {
  return document.cookie.split('; ').some(cookie => cookie.startsWith(name + '='));
}


export const firstLetterCapitalized= (text:string) =>{

    let cha = "";
    for (let index = 0; index < text.length; index++) {
      if(index != 0){
          cha += text.charAt(index);
      }
    }

    return text.charAt(0).toUpperCase()+cha.toLowerCase();
}


export function truncateText(text: string, maxLength: number) {
  return text.length > maxLength ? text.slice(0, maxLength) + "..." : text;
}