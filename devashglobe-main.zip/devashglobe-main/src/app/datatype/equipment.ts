export interface equipment {
id:number,
account_id:number,
title:string,
date:string,
status:string,
deleted:number
} 