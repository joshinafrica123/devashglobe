"use client";

import Image from "next/image";
import Link from "next/link";

interface PriceInt {
  country: string;
  price_dissel_vat: string;
  price_petrol_without_vat: string;
  price_petrol_vat: string;
  price_dissel_without_vat: string;
  vat_petrol: number;
  vat_disesl: number;
  index: number;
}

const PETROL_DISESL_PRICE: PriceInt[] = [
  {
    country: "AUSTRIA",
    price_dissel_vat: "1.0892",
    price_dissel_without_vat: "1.456",
    price_petrol_vat: "1.7455",
    price_petrol_without_vat: "",
    vat_disesl: 50,
    vat_petrol: 10,
    index: 1.0,
  },
  {
    country: "BELGIUM",
    price_dissel_vat: "1.0291",
    price_dissel_without_vat: "1.456",
    price_petrol_vat: "1.4555",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 1,
    index: 1.0,
  },
  {
    country: "BULGARIA",
    price_dissel_vat: "1.2333",
    price_dissel_without_vat: "1.456",
    price_petrol_vat: "1.1355",
    price_petrol_without_vat: "",
    vat_disesl: 15,
    vat_petrol: 10,
    index: 1.3,
  },
  {
    country: "CZECH REPUBLIC",
    price_dissel_vat: "1.7692",
    price_dissel_without_vat: "1.456",
    price_petrol_vat: "1.7555",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 1.0,
  },
  {
    country: "CYPRUS",
    price_dissel_vat: "1.1292",
    price_dissel_without_vat: "1.456",
    price_petrol_vat: "1.1655",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 1.8,
  },
  {
    country: "CROATIA",
    price_dissel_vat: "1.5492",
    price_dissel_without_vat: "1.456",
    price_petrol_vat: "1.7898",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 0.0,
  },
  {
    country: "DENMARK",
    price_dissel_vat: "1.3332",
    price_dissel_without_vat: "1.456",
    price_petrol_vat: "1.7756",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 0.6,
  },
  {
    country: "ESTONIA",
    price_dissel_vat: "1.1492",
    price_dissel_without_vat: "1.406",
    price_petrol_vat: "1.7975",
    price_petrol_without_vat: "",
    vat_disesl: 7,
    vat_petrol: 10,
    index: 1.0,
  },
  {
    country: "FINLAND",
    price_dissel_vat: "1.3492",
    price_dissel_without_vat: "1.496",
    price_petrol_vat: "1.9255",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 2.0,
  },
  {
    country: "FRANCE",
    price_dissel_vat: "1.6492",
    price_dissel_without_vat: "1.156",
    price_petrol_vat: "1.5455",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 0.2,
  },
  {
    country: "GERMANY",
    price_dissel_vat: "1.2492",
    price_dissel_without_vat: "1.056",
    price_petrol_vat: "1.2355",
    price_petrol_without_vat: "",
    vat_disesl: 10,
    vat_petrol: 10,
    index: 1.0,
  },
  {
    country: "GREECE",
    price_dissel_vat: "1.2402",
    price_dissel_without_vat: "1.356",
    price_petrol_vat: "1.0555",
    price_petrol_without_vat: "",
    vat_disesl: 18,
    vat_petrol: 10,
    index: 1.9,
  },
  {
    country: "IRELAND",
    price_dissel_vat: "1.992",
    price_dissel_without_vat: "1.656",
    price_petrol_vat: "1.9155",
    price_petrol_without_vat: "",
    vat_disesl: 9,
    vat_petrol: 10,
    index: 1.3,
  },
  {
    country: "ITALY",
    price_dissel_vat: "1.0092",
    price_dissel_without_vat: "1.856",
    price_petrol_vat: "1.0255",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 1.0,
  },
  {
    country: "LATVIA",
    price_dissel_vat: "1.5592",
    price_dissel_without_vat: "1.256",
    price_petrol_vat: "1.7876",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 1.3,
  },
  {
    country: "LITHUANIA",
    price_dissel_vat: "1.0490",
    price_dissel_without_vat: "1.876",
    price_petrol_vat: "1.7222",
    price_petrol_without_vat: "",
    vat_disesl: 23,
    vat_petrol: 10,
    index: 3.0,
  },
  {
    country: "LUXEMBOURG",
    price_dissel_vat: "1.2002",
    price_dissel_without_vat: "1.400",
    price_petrol_vat: "1.4568",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 0.3,
  },
  {
    country: "MALTA",
    price_dissel_vat: "1.8192",
    price_dissel_without_vat: "1.004",
    price_petrol_vat: "1.3255",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 20,
    index: 0.5,
  },
  {
    country: "NETHERLANDS",
    price_dissel_vat: "1.002",
    price_dissel_without_vat: "1.416",
    price_petrol_vat: "1.8775",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 2.0,
  },
  {
    country: "POLAND",
    price_dissel_vat: "1.2653",
    price_dissel_without_vat: "1.408",
    price_petrol_vat: "1.4235",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 3.0,
  },
  {
    country: "PORTUGAL",
    price_dissel_vat: "1.7802",
    price_dissel_without_vat: "1.435",
    price_petrol_vat: "1.7535",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 4.0,
  },
  {
    country: "ROMANIA",
    price_dissel_vat: "1.4318",
    price_dissel_without_vat: "1.956",
    price_petrol_vat: "1.7509",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 1.0,
  },
  {
    country: "SLOVAKIA",
    price_dissel_vat: "1.5492",
    price_dissel_without_vat: "1.005",
    price_petrol_vat: "1.6665",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 10,
    index: 1.0,
  },
  {
    country: "SLOVENIA",
    price_dissel_vat: "1.2392",
    price_dissel_without_vat: "1.110",
    price_petrol_vat: "1.7000",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 18,
    index: 1.0,
  },
  {
    country: "SPAIN",
    price_dissel_vat: "1.492",
    price_dissel_without_vat: "1.026",
    price_petrol_vat: "1.3255",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 7,
    index: 1.0,
  },
  {
    country: "SWEDEN",
    price_dissel_vat: "1.8492",
    price_dissel_without_vat: "1.086",
    price_petrol_vat: "1.0055",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 0,
    index: 1.0,
  },
  {
    country: "HUNGARY",
    price_dissel_vat: "1.0492",
    price_dissel_without_vat: "1.456",
    price_petrol_vat: "1.7655",
    price_petrol_without_vat: "",
    vat_disesl: 20,
    vat_petrol: 2,
    index: 1.0,
  },
];

export default function WorldFuelPrice() {
  return (
    <div>
      <section
        className="relative  py-15 bg-transparent"
        // style={{ backgroundImage: `url(/assets/img/banner/ash-slider.jpg)` }}
      >
        <span className="absolute inset-0 bg-transparent] opacity-50"></span>
        <div className="container mx-auto relative z-10 text-center"></div>
        <div className="absolute bottom-18.5  left-0 w-50 h-50"></div>
      </section>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* LEFT CONTENT */}
          <div className="lg:col-span-8">
            <section className="bg-white shadow rounded-xl p-6">
              {/* Title */}
              <h1 className="text-2xl md:text-3xl font-bold mb-6 animate-slideInLeft">
                Diesel prices in Europe on 08-09-2025 - EURO
              </h1>

              {/* Country Select */}
              <div className="flex flex-col items-center mb-4">
                <label htmlFor="country" className="mb-2 font-medium">
                  Index for:
                </label>
                <select
                  id="country"
                  name="country"
                  className="border rounded-lg px-3 py-2 uppercase text-sm"
                >
                  <option value="2">AUSTRIA</option>
                  <option value="3">BELGIUM</option>
                  <option value="6">BULGARIA</option>
                  <option value="7">CZECH REPUBLIC</option>
                  <option value="50">CYPRUS</option>
                  <option value="8">CROATIA</option>
                  <option value="9">DENMARK</option>
                  <option value="11">ESTONIA</option>
                  <option value="12">FINLAND</option>
                  <option value="13">FRANCE</option>
                  <option value="14">GERMANY</option>
                  <option value="15">GREECE</option>
                  <option value="38">IRELAND</option>
                  <option value="16">ITALY</option>
                  <option value="17">LATVIA</option>
                  <option value="18">LITHUANIA</option>
                  <option value="37">LUXEMBOURG</option>
                  <option value="48">MALTA</option>
                  <option value="24">NETHERLANDS</option>
                  <option value="25">POLAND</option>
                  <option value="26">PORTUGAL</option>
                  <option value="27">ROMANIA</option>
                  <option value="30">SLOVAKIA</option>
                  <option value="31">SLOVENIA</option>
                  <option value="32">SPAIN</option>
                  <option value="33">SWEDEN</option>
                  <option value="35">HUNGARY</option>
                </select>
              </div>

              {/* Source */}
              <p className="text-center text-sm italic mb-6">
                Source:{" "}
                <Link
                  href="#"
                  target="_blank"
                  className="font-bold text-blue-600 hover:underline"
                >
                  somewhere.com
                </Link>
              </p>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-sm font-sans">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border px-3 py-2 text-center">Country</th>
                      <th className="border px-3 py-2 text-center">
                        Price (Petrol)
                        <br />
                        (without VAT)
                      </th>
                      <th className="border px-3 py-2 text-center">VAT</th>
                      <th className="border px-3 py-2 text-center">
                        Price (Petrol) <br />
                        (including VAT)
                      </th>
                      <th className="border px-3 py-2 text-center">
                        Price (Diesel) <br />
                        (without VAT)
                      </th>
                      <th className="border px-3 py-2 text-center">VAT</th>
                      <th className="border px-3 py-2 text-center">
                        Price (Diesel)
                        <br />
                        (including VAT)
                      </th>
                      <th className="border px-3 py-2 text-center">Index</th>
                    </tr>
                  </thead>
                  <tbody className="[font-variant-numeric:tabular-nums]">
                    {PETROL_DISESL_PRICE?.map((e, i) => (
                      <tr key={i}>
                        <td className="uppercase border px-3 py-2">{e.country}</td>
                        <td className="text-right border px-3 py-2">{e.price_petrol_without_vat}</td>
                        <td className="text-right border px-3 py-2">{e.vat_petrol}</td>
                        <td className="text-right border px-3 py-2">{e.price_petrol_vat}</td>
                        <td className="text-right border px-3 py-2">{e.price_dissel_without_vat}</td>
                        <td className="text-right border px-3 py-2">{e.vat_disesl}</td>
                        <td className="text-right border px-3 py-2">{e.price_dissel_vat}</td>
                        <td className="text-right border px-3 py-2">{e.index}</td>
                      </tr>
                    ))}

                    {/* ... map your data here */}
                  </tbody>
                </table>
              </div>
            </section>
          </div>

          {/* RIGHT IMAGES */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="relative w-full h-48 rounded-xl overflow-hidden">
              <Image
                src="/assets/img/loads/4.jpg"
                alt="Diesel price 1"
                fill
                className="object-cover"
              />
            </div>
            <div className="relative w-full h-48 rounded-xl overflow-hidden">
              <Image
                src="/assets/img/loads/5.jpg"
                alt="Diesel price 2"
                fill
                className="object-cover"
              />
            </div>
            <div className="relative w-full h-48 rounded-xl overflow-hidden">
              <Image
                src="/assets/img/loads/6.jpg"
                alt="Diesel price 3"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
