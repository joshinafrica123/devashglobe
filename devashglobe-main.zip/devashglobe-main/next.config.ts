import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  output: 'export',
  // Uncomment the line below if your app uses next/image and throws optimization errors during build:
  // images: { unoptimized: true },
};

export default nextConfig;
