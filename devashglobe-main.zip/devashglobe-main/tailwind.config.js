
// import animatePlugin from "tailwindcss-animate";
// import plugin from "tailwindcss/plugin";


// /** @type {import('tailwindcss').Config} */



// export default {
//   content: [
//     "./app/**/*.{js,ts,jsx,tsx}",
//     "./pages/**/*.{js,ts,jsx,tsx}",
//     "./components/**/*.{js,ts,jsx,tsx}",
//   ],
//   theme: {
//     extend: {
//       colors: {
//         background: "oklch(1 0 0)",
//         foreground: "oklch(0.13 0.028 261.692)",
//         primary: "oklch(0.21 0.034 264.665)",
//         "primary-foreground": "oklch(0.985 0.002 247.839)",
//         secondary: "oklch(0.967 0.003 264.542)",
//         "secondary-foreground": "oklch(0.21 0.034 264.665)",
//         destructive: "oklch(0.577 0.245 27.325)",
//         "destructive-foreground": "oklch(0.577 0.245 27.325)",
//         muted: "oklch(0.967 0.003 264.542)",
//         "muted-foreground": "oklch(0.551 0.027 264.364)",
//         accent: "oklch(0.967 0.003 264.542)",
//         "accent-foreground": "oklch(0.21 0.034 264.665)",
//         border: "oklch(0.928 0.006 264.531)",
//         input: "oklch(0.928 0.006 264.531)",
//         ring: "oklch(0.707 0.022 261.325)",
//         popover: "oklch(1 0 0)",
//         "popover-foreground": "oklch(0.13 0.028 261.692)",
//         card: "oklch(1 0 0)",
//         "card-foreground": "oklch(0.13 0.028 261.692)",

//         // Sidebar
//         sidebar: "oklch(0.985 0.002 247.839)",
//         "sidebar-foreground": "oklch(0.13 0.028 261.692)",
//         "sidebar-primary": "oklch(0.21 0.034 264.665)",
//         "sidebar-primary-foreground": "oklch(0.985 0.002 247.839)",
//         "sidebar-accent": "oklch(0.967 0.003 264.542)",
//         "sidebar-accent-foreground": "oklch(0.21 0.034 264.665)",
//         "sidebar-border": "oklch(0.928 0.006 264.531)",
//         "sidebar-ring": "oklch(0.707 0.022 261.325)",

//         // Charts
//         "chart-1": "oklch(0.646 0.222 41.116)",
//         "chart-2": "oklch(0.6 0.118 184.704)",
//         "chart-3": "oklch(0.398 0.07 227.392)",
//         "chart-4": "oklch(0.828 0.189 84.429)",
//         "chart-5": "oklch(0.769 0.188 70.08)",
//       },

//       fontFamily: {
//         sans: ["var(--font-geist-sans)", "sans-serif"],
//         mono: ["var(--font-geist-mono)", "monospace"],
//       },

//       borderRadius: {
//         sm: "calc(var(--radius) - 4px)",
//         md: "calc(var(--radius) - 2px)",
//         lg: "var(--radius)",
//         xl: "calc(var(--radius) + 4px)",
//       },

//       inline: {
//         "--color-background": "var(--background)",
//         "--color-foreground": "var(--foreground)",
//         "--font-sans": "var(--font-geist-sans)",
//         "--font-mono": "var(--font-geist-mono)",
//         "--color-sidebar-ring": "var(--sidebar-ring)",
//         "--color-sidebar-border": "var(--sidebar-border)",
//         "--color-sidebar-accent-foreground": "var(--sidebar-accent-foreground)",
//         "--color-sidebar-accent": "var(--sidebar-accent)",
//         "--color-sidebar-primary-foreground": "var(--sidebar-primary-foreground)",
//         "--color-sidebar-primary": "var(--sidebar-primary)",
//         "--color-sidebar-foreground": "var(--sidebar-foreground)",
//         "--color-sidebar": "var(--sidebar)",
//         "--color-chart-5": "var(--chart-5)",
//         "--color-chart-4": "var(--chart-4)",
//         "--color-chart-3": "var(--chart-3)",
//         "--color-chart-2": "var(--chart-2)",
//         "--color-chart-1": "var(--chart-1)",
//         "--color-ring": "var(--ring)",
//         "--color-input": "var(--input)",
//         "--color-border": "var(--border)",
//         "--color-destructive-foreground": "var(--destructive-foreground)",
//         "--color-destructive": "var(--destructive)",
//         "--color-accent-foreground": "var(--accent-foreground)",
//         "--color-accent": "var(--accent)",
//         "--color-muted-foreground": "var(--muted-foreground)",
//         "--color-muted": "var(--muted)",
//         "--color-secondary-foreground": "var(--secondary-foreground)",
//         "--color-secondary": "var(--secondary)",
//         "--color-primary-foreground": "var(--primary-foreground)",
//         "--color-primary": "var(--primary)",
//         "--color-popover-foreground": "var(--popover-foreground)",
//         "--color-popover": "var(--popover)",
//         "--color-card-foreground": "var(--card-foreground)",
//         "--color-card": "var(--card)",
//         "--radius-sm": "calc(var(--radius) - 4px)",
//         "--radius-md": "calc(var(--radius) - 2px)",
//         "--radius-lg": "var(--radius)",
//         "--radius-xl": "calc(var(--radius) + 4px)",
//       },
//     },
//   },
//   darkMode: "class",
//   plugins: [animatePlugin,
//     plugin(function ({ addBase, theme }) {
//       addBase({
//         "*": {
//           borderColor: theme("colors.border"),
//           outlineColor: theme("colors.ring"),
//           outlineOpacity: "0.5",
//         },
//         body: {
//           backgroundColor: theme("colors.background"),
//           color: theme("colors.foreground"),
//         },
//       }",
//     }),
//   ],
//   darkMode: "class",
// };


// import plugin from "tailwindcss/plugin";
// import animatePlugin from "tailwindcss-animate";

// export default {
//   content: [
//     "./app/**/*.{js,ts,jsx,tsx}",
//     "./pages/**/*.{js,ts,jsx,tsx}",
//     "./components/**/*.{js,ts,jsx,tsx}",
//   ],
//   theme: {
//     extend: {
//       colors: {
//         background: "var(--background)",
//         foreground: "var(--foreground)",
//         primary: "var(--primary)",
//         "primary-foreground": "var(--primary-foreground)",
//         secondary: "var(--secondary)",
//         "secondary-foreground": "var(--secondary-foreground)",
//         destructive: "var(--destructive)",
//         "destructive-foreground": "var(--destructive-foreground)",
//         muted: "var(--muted)",
//         "muted-foreground": "var(--muted-foreground)",
//         accent: "var(--accent)",
//         "accent-foreground": "var(--accent-foreground)",
//         border: "var(--border)",
//         input: "var(--input)",
//         ring: "var(--ring)",
//         popover: "var(--popover)",
//         "popover-foreground": "var(--popover-foreground)",
//         card: "var(--card)",
//         "card-foreground": "var(--card-foreground)",
//         sidebar: "var(--sidebar)",
//         "sidebar-foreground": "var(--sidebar-foreground)",
//         "sidebar-primary": "var(--sidebar-primary)",
//         "sidebar-primary-foreground": "var(--sidebar-primary-foreground)",
//         "sidebar-accent": "var(--sidebar-accent)",
//         "sidebar-accent-foreground": "var(--sidebar-accent-foreground)",
//         "sidebar-border": "var(--sidebar-border)",
//         "sidebar-ring": "var(--sidebar-ring)",
//         "chart-1": "var(--chart-1)",
//         "chart-2": "var(--chart-2)",
//         "chart-3": "var(--chart-3)",
//         "chart-4": "var(--chart-4)",
//         "chart-5": "var(--chart-5)",
//       },
//       fontFamily: {
//         sans: ["var(--font-geist-sans)", "sans-serif"],
//         mono: ["var(--font-geist-mono)", "monospace"],
//       },
//       borderRadius: {
//         sm: "var(--radius-sm)",
//         md: "var(--radius-md)",
//         lg: "var(--radius)",
//         xl: "var(--radius-xl)",
//       },
//     },
//   },
//   darkMode: "class",
//   plugins: [
//     animatePlugin,
//     plugin(function ({ addBase, theme }) {
//       addBase({
//         "*": {
//           "border-color": "var(--border)",
//           "outline-color": "var(--ring)",
//         },
//         body: {
//           "background-color": "var(--background)",
//           color: "var(--foreground)",
//         },
//       }",
//     }),
//   ],
// };






// import plugin from "tailwindcss/plugin";
// import animatePlugin from "tailwindcss-animate";

// export default {
//   content: [
//     "./app/**/*.{js,ts,jsx,tsx}",
//     "./pages/**/*.{js,ts,jsx,tsx}",
//     "./components/**/*.{js,ts,jsx,tsx}",
//   ],
//   theme: {
//     extend: {
//       colors: {
//         background: "oklch(var(--background))",
//         foreground: "oklch(var(--foreground))",
//         border: "oklch(var(--border))",
//         ring: "oklch(var(--ring))",
//         primary: "var(--primary)",
//         "primary-foreground": "var(--primary-foreground)",
//         secondary: "var(--secondary)",
//         "secondary-foreground": "var(--secondary-foreground)",
//         destructive: "var(--destructive)",
//         "destructive-foreground": "var(--destructive-foreground)",
//         muted: "var(--muted)",
//         "muted-foreground": "var(--muted-foreground)",
//         accent: "var(--accent)",
//         "accent-foreground": "var(--accent-foreground)",
//         border: "var(--border)",
//         input: "var(--input)",
//         ring: "var(--ring)",
//         popover: "var(--popover)",
//         "popover-foreground": "var(--popover-foreground)",
//         card: "var(--card)",
//         "card-foreground": "var(--card-foreground)",
//         sidebar: "var(--sidebar)",
//         "sidebar-foreground": "var(--sidebar-foreground)",
//         "sidebar-primary": "var(--sidebar-primary)",
//         "sidebar-primary-foreground": "var(--sidebar-primary-foreground)",
//         "sidebar-accent": "var(--sidebar-accent)",
//         "sidebar-accent-foreground": "var(--sidebar-accent-foreground)",
//         "sidebar-border": "var(--sidebar-border)",
//         "sidebar-ring": "var(--sidebar-ring)",
//         "chart-1": "var(--chart-1)",
//         "chart-2": "var(--chart-2)",
//         "chart-3": "var(--chart-3)",
//         "chart-4": "var(--chart-4)",
//         "chart-5": "var(--chart-5)",
//       },
//       fontFamily: {
//         sans: ["var(--font-geist-sans)", "sans-serif"],
//         mono: ["var(--font-geist-mono)", "monospace"],
//       },
//       borderRadius: {
//         sm: "calc(var(--radius) - 4px)",
//         md: "calc(var(--radius) - 2px)",
//         lg: "var(--radius)",
//         xl: "calc(var(--radius) + 4px)",
//       },
//     },
//   },
//   darkMode: "class",
//   plugins: [
//     animatePlugin,
//     plugin(function ({ addBase }) {
//       addBase({
//         ":root": {
//           "--background": "1 0 0",
//           "--foreground": "0.13 0.028 261.692",
//           "--card":"1 0 0",
//           "--card-foreground":"0.13 0.028 261.692",
//           "--popover":"1 0 0",
//           "--popover-foreground":"0.13 0.028 261.692",
//           "--primary":"0.21 0.034 264.665",
//           "--primary-foreground":"0.985 0.002 247.839",
//           "--secondary":"0.967 0.003 264.542",
//           "--secondary-foreground":"0.21 0.034 264.665",
//           "--muted":"0.967 0.003 264.542",
//           "--muted-foreground":"0.551 0.027 264.364",
//           "--accent":"0.967 0.003 264.542",
//           "--accent-foreground":"0.21 0.034 264.665",
//           "--destructive":"0.577 0.245 27.325",
//           "--destructive-foreground":"0.577 0.245 27.325",
//           "--border":"0.928 0.006 264.531",
//           "--input":"0.928 0.006 264.531",
//           "--ring":"0.707 0.022 261.325",
//           "--chart-1":"0.646 0.222 41.116",
//           "--chart-2":"0.6 0.118 184.704",
//           "--chart-3":"0.398 0.07 227.392",
//           "--chart-4":"0.828 0.189 84.429",
//           "--chart-5":"0.769 0.188 70.08",
//           "--radius":"0.625rem",
//           "--sidebar":"0.985 0.002 247.839",
//           "--sidebar-foreground":"0.13 0.028 261.692",
//           "--sidebar-primary":"0.21 0.034 264.665",
//           "--sidebar-primary-foreground":"0.985 0.002 247.839",
//           "--sidebar-accent":"0.967 0.003 264.542",
//           "--sidebar-accent-foreground":"0.21 0.034 264.665",
//           "--sidebar-border":"0.928 0.006 264.531",
//           "--sidebar-ring":"0.707 0.022 261.325",
//         },
//         ".dark": {
//           "--background": "0.13 0.028 261.692",
//           "--foreground": "0.985 0.002 247.839",
//           "--card":"0.13 0.028 261.692",
//           "--card-foreground":"0.985 0.002 247.839",
//           "--popover":"0.13 0.028 261.692",
//           "--popover-foreground":"0.985 0.002 247.839",
//           "--primary":"0.985 0.002 247.839",
//           "--primary-foreground":"0.21 0.034 264.665",
//           "--secondary":"0.278 0.033 256.848",
//           "--secondary-foreground":"0.985 0.002 247.839",
//           "--muted":"0.278 0.033 256.848",
//           "--muted-foreground":"0.707 0.022 261.325",
//           "--accent":"0.278 0.033 256.848",
//           "--accent-foreground":"0.985 0.002 247.839",
//           "--destructive":"0.396 0.141 25.723",
//           "--destructive-foreground":"0.637 0.237 25.331",
//           "--border":"0.278 0.033 256.848",
//           "--input":"0.278 0.033 256.848",
//           "--ring":"0.446 0.03 256.802",
//           "--chart-1":"0.488 0.243 264.376",
//           "--chart-2":"0.696 0.17 162.48",
//           "--chart-3":"0.769 0.188 70.08",
//           "--chart-4":"0.627 0.265 303.9",
//           "--chart-5":"0.645 0.246 16.439",
//           "--sidebar":"0.21 0.034 264.665",
//           "--sidebar-foreground":"0.985 0.002 247.839",
//           "--sidebar-primary":"0.488 0.243 264.376",
//           "--sidebar-primary-foreground":"0.985 0.002 247.839",
//           "--sidebar-accent":"0.278 0.033 256.848",
//           "--sidebar-accent-foreground":"0.985 0.002 247.839",
//           "--sidebar-border":"0.278 0.033 256.848",
//           "--sidebar-ring":"0.446 0.03 256.802",
           
//         }
//       })
//     }),
//   ],
// };



import animatePlugin from "tailwindcss-animate";

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "oklch(var(--background))",
        foreground: "oklch(var(--foreground))",
        card: "oklch(var(--card))",
        "card-foreground": "oklch(var(--card-foreground))",
        popover: "oklch(var(--popover))",
        "popover-foreground": "oklch(var(--popover-foreground))",
        primary: "oklch(var(--primary))",
        "primary-foreground": "oklch(var(--primary-foreground))",
        secondary: "oklch(var(--secondary))",
        "secondary-foreground": "oklch(var(--secondary-foreground))",
        muted: "oklch(var(--muted))",
        "muted-foreground": "oklch(var(--muted-foreground))",
        accent: "oklch(var(--accent))",
        "accent-foreground": "oklch(var(--accent-foreground))",
        destructive: "oklch(var(--destructive))",
        "destructive-foreground": "oklch(var(--destructive-foreground))",
        border: "oklch(var(--border))",
        input: "oklch(var(--input))",
        ring: "oklch(var(--ring))",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  darkMode: "class",
  plugins: [animatePlugin],
};